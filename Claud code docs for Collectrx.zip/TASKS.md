# CollectRx — Build Task List

> **How to use:** Pick the next unchecked task in the current phase. Fully implement and test it. Check it off. Move to the next. Do not skip phases.

---

## Phase 1 — Electron Shell

- [ ] `src/electron/main.js` — Electron entry point, BrowserWindow config, Railway URL webview
- [ ] `src/electron/preload.js` — context bridge, IPC handlers, secure channel setup
- [ ] `src/electron/tray.js` — system tray icon, right-click menu (Open, Sync Now, Quit)
- [ ] `electron-builder.config.js` — Windows NSIS installer config, app icon, auto-update stub
- [ ] `src/electron/updater.js` — electron-updater stub (check Railway endpoint for version)

## Phase 2 — Backend Endpoints (Electron-facing)

- [ ] `POST /api/queue/priority` — carrier priority panel endpoint (reorder queue by carrier weight)
- [ ] `GET /api/sync/status` — return last sync time, claim count, connector health
- [ ] `POST /api/sync/trigger` — manually trigger Abeldent sync from tray menu
- [ ] `GET /api/dashboard/summary` — AR aging buckets, open claims count, resolution rate
- [ ] `GET /api/escalations` — list open escalations needing human review

## Phase 3 — Eligibility Agent Logic

- [ ] `src/agents/eligibility/estimator.js` — pre-treatment estimate calculator (CDT codes → coverage %)
- [ ] `src/agents/eligibility/annual-max-tracker.js` — track used vs. remaining annual maximum per patient
- [ ] `src/agents/eligibility/deductible-engine.js` — deductible status logic (met / not met / partial)
- [ ] `src/agents/eligibility/cdt-category-map.json` — CDT procedure codes → coverage category mappings for all 6 carriers
- [ ] `src/agents/eligibility/coordination-of-benefits.js` — COB logic (primary → secondary carrier sequencing)

## Phase 4 — Patient AR & Payments

- [ ] `src/backend/patient-ar/reconciler.js` — post-insurance balance calculator (billed − insurer paid = patient owes)
- [ ] `src/backend/patient-ar/stripe-connect.js` — Stripe Connect payment link generator per practice
- [ ] `src/backend/patient-ar/reminders.js` — SMS (Twilio) + email (SendGrid) reminder scheduler
- [ ] `src/backend/patient-ar/payment-webhook.js` — Stripe webhook handler, mark claim as paid in PostgreSQL
- [ ] `src/frontend/components/PatientARPanel.jsx` — patient balance dashboard component
- [ ] `src/frontend/components/EscalationQueue.jsx` — human review queue UI with claim detail modal
- [ ] `src/frontend/components/CarrierPriorityPanel.jsx` — drag-and-drop carrier queue ordering

---

## Pre-Pilot Blockers (must complete before Dr. Hasan goes live)

- [ ] Run `discover-schema.js` on Dr. Hasan's machine — confirm Abeldent table/column names
- [ ] Rotate Vapi API key
- [ ] Rotate Railway PostgreSQL credentials
- [ ] Rotate webhook secret (`openssl rand -hex 32`)
- [ ] Validate AI disclosure script with pilot call test (must state AI identity in first 10 seconds)
- [ ] End-to-end test: Abeldent claim → queue → Vapi call → outcome recorded → dashboard updated
