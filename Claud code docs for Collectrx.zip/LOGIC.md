# CollectRx — Business Logic & Safety Architecture

> This file defines how the system works, what decisions it makes autonomously, when it stops and escalates to a human, and what it must never do. Any AI session building this product must read this file before writing logic code.

---

## 1. The Core Loop

```
Every night (2am ET):
  1. Abeldent connector queries SQL Server for unpaid claims
  2. Claims are tokenized via PIIVault (PHI → UUID)
  3. Tokens synced to Railway PostgreSQL
  4. Queue engine scores and orders claims for follow-up
  5. Morning (8am ET): Vapi squad begins outbound calls
  6. Outcomes recorded → dashboard updated → escalations flagged
```

---

## 2. Claim Eligibility for Queue

A claim enters the follow-up queue when ALL of the following are true:

- Status in Abeldent is unpaid / pending insurer
- Days since service date is **≥ 30**
- Carrier is one of the 6 supported carriers
- Claim has not been manually paused by practice staff
- Call attempts on this claim are **< 3**
- The claim has not been marked `CARRIER_BLOCK`

A claim is **excluded** from the queue when ANY of the following are true:

- Already resolved (paid, written off, or patient responsibility confirmed)
- Manually paused by staff
- Carrier block logged (see Section 6)
- Claim is < 30 days old

---

## 3. Aging Buckets and Call Timing

| Bucket | Days Since Service | Action |
|---|---|---|
| Early | 30–44 days | First call attempt |
| Mid | 45–59 days | Second call attempt if unresolved |
| Late | 60–89 days | Third call attempt; escalate if still unresolved |
| Critical | 90+ days | Immediate escalation to human; AI does not call |

**Carrier-specific minimum wait periods (do not call before these):**

| Carrier | Minimum Wait Before First Call |
|---|---|
| Sun Life | Day 30 (2–15 business day payment window) |
| Canada Life | Day 32 (stated 5 business day SLA + 2 day buffer) |
| Manulife | Day 30 |
| Green Shield Canada | Day 30 |
| RBC Insurance | Day 30 |
| TELUS AdjudiCare | Day 21 (1–2 week processing + 3–10 day payment) |

---

## 4. Call Execution Rules

### Hours of Operation
- **Permitted:** Monday–Friday, 8:00am–5:00pm ET only
- **Never call:** weekends, Canadian statutory holidays, outside permitted hours
- Canadian holidays to skip: New Year's Day, Family Day (ON), Good Friday, Victoria Day, Canada Day, Civic Holiday (ON), Labour Day, Thanksgiving (ON), Remembrance Day, Christmas Day, Boxing Day

### Call Attempt Limits
- Maximum **3 attempts** per claim
- Minimum **3 business days** between attempts on the same claim
- After 3 failed attempts: escalate to human, do NOT retry automatically

### Call Opening — AI Disclosure (MANDATORY)
Every call must open with this disclosure within the first 10 seconds:

> *"Hello, this is an automated AI assistant calling on behalf of [Practice Name]. I am not a human agent. I'm calling to follow up on a dental claim submitted by this office. Can you help me check the status of a claim?"*

Failure to disclose AI identity is a compliance violation. This script is non-negotiable.

### Authentication Fields by Carrier
The AI agent must be prepared to provide:
- Provider name and billing address
- Provider NPI / registration number
- Patient group number and member certificate number (from tokenized claim record)
- Date of service
- Claim amount billed
- Procedure codes

**The AI never provides patient name, date of birth, or address directly.** These are retrieved from PIIVault by the backend when needed and provided to the agent as structured data — the agent reads them from the call context, it does not store them.

---

## 5. Outcome Classification

Every call must be logged with one of these outcomes:

| Code | Meaning | Next Action |
|---|---|---|
| `PAID` | Payment confirmed, ETA provided | Record ETA, close claim |
| `IN_PROCESS` | Claim received, processing | Retry after stated wait period |
| `PENDING_INFO` | Carrier needs more documentation | Escalate to human immediately |
| `DENIED` | Claim denied | Escalate to human with denial code |
| `RESUBMIT` | Claim needs resubmission | Escalate to human |
| `NO_ANSWER` | IVR not reached / call dropped | Retry next business day |
| `HOLD_TIMEOUT` | Hold time exceeded 20 minutes | End call, retry next day |
| `CARRIER_BLOCK` | Carrier detected automation | See Section 6 |
| `WRONG_DEPT` | Reached wrong department | Retry same day (once) |
| `ESCALATION_NEEDED` | Agent could not resolve | Escalate to human |

---

## 6. Carrier Block Protocol (Critical Safety Rule)

If a carrier IVR or representative:
- Explicitly states "we do not accept automated calls"
- Disconnects the call immediately upon detecting AI speech patterns
- Requests CAPTCHA, math verification, or human confirmation
- Returns a `CARRIER_BLOCK` signal

Then the system **must**:

1. Log the call as `CARRIER_BLOCK` immediately
2. Flag the claim for human follow-up
3. **Suspend ALL automated calls to that carrier** — not just this claim
4. Alert the practice admin via dashboard notification
5. Do NOT retry that carrier automatically

A human must review and decide whether to:
- Resume calls with a modified approach
- Switch to portal-based follow-up (providerConnect for Canada Life/Sun Life)
- Pursue phone follow-up manually for that carrier

**This is the most important safety rule in the system.** Repeated calls after a block could result in the carrier blacklisting the practice's provider number.

---

## 7. TELUS AdjudiCare Special Logic

AdjudiCare (Carrier ID 000034) is a clearinghouse, not a single insurer. Each TPA underneath it has different rules.

Before calling on any AdjudiCare claim, the system must:

1. Identify the specific TPA from the member benefit card data
2. Load that TPA's knowledge base config (IVR tree, auth fields, hours)
3. If the TPA config is not found: **do not call** — escalate to human with note "Unknown AdjudiCare TPA"

Processing times for AdjudiCare vary by TPA: range is 1–2 weeks for claims, 3–10 business days for payment once approved.

---

## 8. Escalation Rules — When AI Must Stop and Hand Off

The AI must escalate and stop attempting resolution when:

- Outcome is `DENIED`, `PENDING_INFO`, or `RESUBMIT`
- Claim reaches 90+ days aging
- 3 call attempts exhausted without resolution
- `CARRIER_BLOCK` detected
- Unknown AdjudiCare TPA
- Agent confidence score drops below threshold (Vapi returns low-confidence transcript)
- Any mention of legal action, fraud investigation, or audit from the carrier
- Patient has filed a complaint with the carrier (agent learns this on the call)

Escalations appear in the Escalation Queue on the dashboard. Staff resolve them manually. CollectRx records resolution notes back into the claim record.

---

## 9. PHI Safety Rules (Non-Negotiable)

These rules cannot be relaxed, overridden, or modified by any AI session:

1. **PHI never goes to Vapi.** Only UUID tokens. No exceptions.
2. **PHI never appears in logs.** Log the token, never the value.
3. **PHI never appears in Electron.** The desktop app renders the dashboard webview — it has no direct database access.
4. **PHI is encrypted at rest** in Railway PostgreSQL using pgcrypto.
5. **Every PHI access is audit logged** with: timestamp, accessor (system component), token, operation, and reason.
6. **Data minimization:** Only retrieve the fields needed for the specific call. Do not pre-load full patient records.
7. **Retention:** Call transcripts are stored for 3 years + 14 days (CRTC requirement). PHI is not embedded in transcripts — only tokens.

---

## 10. Regulatory Context

### CRTC / Unsolicited Telecommunications
- CollectRx calls are **B2B** (dental provider → insurance carrier). These are not consumer calls.
- B2B calls are not subject to the National Do Not Call List.
- Hours restriction (8am–9pm local time) still applies under CRTC rules.
- CollectRx uses 8am–5pm ET as a more conservative limit (carrier hours).

### AI Disclosure
- CRTC does not currently mandate AI disclosure for B2B calls, but **best practice and future-proofing requires it**.
- The disclosure script (Section 4) satisfies anticipated regulatory direction and protects the practice from liability.
- Canada's proposed AIDA (Artificial Intelligence and Data Act) is not yet in force as of 2026 but is anticipated. Architecture is designed to be compliant when it passes.

### PIPEDA
- Insurance carriers' personal health information (member data) is handled under the practice's existing relationship with the carrier.
- CollectRx does not store member personal data beyond what is needed to identify and follow up on a claim.
- Consent for EDI claim submission covers the follow-up interaction under current interpretation.

### Ontario PHIPA
- Dr. Hasan's patients are Ontario residents. PHIPA governs their dental records.
- CollectRx's PHI boundary architecture (Section, CLAUDE.md) is the technical implementation of PHIPA compliance.
- No patient data is shared with any third party. Vapi receives only tokens.

---

## 11. Nimbleness — How the System Adapts Without Breaking

The system is designed so that changes to carrier behavior, IVR trees, or regulations require config changes, not code changes:

| Change | Response |
|---|---|
| Carrier changes IVR menu | Update carrier JSON knowledge base — no code deploy |
| New carrier added | Add new carrier config + knowledge base — no core code change |
| Carrier blocks AI calls | `CARRIER_BLOCK` protocol activates automatically (Section 6) |
| Regulatory change to AI disclosure | Update disclosure script string in config — one change, all carriers |
| Practice wants different aging buckets | Update queue config per practice — no code change |
| New TPA under AdjudiCare | Add TPA config to AdjudiCare knowledge base — no code change |
| Abeldent schema changes | Re-run `discover-schema.js`, update column map — no core code change |

**The carrier knowledge base is the competitive moat.** It encodes years of IVR navigation experience. Protect it, version it, and update it continuously.

---

## 12. The Three Pilot Assumptions Being Tested

The 90-day pilot with Dr. Hasan is designed to validate exactly three things:

1. **Will carriers accept AI callers?** → Monitored via `CARRIER_BLOCK` rate per carrier
2. **Does the AI achieve sufficient resolution rates?** → Target: >50% resolution without human escalation
3. **Will practices pay the proposed pricing?** → Validated by Dr. Hasan's willingness to convert to paid after pilot

If assumption #1 fails for a carrier: switch that carrier to portal-based follow-up (providerConnect API or web scraping), not phone.

If assumption #2 fails: improve agent scripts and carrier knowledge bases before expanding.

If assumption #3 fails: revisit pricing model before signing more practices.

Do not expand to additional practices until all three assumptions are validated.
