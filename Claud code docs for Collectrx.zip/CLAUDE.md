# CollectRx — AI Session Context

## What We're Building

CollectRx is a dental practice revenue cycle automation platform for **Canadian dental practices**. The core problem: dental office staff spend hours each week manually calling insurance carriers to follow up on unpaid claims. CollectRx automates this with AI voice agents and extends into full RCM.

**Pilot partner:** Dr. Hasan at Tenth Line Family Dentistry, Ottawa, Ontario  
**PMS:** Abeldent Local Plus (Windows desktop, on-premise SQL Server — Local Plus / installed edition)  
**GitHub repo:** `github.com/khalidegeh/Click` (repo name: `Collect-RX-main`)

---

## What We're Building — Full Scope

1. **Insurance AR follow-up** via AI voice agents (core product)
2. **Pre-treatment eligibility estimates**
3. **Annual maximum tracking**
4. **CDT procedure category coverage breakdowns**
5. **Post-insurance patient balance reconciliation**
6. **Automated patient payment collection** via Stripe Connect

---

## Tech Stack

| Layer | Technology |
|---|---|
| Voice AI | Vapi.ai (Squad architecture — 4 agents) |
| Telephony | Twilio |
| Backend | Node.js / Express on Railway (permanent — Vapi webhooks need public URL) |
| Database | PostgreSQL (Railway) + SQL Server (Abeldent on-premise) |
| Frontend | React / Vite / Tailwind CSS |
| Desktop packaging | Electron (thin wrapper — Option B) |
| Payments | Stripe Connect (NOT standard Stripe) |
| Email | SendGrid |
| PMS connector | `mssql` package, Windows Integrated Auth |
| Compliance | PIIVault tokenization |
| Logging | Winston with rotating file output |
| Windows Service | `node-windows` |

---

## Architecture — The PHI Boundary (NEVER VIOLATE THIS)

```
Abeldent SQL Server
        ↓
  Node.js Backend (Railway)  ← PHI lives here only
        ↓ UUID tokens only (no PHI)
      Vapi Agents
        ↓
   Insurance Carriers
```

- **PHI never crosses to Vapi.** Only UUID tokens go to the Vapi squad.
- The Node.js backend maps tokens ↔ real patient data via PIIVault.
- Electron shell is a thin UI wrapper — it never handles PHI.
- PostgreSQL on Railway holds the token map and audit logs.
- All PHI stays encrypted at rest on Railway.

---

## Carriers in Scope (78% of Canadian private dental market)

| Carrier | Carrier ID | Network | Key Details |
|---|---|---|---|
| Sun Life | — | CDAnet / TELUS Group B | 2–15 business days payment; providerConnect portal |
| Canada Life | 000011 | CDAnet v4 / TELUS Group B | 5 business day SLA; providerConnect portal; 90-day EDI submission window |
| Manulife | — | CDAnet / TELUS Group B | EDI via SECUREServe portal |
| Green Shield Canada | — | CDAnet | Portal available |
| RBC Insurance | — | CDAnet | Phone follow-up primary method |
| TELUS AdjudiCare | 000034 | TELUS Dental Network Group B | Aggregated clearinghouse for many small TPAs/TPPs; 1–2 week processing; payment 3–10 business days |

**Key insight about TELUS AdjudiCare:** It is NOT a single insurer. It is a clearinghouse for dozens of small third-party administrators. Each underlying TPA has its own rules. When the AI agent calls for AdjudiCare claims, it must identify the specific TPA from the member card before navigating the IVR.

---

## Vapi Squad Architecture — 4 Agents

1. **IVR_Navigator** — navigates carrier phone trees to reach a claims agent
2. **Claims_Agent** — authenticates, queries claim status, records outcome
3. **Escalation_Closer** — handles complex denials, requests supervisor
4. **Resolution_Closer** — confirms payment details, records ETA

Each agent has a per-carrier JSON knowledge base encoding IVR trees, authentication fields, hold patterns, and denial codes.

---

## Compliance Requirements

- **PHIPA** (Ontario) — dental records are personal health information
- **PIPEDA** (federal) — governs data handling by private businesses
- **AI Disclosure** — every call must open with disclosure that it is an AI agent calling on behalf of the dental practice
- **CRTC** — B2B calls (provider → insurer) are not subject to DNCL; hours restriction (8am–9pm local) still applies
- **Audit logging** — every call, outcome, and data access must be logged
- **Data minimization** — only the minimum PHI needed for each operation is accessed

---

## Key Business Logic Rules

- Claims are queued for follow-up at **30, 45, 60, 90 days** aging buckets
- Canada Life has a **5 business day** stated SLA — do not call before day 7 (give buffer)
- TELUS AdjudiCare processing is **1–2 weeks** — do not call before day 14
- Sun Life payment via EFT arrives within **2 business days** of approval — use this to detect stalls
- Maximum **3 call attempts** per claim before escalating to human
- Calls permitted **Monday–Friday, 8am–5pm ET** only (carrier hours)
- If a carrier IVR detects automation and terminates, log as `CARRIER_BLOCK` and escalate immediately — do NOT retry automatically

---

## Pitfalls — Do Not Repeat These Mistakes

1. **Real credentials were found in a previous `.env` upload.** Rotate: Vapi API key, Railway PostgreSQL credentials, webhook secret (`openssl rand -hex 32`) before pilot go-live.
2. **Schema discovery is pending.** `discover-schema.js` must be run on Dr. Hasan's machine to confirm actual Abeldent table/column names before the sync query runs live. Do not hardcode column names.
3. **Stripe Connect, not standard Stripe.** Standard Stripe makes CollectRx the merchant of record — unacceptable. Connect keeps each practice as its own merchant.
4. **Backend stays on Railway.** Vapi webhooks require a public URL. Do not move the backend to fully local.
5. **Electron is a thin wrapper only.** All logic lives in Node.js backend. Electron only renders the dashboard webview and system tray.

---

## Directory Structure

```
/
├── src/
│   ├── backend/          # Node.js/Express — all business logic
│   ├── frontend/         # React/Vite/Tailwind dashboard
│   ├── electron/         # main.js, preload.js, tray
│   ├── agents/           # Vapi squad configs, carrier knowledge bases
│   └── connector/        # Abeldent SQL Server sync service
├── migrations/           # PostgreSQL schema migrations
├── tests/
├── CLAUDE.md             # This file
├── TASKS.md              # Build checklist
└── LOGIC.md              # Business logic and safety architecture
```

---

## Current Build Status

- ✅ PHIPA/PIPEDA compliance layer (PIIVault, audit logging, encrypted schema)
- ✅ Abeldent database connector (Node.js package, Windows Service installer)
- ✅ 4-agent Vapi Squad architecture with per-carrier JSON knowledge bases
- ✅ Backend: Node.js/Express on Railway (queue engine, outcome processor, escalation system)
- ✅ Frontend: React/Vite/Tailwind dashboard
- ⏳ Electron shell (thin wrapper — in progress)
- ⏳ Schema discovery on Dr. Hasan's machine
- ⏳ Credential rotation
- ⏳ Pilot deployment

---

## Model Selection

- **Sonnet** for Phases 1–2 (Electron shell, backend scaffolding — well-defined)
- **Opus** for Phase 3 (eligibility agent logic, insurance rules, edge cases — complex reasoning)
