/**
 * Comprehensive Test Suite for CollectRx Eligibility Engine
 *
 * Tests cover the complete API surface of the eligibility calculation system:
 * - Deductible application and tracking
 * - Annual maximum enforcement
 * - CDT code mapping to coverage tiers
 * - Frequency limit enforcement
 * - Waiting period validation
 * - Full treatment plan estimates
 * - Coordination of Benefits (COB)
 * - Claims reconciliation
 * - Edge cases and error handling
 *
 * Test data uses real CDT codes and realistic Canadian dollar amounts.
 * All tests are deterministic and stateless (no database dependencies).
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  EligibilityEngine,
  createEngine,
  estimateProcedures,
} from '../src/services/eligibility/engine';
import {
  Patient,
  Plan,
  EligibilitySnapshot,
  ProcedureInput,
  EstimateRequest,
  CarrierCode,
  CoverageTier,
  ActualClaimPayment,
  ReconcileRequest,
} from '../src/services/eligibility/types';
import { DeductibleTracker } from '../src/services/eligibility/rules/deductible';
import { AnnualMaxTracker } from '../src/services/eligibility/rules/annual-max';
import { ReconciliationEngine } from '../src/services/eligibility/reconciliation';
import { CARRIER_CONFIGS } from '../src/services/eligibility/rules/carriers';

// ============================================================================
// === TEST DATA HELPERS ===
// ============================================================================

/**
 * Create a realistic test patient with Canadian coverage
 */
function createTestPatient(id: string = 'patient-001'): Patient {
  return {
    id,
    firstName: 'John',
    lastName: 'Smith',
    dateOfBirth: '1985-06-15',
    insuranceId: 'SL123456789',
    groupNumber: 'GROUP001',
    relationshipToSubscriber: 'self',
    language: 'en',
    email: 'john.smith@example.com',
    phone: '416-555-0123',
  };
}

/**
 * Create a test plan for a given carrier
 */
function createTestPlan(
  patientId: string = 'patient-001',
  carrierCode: CarrierCode = 'sunlife_private',
  isPrimary: boolean = true
): Plan {
  return {
    id: `plan-${carrierCode}-${patientId}`,
    patientId,
    carrierCode,
    planName: `${carrierCode.toUpperCase()} Comprehensive`,
    groupNumber: 'GROUP001',
    effectiveDate: '2026-01-01',
    planType: 'group',
    isPrimary,
    sequence: isPrimary ? 1 : 2,
  };
}

/**
 * Create an eligibility snapshot with custom deductible/annual max usage
 */
function createTestSnapshot(
  patientId: string = 'patient-001',
  planId: string = 'plan-sunlife_private-patient-001',
  deductibleUsed: number = 0,
  annualMaxUsed: number = 0,
  isActive: boolean = true
): EligibilitySnapshot {
  return {
    id: `snapshot-${patientId}-${planId}`,
    patientId,
    planId,
    capturedAt: '2026-04-05T10:00:00Z',
    source: 'carrier_lookup',
    isActive,
    effectiveDate: '2026-01-01',
    deductibleUsed: {
      individual: deductibleUsed,
      family: deductibleUsed,
    },
    annualMaxUsed: {
      individual: annualMaxUsed,
    },
    claimsHistory: [],
    lastVerifiedDate: '2026-04-04',
  };
}

/**
 * Create a simple procedure input
 */
function createProcedure(
  cdtCode: string,
  providerFee: number = 150,
  dateOfService: string = '2026-04-15',
  quantity: number = 1,
  toothNumber?: string
): ProcedureInput {
  return {
    cdtCode,
    providerFee,
    quantity,
    dateOfService,
    toothNumber,
  };
}

/**
 * Create a complete estimate request
 */
function createEstimateRequest(
  patient: Patient,
  plan: Plan,
  procedures: ProcedureInput[],
  eligibility?: EligibilitySnapshot,
  secondaryPlan?: Plan,
  secondaryEligibility?: EligibilitySnapshot
): EstimateRequest {
  return {
    patient,
    plan,
    procedures,
    eligibility,
    secondaryPlan,
    secondaryEligibility,
  };
}

// ============================================================================
// === 1. DEDUCTIBLE APPLICATION TESTS ===
// ============================================================================

describe('Deductible Application Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;
  let sunLifePlan: Plan;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
    sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
  });

  it('Test: Sun Life $50 deductible applies to first basic procedure', () => {
    // Sun Life Private has $50 individual deductible
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0);
    const fillingProcedure = createProcedure('D2391', 150, '2026-04-15'); // Composite filling

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Basic coverage is 80%, so:
    // Covered amount = (150 - 50) * 0.80 = 80
    // Patient portion = 150 - 80 = 70
    expect(result.procedures[0].deductibleApplied).toBe(50);
    expect(result.procedures[0].insurancePortion).toBe(80);
    expect(result.procedures[0].patientPortion).toBe(70);
    expect(result.summary.totalDeductibleApplied).toBe(50);
  });

  it('Test: Manulife $0 deductible means no deductible on any procedure', () => {
    // Manulife has $0 deductible
    const manulifePlan = createTestPlan(patient.id, 'manulife');
    const snapshot = createTestSnapshot(patient.id, manulifePlan.id, 0);
    const fillingProcedure = createProcedure('D2391', 150);

    const request = createEstimateRequest(patient, manulifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // With $0 deductible, insurance pays 80% of full amount
    expect(result.procedures[0].deductibleApplied).toBe(0);
    expect(result.procedures[0].insurancePortion).toBe(120); // 150 * 0.80
    expect(result.procedures[0].patientPortion).toBe(30);
  });

  it('Test: Preventive procedures waive deductible (Sun Life)', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0);
    const cleaningProcedure = createProcedure('D1110', 120, '2026-04-15'); // Adult prophylaxis

    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Preventive is 100%, no deductible applies
    expect(result.procedures[0].deductibleApplied).toBe(0);
    expect(result.procedures[0].insurancePortion).toBe(120);
    expect(result.procedures[0].patientPortion).toBe(0);
    expect(result.summary.totalDeductibleApplied).toBe(0);
  });

  it('Test: Deductible applies across batch — second procedure gets reduced deductible', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0);
    const procedures = [
      createProcedure('D2391', 100), // Composite, $100
      createProcedure('D2380', 120), // Another composite, $120
    ];

    const request = createEstimateRequest(patient, sunLifePlan, procedures, snapshot);
    const result = engine.calculateEstimate(request);

    // First procedure: 50 deductible applied
    expect(result.procedures[0].deductibleApplied).toBe(50);

    // Second procedure: remaining $30 of deductible applied (50 - 50 already used = 0 remaining, so $0)
    // But since first was only 50, we have $0 remaining
    // Actual: second proc gets (100 - 50) covered = 50 * 0.80 = 40
    // Actually, second should get 0 deductible (all 50 used on first)
    expect(result.procedures[1].deductibleApplied).toBe(0);
    expect(result.summary.totalDeductibleApplied).toBe(50);
  });

  it('Test: Family deductible cap — individual stops once family total met', () => {
    // When family deductible is met, individual deductible is considered satisfied
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 75); // Family deductible partially used
    const fillingProcedure = createProcedure('D2391', 150);

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // With 75 of family deductible used out of (assumed) 150 family max,
    // remaining individual deductible should be limited
    // This depends on specific family deductible logic
    expect(result.procedures[0].deductibleApplied).toBeGreaterThanOrEqual(0);
  });

  it('Test: Zero provider fee — no deductible applies', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0);
    const zeroCostProcedure = createProcedure('D0000', 0); // Hypothetical zero-cost code

    const request = createEstimateRequest(patient, sunLifePlan, [zeroCostProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // No provider fee, so no deductible applies
    expect(result.procedures[0].deductibleApplied).toBe(0);
    expect(result.procedures[0].insurancePortion).toBe(0);
  });
});

// ============================================================================
// === 2. ANNUAL MAXIMUM TESTS ===
// ============================================================================

describe('Annual Maximum Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;
  let sunLifePlan: Plan;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
    sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
  });

  it('Test: Basic procedure counts toward annual max', () => {
    // Sun Life annual max is $1200
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 50, 0);
    const fillingProcedure = createProcedure('D2391', 500); // $500 filling

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // After deductible ($50), covered = 450 * 0.80 = 360
    // This counts toward annual max
    // Remaining = 1200 - 360 = 840
    expect(result.summary.annualMaxRemaining).toBeLessThan(1200);
    expect(result.procedures[0].annualMaxApplied).toBeGreaterThan(0);
  });

  it('Test: Preventive does NOT count toward max for Sun Life (includesPreventive: false)', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const cleaningProcedure = createProcedure('D1110', 150);

    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Preventive should NOT count toward annual max for Sun Life
    // Annual max should remain at 1200
    expect(result.summary.annualMaxRemaining).toBe(1200);
  });

  it('Test: Preventive DOES count toward max for Green Shield (includesPreventive: true)', () => {
    const greenShieldPlan = createTestPlan(patient.id, 'green_shield');
    const snapshot = createTestSnapshot(patient.id, greenShieldPlan.id, 0, 0);
    const cleaningProcedure = createProcedure('D1110', 150);

    const request = createEstimateRequest(patient, greenShieldPlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // For Green Shield, preventive DOES count toward annual max
    // Insurance pays 100% of 150 = 150 toward annual max
    expect(result.summary.annualMaxRemaining).toBeLessThan(greenShieldPlan.carrierCode === 'green_shield' ? 2000 : 1200);
  });

  it('Test: Annual max exhausted — remaining procedures patient pays 100%', () => {
    // Set annual max already used to nearly max (assuming 1200 max)
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 50, 1150);
    const expensiveCrown = createProcedure('D2750', 1200); // Crown

    const request = createEstimateRequest(patient, sunLifePlan, [expensiveCrown], snapshot);
    const result = engine.calculateEstimate(request);

    // Only $50 remaining annual max, so insurance pays only $50
    // Patient pays 1200 - 50 = 1150
    expect(result.procedures[0].insurancePortion).toBeLessThanOrEqual(50);
    expect(result.procedures[0].patientPortion).toBeGreaterThan(1150);
  });

  it('Test: Manulife family aggregate max ($6,000) caps total across family', () => {
    const manulifePlan = createTestPlan(patient.id, 'manulife');
    // Assume Manulife has 6000 family max
    const snapshot = createTestSnapshot(patient.id, manulifePlan.id, 0, 5800);
    const procedures = [
      createProcedure('D2750', 500), // Crown - 50% = 250
      createProcedure('D2751', 500), // Another crown - 50% = 250
    ];

    const request = createEstimateRequest(patient, manulifePlan, procedures, snapshot);
    const result = engine.calculateEstimate(request);

    // Only $200 remaining of family max (6000 - 5800)
    // Both procedures together would be 500, so both hit the family max cap
    expect(result.summary.annualMaxRemaining).toBeLessThanOrEqual(200);
  });
});

// ============================================================================
// === 3. CDT CODE MAPPING TESTS ===
// ============================================================================

describe('CDT Code Mapping Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;
  let sunLifePlan: Plan;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
    sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
  });

  it('Test: D1110 (cleaning) maps to "preventive" tier', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const cleaningProcedure = createProcedure('D1110', 120);

    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    expect(result.procedures[0].tier).toBe('preventive');
    expect(result.procedures[0].coveragePercentage).toBe(100);
  });

  it('Test: D2750 (crown) maps to "major" tier', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const crownProcedure = createProcedure('D2750', 1200);

    const request = createEstimateRequest(patient, sunLifePlan, [crownProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    expect(result.procedures[0].tier).toBe('major');
    expect(result.procedures[0].coveragePercentage).toBe(50); // Sun Life major coverage
  });

  it('Test: D3310 (root canal) maps to "endodontic" tier', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const rootCanalProcedure = createProcedure('D3310', 800);

    const request = createEstimateRequest(patient, sunLifePlan, [rootCanalProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Root canal should map to endodontic or basic tier depending on config
    expect(result.procedures[0].tier).toMatch(/basic|endodontic/);
  });

  it('Test: Unknown CDT code throws error or returns undefined', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const invalidProcedure = createProcedure('D9999', 100); // Invalid code

    const request = createEstimateRequest(patient, sunLifePlan, [invalidProcedure], snapshot);

    // Should throw or handle gracefully
    expect(() => engine.calculateEstimate(request)).toThrow();
  });
});

// ============================================================================
// === 4. FREQUENCY LIMIT TESTS ===
// ============================================================================

describe('Frequency Limit Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;
  let sunLifePlan: Plan;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
    sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
  });

  it('Test: Sun Life allows 2 cleanings per 6 months — third is limited', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    // Add 2 cleanings to history within last 6 months
    snapshot.claimsHistory = [
      {
        claimId: 'claim-001',
        cdtCode: 'D1110',
        dateOfService: '2026-02-15',
        amountBilled: 120,
        amountPaid: 120,
      },
      {
        claimId: 'claim-002',
        cdtCode: 'D1110',
        dateOfService: '2026-03-15',
        amountBilled: 120,
        amountPaid: 120,
      },
    ];

    const thirdCleaningProcedure = createProcedure('D1110', 120, '2026-04-15');
    const request = createEstimateRequest(patient, sunLifePlan, [thirdCleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Third cleaning should be frequency-limited
    expect(result.procedures[0].frequencyLimited).toBe(true);
    expect(result.procedures[0].frequencyNote).toBeDefined();
  });

  it('Test: Green Shield 9-month cleaning interval — cleaning at 7 months is limited', () => {
    const greenShieldPlan = createTestPlan(patient.id, 'green_shield');
    const snapshot = createTestSnapshot(patient.id, greenShieldPlan.id, 0, 0);
    // Previous cleaning in August 2025
    snapshot.claimsHistory = [
      {
        claimId: 'claim-001',
        cdtCode: 'D1110',
        dateOfService: '2025-08-15',
        amountBilled: 120,
        amountPaid: 120,
      },
    ];

    // New cleaning in April 2026 (about 8 months later)
    const cleaningProcedure = createProcedure('D1110', 120, '2026-04-15');
    const request = createEstimateRequest(patient, greenShieldPlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Depending on Green Shield's exact rules, this might be limited
    if (result.procedures[0].frequencyLimited) {
      expect(result.procedures[0].frequencyNote).toBeDefined();
    }
  });

  it('Test: Full mouth X-rays limited to 1 per 36 months (Sun Life)', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    // Add a full mouth series from 24 months ago
    snapshot.claimsHistory = [
      {
        claimId: 'claim-001',
        cdtCode: 'D0210',
        dateOfService: '2024-04-15',
        amountBilled: 80,
        amountPaid: 80,
      },
    ];

    // Request another full mouth series now (within 36 months)
    const xrayProcedure = createProcedure('D0210', 80, '2026-04-15');
    const request = createEstimateRequest(patient, sunLifePlan, [xrayProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Should be frequency limited
    expect(result.procedures[0].frequencyLimited).toBe(true);
  });

  it('Test: Per-tooth frequency — same code on different teeth is allowed', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    // Previous crown on tooth #14
    snapshot.claimsHistory = [
      {
        claimId: 'claim-001',
        cdtCode: 'D2750',
        dateOfService: '2025-06-15',
        amountBilled: 1200,
        amountPaid: 600,
        toothNumber: '14',
      },
    ];

    // New crown on tooth #15 (different tooth, same code)
    const crownProcedure = createProcedure('D2750', 1200, '2026-04-15', 1, '15');
    const request = createEstimateRequest(patient, sunLifePlan, [crownProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Should NOT be frequency limited since it's on a different tooth
    expect(result.procedures[0].frequencyLimited).toBe(false);
  });
});

// ============================================================================
// === 5. WAITING PERIOD TESTS ===
// ============================================================================

describe('Waiting Period Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
  });

  it('Test: Sun Life 12-month ortho waiting period — ortho procedure at 6 months is blocked', () => {
    // Plan effective date Jan 1, 2026
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    sunLifePlan.effectiveDate = '2026-01-01';

    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.effectiveDate = '2026-01-01';

    // Ortho procedure at 6 months (June 2026) - within waiting period
    const orthoProcedure = createProcedure('D8070', 2000, '2026-06-15'); // Comprehensive ortho treatment

    const request = createEstimateRequest(patient, sunLifePlan, [orthoProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Should have waiting period applied
    expect(result.procedures[0].waitingPeriodApplies).toBe(true);
    expect(result.procedures[0].excluded).toBe(true);
  });

  it('Test: Sun Life ortho waiting period — procedure at 14 months is covered', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    sunLifePlan.effectiveDate = '2025-02-01'; // 14 months ago

    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.effectiveDate = '2025-02-01';

    // Ortho procedure at 14 months (after waiting period)
    const orthoProcedure = createProcedure('D8070', 2000, '2026-04-01');

    const request = createEstimateRequest(patient, sunLifePlan, [orthoProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Should NOT have waiting period applied
    expect(result.procedures[0].waitingPeriodApplies).toBe(false);
    expect(result.procedures[0].excluded).toBe(false);
  });

  it('Test: No waiting period for basic procedures', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    sunLifePlan.effectiveDate = '2026-03-01'; // Only 1 month effective

    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.effectiveDate = '2026-03-01';

    // Basic procedure at 1 month - should NOT have waiting period
    const fillingProcedure = createProcedure('D2391', 150, '2026-04-01');

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Basic procedures don't have waiting periods
    expect(result.procedures[0].waitingPeriodApplies).toBe(false);
  });
});

// ============================================================================
// === 6. FULL ESTIMATE TESTS ===
// ============================================================================

describe('Full Estimate Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
  });

  it('Test: Single preventive procedure (cleaning) — Sun Life pays 100%, no deductible', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const cleaningProcedure = createProcedure('D1110', 150, '2026-04-15');

    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    expect(result.summary.totalProviderFees).toBe(150);
    expect(result.summary.totalInsurancePortion).toBe(150);
    expect(result.summary.totalPatientPortion).toBe(0);
    expect(result.summary.totalDeductibleApplied).toBe(0);
    expect(result.procedures.length).toBe(1);
  });

  it('Test: Single basic procedure (filling) — Sun Life pays 80% after $50 deductible', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const fillingProcedure = createProcedure('D2391', 200, '2026-04-15');

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // (200 - 50 deductible) * 0.80 = 120
    expect(result.summary.totalProviderFees).toBe(200);
    expect(result.summary.totalInsurancePortion).toBe(120);
    expect(result.summary.totalPatientPortion).toBe(80); // 50 deductible + 30 coinsurance
    expect(result.summary.totalDeductibleApplied).toBe(50);
  });

  it('Test: Multi-procedure batch (cleaning + filling + crown) — correct deductible application order and coverage tiers', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const procedures = [
      createProcedure('D1110', 150), // Preventive - 100%
      createProcedure('D2391', 200), // Basic - 80%
      createProcedure('D2750', 1200), // Major - 50%
    ];

    const request = createEstimateRequest(patient, sunLifePlan, procedures, snapshot);
    const result = engine.calculateEstimate(request);

    // Cleaning: 150 (100%)
    expect(result.procedures[0].insurancePortion).toBe(150);

    // Filling: (200 - 50 deductible) * 0.80 = 120
    expect(result.procedures[1].insurancePortion).toBe(120);

    // Crown: 1200 * 0.50 = 600
    expect(result.procedures[2].insurancePortion).toBe(600);

    expect(result.summary.totalInsurancePortion).toBe(870);
    expect(result.summary.totalPatientPortion).toBe(1550); // 150 + 80 + 600 - insurance
  });

  it('Test: Green Shield estimate — verify stricter frequency rules affect estimate', () => {
    const greenShieldPlan = createTestPlan(patient.id, 'green_shield');
    const snapshot = createTestSnapshot(patient.id, greenShieldPlan.id, 0, 0);
    snapshot.claimsHistory = [
      {
        claimId: 'claim-001',
        cdtCode: 'D1110',
        dateOfService: '2025-08-01',
        amountBilled: 120,
        amountPaid: 120,
      },
    ];

    const cleaningProcedure = createProcedure('D1110', 120, '2026-04-15');
    const request = createEstimateRequest(patient, greenShieldPlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Green Shield may have different frequency rules
    // Verify estimate reflects carrier's specific rules
    expect(result.procedures[0].tier).toBe('preventive');
  });

  it('Test: Estimate with no eligibility snapshot — low confidence score', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    const cleaningProcedure = createProcedure('D1110', 150);

    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure]);
    const result = engine.calculateEstimate(request);

    // Without snapshot, confidence should be low
    expect(result.confidence.score).toBeLessThan(50);
    expect(result.confidence.level).toBe('low');
    expect(result.warnings).toContain(expect.stringContaining('low confidence'));
  });

  it('Test: Estimate with recent verified snapshot — high confidence score', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.lastVerifiedDate = '2026-04-04'; // Verified yesterday
    snapshot.source = 'carrier_lookup';

    const cleaningProcedure = createProcedure('D1110', 150);
    const request = createEstimateRequest(patient, sunLifePlan, [cleaningProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // With recent carrier verification, confidence should be high
    expect(result.confidence.score).toBeGreaterThan(75);
    expect(result.confidence.level).toBe('high');
  });
});

// ============================================================================
// === 7. COB TESTS ===
// ============================================================================

describe('COB (Coordination of Benefits) Tests', () => {
  let engine: EligibilityEngine;
  let patient: Patient;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
  });

  it('Test: Standard COB — primary pays first, secondary covers remainder up to 100%', () => {
    const primaryPlan = createTestPlan(patient.id, 'sunlife_private', true);
    const secondaryPlan = createTestPlan(patient.id, 'manulife', false);
    secondaryPlan.sequence = 2;

    const primarySnapshot = createTestSnapshot(patient.id, primaryPlan.id, 0, 0);
    const secondarySnapshot = createTestSnapshot(patient.id, secondaryPlan.id, 0, 0);

    const crownProcedure = createProcedure('D2750', 1000); // Major - $1000

    const request = createEstimateRequest(
      patient,
      primaryPlan,
      [crownProcedure],
      primarySnapshot,
      secondaryPlan,
      secondarySnapshot
    );
    const result = engine.calculateEstimate(request);

    // Primary Sun Life pays 50% = 500
    // Secondary Manulife pays up to additional 50% = 500
    // Total should not exceed 1000
    expect(result.summary.totalInsurancePortion).toBeLessThanOrEqual(1000);
    expect(result.summary.totalPatientPortion).toBeGreaterThanOrEqual(0);
  });

  it('Test: Non-duplication COB (Manulife secondary) — pays lesser of own benefit or remaining', () => {
    // Manulife uses non-duplication COB
    const primaryPlan = createTestPlan(patient.id, 'sunlife_private', true);
    const manulifePlan = createTestPlan(patient.id, 'manulife', false);
    manulifePlan.sequence = 2;

    const primarySnapshot = createTestSnapshot(patient.id, primaryPlan.id, 0, 0);
    const manulifeSnapshot = createTestSnapshot(patient.id, manulifePlan.id, 0, 0);

    const fillingProcedure = createProcedure('D2391', 300); // Basic - $300

    const request = createEstimateRequest(
      patient,
      primaryPlan,
      [fillingProcedure],
      primarySnapshot,
      manulifePlan,
      manulifeSnapshot
    );
    const result = engine.calculateEstimate(request);

    // Sun Life basic pays 80% = 240
    // Manulife non-duplication: pays lesser of (300 * 80%) or (300 - 240) = 60
    expect(result.summary.totalInsurancePortion).toBeLessThanOrEqual(300);
  });

  it('Test: Carve-out COB — secondary subtracts primary payment from own benefit', () => {
    // Some carriers use carve-out method
    const primaryPlan = createTestPlan(patient.id, 'sunlife_private', true);
    const secondaryPlan = createTestPlan(patient.id, 'great_west', false);
    secondaryPlan.sequence = 2;

    const primarySnapshot = createTestSnapshot(patient.id, primaryPlan.id, 0, 0);
    const secondarySnapshot = createTestSnapshot(patient.id, secondaryPlan.id, 0, 0);

    const crownProcedure = createProcedure('D2750', 1200);

    const request = createEstimateRequest(
      patient,
      primaryPlan,
      [crownProcedure],
      primarySnapshot,
      secondaryPlan,
      secondarySnapshot
    );
    const result = engine.calculateEstimate(request);

    // Verify COB is applied
    expect(result.assumptions).toContain(expect.stringContaining('COB'));
  });

  it('Test: Primary plan pays 100% — secondary pays nothing', () => {
    // Preventive paid at 100% by primary
    const primaryPlan = createTestPlan(patient.id, 'sunlife_private', true);
    const secondaryPlan = createTestPlan(patient.id, 'manulife', false);
    secondaryPlan.sequence = 2;

    const primarySnapshot = createTestSnapshot(patient.id, primaryPlan.id, 0, 0);
    const secondarySnapshot = createTestSnapshot(patient.id, secondaryPlan.id, 0, 0);

    const cleaningProcedure = createProcedure('D1110', 200); // Preventive - 100%

    const request = createEstimateRequest(
      patient,
      primaryPlan,
      [cleaningProcedure],
      primarySnapshot,
      secondaryPlan,
      secondarySnapshot
    );
    const result = engine.calculateEstimate(request);

    // Primary pays 100% (200), secondary has nothing left to pay
    expect(result.summary.totalInsurancePortion).toBeLessThanOrEqual(200);
  });
});

// ============================================================================
// === 8. RECONCILIATION TESTS ===
// ============================================================================

describe('Reconciliation Tests', () => {
  let patient: Patient;
  let sunLifePlan: Plan;
  let engine: EligibilityEngine;

  beforeEach(() => {
    patient = createTestPatient();
    sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    engine = createEngine();
  });

  it('Test: Perfect match — actual matches estimate exactly, no variance', () => {
    // Create an estimate first
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const fillingProcedure = createProcedure('D2391', 300);

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const estimate = engine.calculateEstimate(request);

    // Create actual payment that matches estimate
    const actualPayment: ActualClaimPayment = {
      claimId: 'claim-actual-001',
      patientId: patient.id,
      planId: sunLifePlan.id,
      carrierCode: 'sunlife_private',
      cdtCode: 'D2391',
      dateOfService: '2026-04-15',
      amountBilled: 300,
      amountPaid: estimate.procedures[0].insurancePortion,
      amountDenied: 0,
      paymentDate: '2026-04-30',
    };

    // Verify amounts match
    expect(actualPayment.amountPaid).toBe(estimate.procedures[0].insurancePortion);
  });

  it('Test: Underpayment — carrier paid less than estimated, patient balance increases', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const fillingProcedure = createProcedure('D2391', 300);

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const estimate = engine.calculateEstimate(request);

    // Carrier underpays
    const actualPayment: ActualClaimPayment = {
      claimId: 'claim-actual-002',
      patientId: patient.id,
      planId: sunLifePlan.id,
      carrierCode: 'sunlife_private',
      cdtCode: 'D2391',
      dateOfService: '2026-04-15',
      amountBilled: 300,
      amountPaid: estimate.procedures[0].insurancePortion * 0.8, // 80% of expected
      amountDenied: estimate.procedures[0].insurancePortion * 0.2,
      paymentDate: '2026-04-30',
      denialReason: 'Partial payment',
    };

    // Patient owes more
    expect(actualPayment.amountPaid).toBeLessThan(estimate.procedures[0].insurancePortion);
  });

  it('Test: Overpayment — carrier paid more than estimated, patient balance decreases', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const fillingProcedure = createProcedure('D2391', 300);

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const estimate = engine.calculateEstimate(request);

    // Carrier overpays (rare but possible)
    const actualPayment: ActualClaimPayment = {
      claimId: 'claim-actual-003',
      patientId: patient.id,
      planId: sunLifePlan.id,
      carrierCode: 'sunlife_private',
      cdtCode: 'D2391',
      dateOfService: '2026-04-15',
      amountBilled: 300,
      amountPaid: estimate.procedures[0].insurancePortion * 1.1, // 10% overpayment
      amountDenied: 0,
      paymentDate: '2026-04-30',
    };

    // Patient owes less
    expect(actualPayment.amountPaid).toBeGreaterThan(estimate.procedures[0].insurancePortion);
  });

  it('Test: Claim denied — full variance, write-off recommended', () => {
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    const fillingProcedure = createProcedure('D2391', 300);

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const estimate = engine.calculateEstimate(request);

    // Carrier denies entire claim
    const actualPayment: ActualClaimPayment = {
      claimId: 'claim-actual-denied',
      patientId: patient.id,
      planId: sunLifePlan.id,
      carrierCode: 'sunlife_private',
      cdtCode: 'D2391',
      dateOfService: '2026-04-15',
      amountBilled: 300,
      amountPaid: 0,
      amountDenied: 300,
      paymentDate: '2026-04-30',
      denialReason: 'Procedure excluded or missing documentation',
      adjustmentCodes: ['EXCL'],
    };

    // Full variance
    const variance = actualPayment.amountPaid - estimate.procedures[0].insurancePortion;
    expect(variance).toBeLessThan(0);
  });

  it('Test: Variance pattern detection — same carrier consistently underpaying', () => {
    // This test would be better implemented with multiple claims aggregated
    // For now, demonstrate underpayment pattern detection
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);

    // Multiple claims from same carrier
    const claims = [
      createProcedure('D1110', 150),
      createProcedure('D2391', 300),
      createProcedure('D2750', 1200),
    ];

    const request = createEstimateRequest(patient, sunLifePlan, claims, snapshot);
    const estimate = engine.calculateEstimate(request);

    // Simulating consistent underpayment
    let totalVariance = 0;
    for (let i = 0; i < estimate.procedures.length; i++) {
      const actualPaid = estimate.procedures[i].insurancePortion * 0.85; // 85% of expected
      totalVariance += actualPaid - estimate.procedures[i].insurancePortion;
    }

    // Negative variance indicates underpayment pattern
    expect(totalVariance).toBeLessThan(0);
  });
});

// ============================================================================
// === 9. EDGE CASES ===
// ============================================================================

describe('Edge Cases', () => {
  let engine: EligibilityEngine;
  let patient: Patient;

  beforeEach(() => {
    engine = createEngine();
    patient = createTestPatient();
  });

  it('Test: Plan terminated before service date — coverage inactive', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    sunLifePlan.terminationDate = '2026-03-31'; // Terminated before procedure

    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.isActive = false;
    snapshot.terminationDate = '2026-03-31';

    const fillingProcedure = createProcedure('D2391', 300, '2026-04-15'); // After termination

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Should have warning about inactive plan
    expect(result.warnings).toContain(expect.stringContaining('NOT active'));
  });

  it('Test: Procedure date before plan effective date — not covered', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    sunLifePlan.effectiveDate = '2026-03-01';

    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 0);
    snapshot.effectiveDate = '2026-03-01';

    // Procedure before effective date
    const fillingProcedure = createProcedure('D2391', 300, '2026-02-15');

    const request = createEstimateRequest(patient, sunLifePlan, [fillingProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Verify warning or exclusion
    expect(result.warnings.length).toBeGreaterThan(0);
  });

  it('Test: Annual max already exhausted at start of batch — all patient responsibility', () => {
    const sunLifePlan = createTestPlan(patient.id, 'sunlife_private');
    // Already used full annual max (assume 1200)
    const snapshot = createTestSnapshot(patient.id, sunLifePlan.id, 0, 1200);

    const crownProcedure = createProcedure('D2750', 1500); // Major

    const request = createEstimateRequest(patient, sunLifePlan, [crownProcedure], snapshot);
    const result = engine.calculateEstimate(request);

    // Insurance pays $0, patient pays $1500 (after deductible)
    expect(result.procedures[0].insurancePortion).toBe(0);
    expect(result.procedures[0].patientPortion).toBe(1500);
  });
});

// ============================================================================
// === INTEGRATION TESTS ===
// ============================================================================

describe('Integration Tests', () => {
  let engine: EligibilityEngine;

  beforeEach(() => {
    engine = createEngine();
  });

  it('Integration: Complex family plan scenario with multiple procedures and COB', () => {
    const spouse = createTestPatient('spouse-001');
    spouse.firstName = 'Jane';
    spouse.relationshipToSubscriber = 'spouse';

    const primaryPlan = createTestPlan(spouse.id, 'manulife', true);
    const secondaryPlan = createTestPlan(spouse.id, 'green_shield', false);
    secondaryPlan.sequence = 2;

    const primarySnapshot = createTestSnapshot(spouse.id, primaryPlan.id, 0, 0);
    const secondarySnapshot = createTestSnapshot(spouse.id, secondaryPlan.id, 0, 0);

    const complexProcedures = [
      createProcedure('D1110', 150),
      createProcedure('D2391', 500),
      createProcedure('D2750', 2000),
    ];

    const request = createEstimateRequest(
      spouse,
      primaryPlan,
      complexProcedures,
      primarySnapshot,
      secondaryPlan,
      secondarySnapshot
    );
    const result = engine.calculateEstimate(request);

    // Validate structural expectations
    expect(result.procedures.length).toBe(3);
    expect(result.summary.totalProviderFees).toBe(2650);
    expect(result.confidence.score).toBeGreaterThan(0);
    expect(result.confidence.score).toBeLessThanOrEqual(100);
  });

  it('Integration: All six carriers produce estimates', () => {
    const carriers: CarrierCode[] = [
      'sunlife_private',
      'great_west',
      'manulife',
      'green_shield',
      'rbc_insurance',
      'telus_adjudicare',
    ];

    for (const carrierCode of carriers) {
      const patient = createTestPatient(`patient-${carrierCode}`);
      const plan = createTestPlan(patient.id, carrierCode);
      const snapshot = createTestSnapshot(patient.id, plan.id, 0, 0);

      const procedures = [
        createProcedure('D1110', 150),
        createProcedure('D2391', 300),
      ];

      const request = createEstimateRequest(patient, plan, procedures, snapshot);
      const result = engine.calculateEstimate(request);

      expect(result.procedures.length).toBe(2);
      expect(result.summary.totalProviderFees).toBeGreaterThan(0);
      expect(result.confidence).toBeDefined();
    }
  });
});
