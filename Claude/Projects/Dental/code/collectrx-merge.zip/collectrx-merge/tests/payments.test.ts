/**
 * CollectRx Phase 4: Patient Payment System
 * Comprehensive Test Suite
 *
 * Tests cover:
 * - Stripe Connect account and payment management
 * - Communication delivery (SMS/Email)
 * - Reminder sequences and templates
 * - Write-off workflows and approval
 * - Payment links and transactions
 * - Patient balance calculations
 * - Full end-to-end payment flows
 *
 * All tests use realistic Canadian data (CAD currency, Canadian phone numbers)
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// TEST FIXTURES & HELPERS
// ============================================================================

/**
 * Fixture: Create a test connected account
 */
function createMockConnectedAccount(overrides = {}) {
  return {
    id: uuidv4(),
    practiceId: uuidv4(),
    stripeAccountId: 'acct_test_' + uuidv4().slice(0, 8),
    accountStatus: 'active' as const,
    chargesEnabled: true,
    payoutsEnabled: true,
    businessName: 'Maple Dental Clinic',
    email: 'practice@mapledental.ca',
    onboardingComplete: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Fixture: Create a test payment link
 */
function createMockPaymentLink(overrides = {}) {
  return {
    id: uuidv4(),
    patientId: uuidv4(),
    practiceId: uuidv4(),
    stripePaymentLinkId: 'plink_test_' + uuidv4().slice(0, 8),
    stripeSessionId: null,
    amount: 15000, // $150.00 CAD
    currency: 'cad' as const,
    description: 'Patient responsibility for crown',
    status: 'active' as const,
    lineItems: [
      {
        description: 'Crown - Tooth #14',
        amount: 15000,
        quantity: 1,
      },
    ],
    expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    paidAt: null,
    cancelledAt: null,
    metadata: {
      claimId: uuidv4(),
      insuranceCarrier: 'sunlife',
    },
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Fixture: Create a test payment transaction
 */
function createMockPaymentTransaction(overrides = {}) {
  return {
    id: uuidv4(),
    paymentLinkId: uuidv4(),
    patientId: uuidv4(),
    practiceId: uuidv4(),
    stripePaymentIntentId: 'pi_test_' + uuidv4().slice(0, 8),
    stripeChargeId: 'ch_test_' + uuidv4().slice(0, 8),
    amount: 15000, // $150.00 CAD
    currency: 'cad' as const,
    status: 'succeeded' as const,
    paymentMethod: 'card',
    receiptUrl: 'https://stripe.com/receipts/test',
    refundedAmount: 0,
    refundReason: null,
    failureCode: null,
    failureMessage: null,
    processedAt: new Date().toISOString(),
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Fixture: Create a test communication
 */
function createMockCommunication(overrides = {}) {
  return {
    id: uuidv4(),
    patientId: uuidv4(),
    practiceId: uuidv4(),
    type: 'email' as const,
    purpose: 'payment_reminder' as const,
    status: 'sent' as const,
    recipient: 'john.doe@example.com',
    subject: 'Payment Reminder from Maple Dental Clinic',
    body: 'Hi John, you have a balance of $150.00 due.',
    templateId: uuidv4(),
    paymentLinkId: null,
    sentAt: new Date().toISOString(),
    deliveredAt: new Date().toISOString(),
    openedAt: null,
    failureReason: null,
    externalId: 'sg_msg_test_' + uuidv4().slice(0, 8),
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Fixture: Create a test reminder sequence
 */
function createMockReminderSequence(overrides = {}) {
  return {
    id: uuidv4(),
    patientId: uuidv4(),
    practiceId: uuidv4(),
    paymentLinkId: uuidv4(),
    balanceAmount: 15000, // $150.00 CAD
    status: 'active' as const,
    currentStep: 0,
    steps: [
      {
        stepNumber: 1,
        type: 'email',
        delayDays: 0,
        templateId: uuidv4(),
        sent: false,
      },
      {
        stepNumber: 2,
        type: 'sms',
        delayDays: 3,
        templateId: uuidv4(),
        sent: false,
      },
      {
        stepNumber: 3,
        type: 'email',
        delayDays: 7,
        templateId: uuidv4(),
        sent: false,
      },
      {
        stepNumber: 4,
        type: 'sms',
        delayDays: 14,
        templateId: uuidv4(),
        sent: false,
      },
      {
        stepNumber: 5,
        type: 'email',
        delayDays: 30,
        templateId: uuidv4(),
        sent: false,
      },
    ],
    templateId: uuidv4(),
    startedAt: new Date().toISOString(),
    completedAt: null,
    cancelledAt: null,
    cancelReason: null,
    ...overrides,
  };
}

/**
 * Fixture: Create a test write-off
 */
function createMockWriteOff(overrides = {}) {
  return {
    id: uuidv4(),
    patientId: uuidv4(),
    practiceId: uuidv4(),
    claimId: null,
    amount: 2500, // $25.00 CAD
    reason: 'small_balance' as const,
    status: 'pending_approval' as const,
    notes: 'Rounding difference from insurance adjustment',
    requestedBy: 'staff@mapledental.ca',
    requestedAt: new Date().toISOString(),
    approvedBy: null,
    approvedAt: null,
    rejectedBy: null,
    rejectedAt: null,
    rejectionReason: null,
    reversedAt: null,
    reversalReason: null,
    ...overrides,
  };
}

/**
 * Fixture: Create a test patient balance
 */
function createMockPatientBalance(overrides = {}) {
  return {
    patientId: uuidv4(),
    practiceId: uuidv4(),
    totalOutstanding: 50000, // $500.00 CAD
    insurancePending: 25000, // $250.00 CAD
    patientResponsibility: 25000, // $250.00 CAD
    totalPaid: 10000, // $100.00 CAD
    totalWrittenOff: 2500, // $25.00 CAD
    netBalance: 12500, // $125.00 CAD (25000 - 10000 - 2500)
    lastPaymentDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    lastReminderDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    reminderSequenceId: uuidv4(),
    isInCollections: false,
    balanceAge: 45,
    updatedAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Fixture: Create a test write-off policy
 */
function createMockWriteOffPolicy(overrides = {}) {
  return {
    id: uuidv4(),
    practiceId: uuidv4(),
    autoApproveThreshold: 1000, // $10.00 CAD
    requireApprovalAbove: 1000,
    maxMonthlyTotal: 50000, // $500.00 CAD
    allowedReasons: [
      'uncollectible',
      'insurance_denial',
      'billing_error',
      'courtesy_adjustment',
      'small_balance',
      'hardship',
      'other',
    ],
    updatedAt: new Date().toISOString(),
    ...overrides,
  };
}

/**
 * Mock Canadian phone number validation
 */
function isValidCanadianPhone(phone: string): boolean {
  const canadianPhoneRegex = /^\+?1?[-.\s]?\(?[2-9]\d{2}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return canadianPhoneRegex.test(phone.replace(/\s+/g, ''));
}

// ============================================================================
// 1. STRIPE CONNECT TESTS
// ============================================================================

describe('Stripe Connect Account Management', () => {
  it('should create a connected account with valid structure', () => {
    const account = createMockConnectedAccount();

    expect(account).toHaveProperty('id');
    expect(account).toHaveProperty('practiceId');
    expect(account).toHaveProperty('stripeAccountId');
    expect(account.stripeAccountId).toMatch(/^acct_/);
    expect(account.accountStatus).toBe('active');
    expect(account.chargesEnabled).toBe(true);
    expect(account.payoutsEnabled).toBe(true);
  });

  it('should generate valid payment link with correct line items and amount', () => {
    const link = createMockPaymentLink({
      lineItems: [
        { description: 'Crown - Tooth #14', amount: 10000, quantity: 1 },
        { description: 'Core buildup', amount: 5000, quantity: 1 },
      ],
    });

    const totalAmount = link.lineItems.reduce(
      (sum, item) => sum + item.amount * item.quantity,
      0
    );

    expect(link.amount).toBe(15000);
    expect(totalAmount).toBe(link.amount);
    expect(link.currency).toBe('cad');
    expect(link.lineItems).toHaveLength(2);
  });

  it('should calculate application fee correctly (1% + Stripe fees)', () => {
    const transactionAmount = 15000; // $150.00
    const collectrxFeePercent = 0.01; // 1%
    const stripeFeePercent = 0.029; // 2.9% + $0.30 for Canadian cards
    const stripeFeeFixed = 30; // $0.30

    const collectrxFee = Math.round(transactionAmount * collectrxFeePercent);
    const stripeFee =
      Math.round(transactionAmount * stripeFeePercent) + stripeFeeFixed;
    const totalFees = collectrxFee + stripeFee;
    const netToPractice = transactionAmount - totalFees;

    expect(collectrxFee).toBe(150); // $1.50
    expect(stripeFee).toBeGreaterThan(400); // ~$4.65
    expect(netTopractice).toBe(transactionAmount - totalFees);
  });

  it('should process full refund correctly', () => {
    const transaction = createMockPaymentTransaction({
      amount: 15000,
      status: 'succeeded',
    });

    const refundAmount = transaction.amount;
    const refundedTransaction = {
      ...transaction,
      refundedAmount: refundAmount,
      status: 'refunded' as const,
      refundReason: 'patient_request',
    };

    expect(refundedTransaction.refundedAmount).toBe(transaction.amount);
    expect(refundedTransaction.status).toBe('refunded');
    expect(refundedTransaction.refundedAmount).toBeLessThanOrEqual(
      refundedTransaction.amount
    );
  });

  it('should process partial refund correctly', () => {
    const transaction = createMockPaymentTransaction({
      amount: 15000,
      status: 'succeeded',
    });

    const refundAmount = 7500; // $75.00 refund
    const refundedTransaction = {
      ...transaction,
      refundedAmount: refundAmount,
      status: 'partially_refunded' as const,
      refundReason: 'partial_service_credit',
    };

    expect(refundedTransaction.refundedAmount).toBe(7500);
    expect(refundedTransaction.status).toBe('partially_refunded');
    expect(refundedTransaction.refundedAmount).toBeLessThan(
      refundedTransaction.amount
    );
  });

  it('should handle webhook event for checkout.session.completed', () => {
    const transaction = createMockPaymentTransaction();
    const webhookPayload = {
      id: 'evt_test_' + uuidv4().slice(0, 8),
      type: 'checkout.session.completed',
      data: {
        object: {
          id: transaction.stripeSessionId,
          payment_intent: transaction.stripePaymentIntentId,
          payment_status: 'paid',
          amount_total: transaction.amount,
        },
      },
    };

    expect(webhookPayload.type).toBe('checkout.session.completed');
    expect(webhookPayload.data.object.payment_status).toBe('paid');
    expect(webhookPayload.data.object.amount_total).toBe(transaction.amount);
  });
});

// ============================================================================
// 2. COMMUNICATION TESTS
// ============================================================================

describe('Communication Delivery', () => {
  it('should send SMS with valid Canadian phone number', () => {
    const canadianPhoneNumber = '+1 (416) 555-0123';
    expect(isValidCanadianPhone(canadianPhoneNumber)).toBe(true);

    const communication = createMockCommunication({
      type: 'sms',
      recipient: canadianPhoneNumber,
      body: 'Hi John, you have a balance of $150.00 due.',
    });

    expect(communication.type).toBe('sms');
    expect(isValidCanadianPhone(communication.recipient)).toBe(true);
    expect(communication.body).toContain('$150.00');
  });

  it('should send email with valid address', () => {
    const communication = createMockCommunication({
      type: 'email',
      recipient: 'john.doe@example.com',
      subject: 'Payment Reminder from Maple Dental Clinic',
    });

    expect(communication.type).toBe('email');
    expect(communication.recipient).toMatch(
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    );
    expect(communication.subject).toBeTruthy();
  });

  it('should render template with variable substitution', () => {
    const template = {
      body: 'Hi {patientName}, you have a balance of {amount} due.',
      variables: ['patientName', 'amount'],
    };

    const variables = {
      patientName: 'John Doe',
      amount: '$150.00',
    };

    let renderedBody = template.body;
    Object.entries(variables).forEach(([key, value]) => {
      renderedBody = renderedBody.replace(`{${key}}`, String(value));
    });

    expect(renderedBody).toBe(
      'Hi John Doe, you have a balance of $150.00 due.'
    );
  });

  it('should validate invalid phone number (non-Canadian)', () => {
    const invalidPhoneNumbers = [
      '1234567890', // Missing country code
      '+1 234 5678', // Too few digits
      '+33 1 23 45 67 89', // French number
      'not-a-phone',
    ];

    invalidPhoneNumbers.forEach((phone) => {
      expect(isValidCanadianPhone(phone)).toBe(false);
    });
  });

  it('should throw error when template has missing required variables', () => {
    const template = {
      body: 'Hi {patientName}, you owe {amount} by {dueDate}.',
      variables: ['patientName', 'amount', 'dueDate'],
    };

    const incompleteVariables = {
      patientName: 'John Doe',
      amount: '$150.00',
      // dueDate is missing
    };

    const missingVars = template.variables.filter(
      (v) => !(v in incompleteVariables)
    );

    expect(missingVars).toContain('dueDate');
    expect(missingVars.length).toBeGreaterThan(0);
  });
});

// ============================================================================
// 3. REMINDER SEQUENCE TESTS
// ============================================================================

describe('Reminder Sequences', () => {
  it('should create sequence from default template with 5 steps', () => {
    const sequence = createMockReminderSequence();

    expect(sequence.status).toBe('active');
    expect(sequence.steps).toHaveLength(5);
    expect(sequence.currentStep).toBe(0);

    // Verify steps are in order with increasing delays
    let previousDelay = -1;
    sequence.steps.forEach((step) => {
      expect(step.delayDays).toBeGreaterThanOrEqual(previousDelay);
      previousDelay = step.delayDays;
    });
  });

  it('should select "Gentle" template for balance under $100', () => {
    const smallBalance = 5000; // $50.00 CAD
    const templateType =
      smallBalance < 10000 ? 'gentle' : 'urgent';

    expect(templateType).toBe('gentle');
  });

  it('should select "Urgent" template for balance over $500', () => {
    const largeBalance = 60000; // $600.00 CAD
    const templateType = largeBalance > 50000 ? 'urgent' : 'gentle';

    expect(templateType).toBe('urgent');
  });

  it('should process next step and send communication', () => {
    const sequence = createMockReminderSequence();
    const currentStep = sequence.steps[sequence.currentStep];

    const communication = createMockCommunication({
      type: currentStep.type as 'sms' | 'email',
      purpose: 'payment_reminder',
      status: 'sent',
    });

    expect(communication.type).toBe(currentStep.type);
    expect(communication.status).toBe('sent');
  });

  it('should auto-cancel sequence when balance is 0', () => {
    const sequence = createMockReminderSequence({
      status: 'active',
      balanceAmount: 0,
    });

    if (sequence.balanceAmount === 0) {
      sequence.status = 'cancelled';
      sequence.cancelReason = 'balance_paid';
    }

    expect(sequence.status).toBe('cancelled');
    expect(sequence.cancelReason).toBe('balance_paid');
  });

  it('should pause and resume sequence, recalculating dates', () => {
    const sequence = createMockReminderSequence({
      status: 'active',
    });

    // Pause
    const pausedSequence = {
      ...sequence,
      status: 'paused' as const,
    };
    expect(pausedSequence.status).toBe('paused');

    // Resume
    const resumedSequence = {
      ...pausedSequence,
      status: 'active' as const,
    };
    expect(resumedSequence.status).toBe('active');
  });

  it('should skip SMS step when patient has no phone number', () => {
    const sequence = createMockReminderSequence({
      steps: sequence.steps.map((step) => ({
        ...step,
        skipped: step.type === 'sms',
        skipReason: step.type === 'sms' ? 'no_phone_number' : null,
      })),
    });

    const smsSteps = sequence.steps.filter((s) => s.type === 'sms');
    smsSteps.forEach((step) => {
      expect(step.skipped).toBe(true);
    });
  });
});

// ============================================================================
// 4. WRITE-OFF TESTS
// ============================================================================

describe('Write-Off Management', () => {
  it('should auto-approve write-off under $10 threshold', () => {
    const policy = createMockWriteOffPolicy({
      autoApproveThreshold: 1000, // $10.00
    });

    const writeOff = createMockWriteOff({
      amount: 750, // $7.50 (under threshold)
      reason: 'small_balance',
    });

    const shouldAutoApprove =
      writeOff.amount <= policy.autoApproveThreshold;

    expect(shouldAutoApprove).toBe(true);
    if (shouldAutoApprove) {
      writeOff.status = 'approved';
      writeOff.approvedAt = new Date().toISOString();
      writeOff.approvedBy = 'system_auto';
    }

    expect(writeOff.status).toBe('approved');
  });

  it('should require approval for write-off over threshold', () => {
    const policy = createMockWriteOffPolicy({
      requireApprovalAbove: 1000, // $10.00
    });

    const writeOff = createMockWriteOff({
      amount: 2500, // $25.00 (over threshold)
      reason: 'billing_error',
      status: 'pending_approval',
    });

    const requiresApproval =
      writeOff.amount > policy.requireApprovalAbove;

    expect(requiresApproval).toBe(true);
    expect(writeOff.status).toBe('pending_approval');
    expect(writeOff.approvedBy).toBeNull();
  });

  it('should approve a pending write-off', () => {
    const writeOff = createMockWriteOff({
      status: 'pending_approval',
      approvedBy: null,
    });

    writeOff.status = 'approved';
    writeOff.approvedBy = 'manager@mapledental.ca';
    writeOff.approvedAt = new Date().toISOString();

    expect(writeOff.status).toBe('approved');
    expect(writeOff.approvedBy).toBeTruthy();
    expect(writeOff.approvedAt).toBeTruthy();
  });

  it('should reject a pending write-off', () => {
    const writeOff = createMockWriteOff({
      status: 'pending_approval',
    });

    writeOff.status = 'rejected';
    writeOff.rejectedBy = 'manager@mapledental.ca';
    writeOff.rejectedAt = new Date().toISOString();
    writeOff.rejectionReason = 'Patient should pay based on contract';

    expect(writeOff.status).toBe('rejected');
    expect(writeOff.rejectedBy).toBeTruthy();
    expect(writeOff.rejectionReason).toBeTruthy();
  });

  it('should reverse an approved write-off', () => {
    const writeOff = createMockWriteOff({
      status: 'approved',
      approvedBy: 'manager@mapledental.ca',
      approvedAt: new Date().toISOString(),
    });

    writeOff.status = 'reversed';
    writeOff.reversedAt = new Date().toISOString();
    writeOff.reversalReason = 'Payment received from patient';

    expect(writeOff.status).toBe('reversed');
    expect(writeOff.reversedAt).toBeTruthy();
  });

  it('should batch small balance write-offs', () => {
    const smallBalances = [
      createMockWriteOff({ amount: 500 }), // $5.00
      createMockWriteOff({ amount: 750 }), // $7.50
      createMockWriteOff({ amount: 300 }), // $3.00
    ];

    const policy = createMockWriteOffPolicy({
      autoApproveThreshold: 1000,
    });

    const batchApproved = smallBalances.filter(
      (wo) => wo.amount <= policy.autoApproveThreshold
    );
    const totalBatchAmount = batchApproved.reduce(
      (sum, wo) => sum + wo.amount,
      0
    );

    expect(batchApproved.length).toBe(3);
    expect(totalBatchAmount).toBe(1550); // $15.50
  });
});

// ============================================================================
// 5. PAYMENT LINK TESTS
// ============================================================================

describe('Payment Links', () => {
  it('should create payment link with line items', () => {
    const lineItems = [
      { description: 'Crown - Tooth #14', amount: 10000, quantity: 1 },
      { description: 'Core buildup', amount: 5000, quantity: 1 },
    ];

    const link = createMockPaymentLink({
      lineItems,
    });

    expect(link.lineItems).toEqual(lineItems);
    expect(link.status).toBe('active');
    expect(link.amount).toBeGreaterThan(0);
  });

  it('should expire payment link after 30 days', () => {
    const createdAt = new Date();
    const expiresAt = new Date(
      createdAt.getTime() + 30 * 24 * 60 * 60 * 1000
    );

    const link = createMockPaymentLink({
      createdAt: createdAt.toISOString(),
      expiresAt: expiresAt.toISOString(),
      status: 'active',
    });

    const isExpired = new Date() > new Date(link.expiresAt);
    expect(isExpired).toBe(false);

    // Simulate time passing
    const futureDate = new Date(
      createdAt.getTime() + 31 * 24 * 60 * 60 * 1000
    );
    const isExpiredFuture = futureDate > new Date(link.expiresAt);
    expect(isExpiredFuture).toBe(true);
  });

  it('should transition payment link status: draft → active → paid', () => {
    let link = createMockPaymentLink({
      status: 'draft',
      stripePaymentLinkId: null,
    });

    expect(link.status).toBe('draft');

    // Activate link
    link = {
      ...link,
      status: 'active',
      stripePaymentLinkId: 'plink_test_' + uuidv4().slice(0, 8),
    };
    expect(link.status).toBe('active');

    // Mark as paid
    link = {
      ...link,
      status: 'paid',
      paidAt: new Date().toISOString(),
    };
    expect(link.status).toBe('paid');
    expect(link.paidAt).toBeTruthy();
  });

  it('should verify line items sum matches total amount', () => {
    const lineItems = [
      { description: 'Crown - Tooth #14', amount: 10000, quantity: 1 },
      { description: 'Core buildup', amount: 3000, quantity: 1 },
      { description: 'Adjustment', amount: 2000, quantity: 1 },
    ];

    const calculatedTotal = lineItems.reduce(
      (sum, item) => sum + item.amount * item.quantity,
      0
    );

    const link = createMockPaymentLink({
      amount: 15000,
      lineItems,
    });

    expect(link.amount).toBe(calculatedTotal);
  });
});

// ============================================================================
// 6. PATIENT BALANCE TESTS
// ============================================================================

describe('Patient Balance Calculations', () => {
  it('should calculate net balance: responsibility - paid - written_off', () => {
    const balance = createMockPatientBalance({
      patientResponsibility: 25000, // $250.00
      totalPaid: 10000, // $100.00
      totalWrittenOff: 2500, // $25.00
      netBalance: 12500, // $250 - $100 - $25
    });

    const calculatedNet =
      balance.patientResponsibility -
      balance.totalPaid -
      balance.totalWrittenOff;

    expect(balance.netBalance).toBe(calculatedNet);
    expect(calculatedNet).toBe(12500);
  });

  it('should record payment as negative (credit) in ledger', () => {
    const ledgerEntry = {
      id: uuidv4(),
      patientId: uuidv4(),
      practiceId: uuidv4(),
      type: 'payment' as const,
      amount: -15000, // Negative = credit
      description: 'Payment received - Card',
      referenceId: uuidv4(),
      balanceAfter: 10000,
      createdAt: new Date().toISOString(),
    };

    expect(ledgerEntry.type).toBe('payment');
    expect(ledgerEntry.amount).toBeLessThan(0);
  });

  it('should record charge as positive (debit) in ledger', () => {
    const ledgerEntry = {
      id: uuidv4(),
      patientId: uuidv4(),
      practiceId: uuidv4(),
      type: 'charge' as const,
      amount: 25000, // Positive = debit
      description: 'Crown - Tooth #14',
      referenceId: uuidv4(),
      balanceAfter: 25000,
      createdAt: new Date().toISOString(),
    };

    expect(ledgerEntry.type).toBe('charge');
    expect(ledgerEntry.amount).toBeGreaterThan(0);
  });

  it('should record write-off ledger entry reducing balance', () => {
    const previousBalance = 25000;
    const writeOffAmount = 2500;

    const ledgerEntry = {
      id: uuidv4(),
      patientId: uuidv4(),
      practiceId: uuidv4(),
      type: 'write_off' as const,
      amount: -2500, // Negative = reduces balance
      description: 'Write-off: Small balance adjustment',
      referenceId: uuidv4(),
      balanceAfter: previousBalance + ledgerEntry.amount,
      createdAt: new Date().toISOString(),
    };

    expect(ledgerEntry.type).toBe('write_off');
    expect(ledgerEntry.balanceAfter).toBe(22500);
  });
});

// ============================================================================
// 7. INTEGRATION TESTS
// ============================================================================

describe('End-to-End Payment Flows', () => {
  it('should complete full flow: create link → send reminder → process payment → update balance', async () => {
    // Step 1: Create payment link
    const paymentLink = createMockPaymentLink({
      amount: 15000,
      status: 'draft',
    });
    expect(paymentLink.status).toBe('draft');

    // Step 2: Activate link and send reminder
    const activatedLink = {
      ...paymentLink,
      status: 'active',
    };
    expect(activatedLink.status).toBe('active');

    const reminderSequence = createMockReminderSequence({
      paymentLinkId: activatedLink.id,
      balanceAmount: activatedLink.amount,
    });
    expect(reminderSequence.currentStep).toBe(0);

    // Step 3: Process payment
    const transaction = createMockPaymentTransaction({
      paymentLinkId: activatedLink.id,
      amount: activatedLink.amount,
      status: 'succeeded',
    });
    expect(transaction.status).toBe('succeeded');

    // Step 4: Update payment link status
    const paidLink = {
      ...activatedLink,
      status: 'paid',
      paidAt: transaction.processedAt,
    };
    expect(paidLink.status).toBe('paid');

    // Step 5: Update patient balance
    let patientBalance = createMockPatientBalance({
      patientResponsibility: activatedLink.amount,
      totalPaid: 0,
    });
    expect(patientBalance.netBalance).toBe(activatedLink.amount);

    patientBalance = {
      ...patientBalance,
      totalPaid: transaction.amount,
      netBalance:
        patientBalance.patientResponsibility -
        transaction.amount -
        patientBalance.totalWrittenOff,
    };
    expect(patientBalance.netBalance).toBe(0);

    // Verify full flow completion
    expect(paidLink.status).toBe('paid');
    expect(transaction.status).toBe('succeeded');
    expect(patientBalance.netBalance).toBe(0);
  });

  it('should trigger reminder sequence for patient portion after reconciliation', () => {
    // Insurance reconciliation result: balance reduced
    let patientBalance = createMockPatientBalance({
      totalOutstanding: 50000,
      insurancePending: 25000,
      patientResponsibility: 25000,
      totalPaid: 0,
    });

    expect(patientBalance.patientResponsibility).toBeGreaterThan(0);

    // Trigger reminder sequence for patient responsibility
    const reminderSequence = createMockReminderSequence({
      patientId: patientBalance.patientId,
      balanceAmount: patientBalance.patientResponsibility,
      status: 'active',
    });

    expect(reminderSequence.status).toBe('active');
    expect(reminderSequence.balanceAmount).toBe(
      patientBalance.patientResponsibility
    );

    // Process first communication
    const firstStep = reminderSequence.steps[0];
    const communication = createMockCommunication({
      patientId: reminderSequence.patientId,
      type: firstStep.type as 'sms' | 'email',
      status: 'sent',
    });

    expect(communication.status).toBe('sent');
  });
});
