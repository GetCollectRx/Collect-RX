# CollectRx Phase 4 — Patient Payment Collection Handoff

## What's Built

Complete patient payment collection system via Stripe Connect with automated SMS/email reminders, write-off management, and immutable patient ledger. 8 source files, ~6,945 lines of TypeScript + SQL.

## Architecture

```
src/
  services/payments/
    types.ts                    (702 lines)  — Full type system: 35+ interfaces
    stripe-connect.ts           (625 lines)  — Stripe Connect integration
  services/communications/
    communication-service.ts    (1,020 lines) — Twilio SMS + SendGrid email
  services/reminders/
    reminder-engine.ts          (651 lines)  — Multi-step reminder workflows
  services/writeoffs/
    writeoff-service.ts         (522 lines)  — Write-off management + auto-approve
  routes/
    payments.ts                 (1,955 lines) — 29 Express endpoints
  migrations/
    payments-schema.sql         (516 lines)  — 10 tables with seed data
tests/
  payments.test.ts              (954 lines)  — 32 tests across 7 suites
```

## Stripe Connect Architecture

**Why Connect, not standard Stripe:** Standard Stripe makes CollectRx the merchant of record, creating legal/financial liability. Connect keeps each dental practice as their own merchant — funds go directly to them.

Key flows:
- `createConnectedAccount()` — Onboards practice as Stripe Express account
- `generateOnboardingLink()` — Returns Stripe-hosted onboarding URL
- `createPaymentLink()` — Creates Checkout Session with patient-facing payment page
- `processRefund()` — Full or partial refund with reason tracking
- `handleWebhookEvent()` — Processes checkout.session.completed, payment_intent.succeeded/failed, charge.refunded

**Platform fee:** 1% application fee on each transaction (configurable).

## Communication Service

Dual-channel messaging via Twilio (SMS) and SendGrid (email):
- 7 built-in templates: payment_reminder, payment_received, payment_overdue, payment_link, statement_ready, final_notice, write_off_notice
- Canadian phone validation (+1 format)
- Template variable interpolation
- Delivery tracking and stats
- Webhook handlers for delivery status updates

## Reminder Workflows

Three pre-built sequences:
| Sequence | Steps | Pattern |
|----------|-------|---------|
| Standard 30-Day | 4 steps | Day 0 email → Day 7 SMS → Day 14 email → Day 30 final notice |
| Gentle | 3 steps | Day 0 email → Day 14 email → Day 30 email |
| Urgent | 5 steps | Day 0 email+SMS → Day 3 SMS → Day 7 email → Day 14 call → Day 21 final |

`processAllDueReminders()` runs on a schedule, auto-selects appropriate template based on balance amount, and advances each patient through their sequence.

## Write-Off Management

- Auto-approve thresholds (default: $25 CAD)
- Batch small-balance write-offs
- Approval/rejection workflow with reason tracking
- Reversal capability with full audit trail
- Write-off summary reporting by period
- Every write-off creates an immutable ledger entry

## Patient Ledger

Immutable audit trail for all financial transactions:
- Charges, payments, adjustments, refunds, write-offs, reversals
- Running balance per patient
- Statement generation
- All amounts in cents (CAD)

## API Endpoints (29 total)

```
# Stripe Connect
POST   /api/payments/connect/account           — Create connected account
POST   /api/payments/connect/onboarding-link    — Generate onboarding URL
GET    /api/payments/connect/account/:practiceId — Get account status

# Payment Links
POST   /api/payments/link                       — Create payment link
GET    /api/payments/link/:linkId               — Get link details
GET    /api/payments/patient/:patientId/links   — Patient payment links

# Transactions
GET    /api/payments/transactions               — List transactions (filterable)
GET    /api/payments/transaction/:id            — Transaction details
POST   /api/payments/refund                     — Process refund

# Reminders
POST   /api/payments/reminders/sequence         — Create reminder sequence
GET    /api/payments/reminders/patient/:id       — Patient's reminder sequences
POST   /api/payments/reminders/process           — Process all due reminders
PUT    /api/payments/reminders/sequence/:id/pause — Pause sequence
PUT    /api/payments/reminders/sequence/:id/resume — Resume sequence

# Write-offs
POST   /api/payments/writeoffs                  — Create write-off
PUT    /api/payments/writeoffs/:id/approve       — Approve write-off
PUT    /api/payments/writeoffs/:id/reject        — Reject write-off
PUT    /api/payments/writeoffs/:id/reverse       — Reverse write-off
POST   /api/payments/writeoffs/batch-small       — Batch small balance write-offs
GET    /api/payments/writeoffs/summary           — Write-off summary report

# Communications
POST   /api/payments/communications/send         — Send SMS or email
GET    /api/payments/communications/patient/:id   — Patient communication history
GET    /api/payments/communications/stats         — Delivery statistics

# Patient Balances
GET    /api/payments/balances                    — All outstanding balances
GET    /api/payments/balances/patient/:id        — Patient balance + ledger
GET    /api/payments/balances/aging              — Aging summary

# Webhooks
POST   /api/payments/webhooks/stripe             — Stripe webhook handler
POST   /api/payments/webhooks/twilio             — Twilio delivery status
POST   /api/payments/webhooks/sendgrid           — SendGrid event webhook
```

## Database Schema (10 tables)

```sql
stripe_connected_accounts    — Practice Stripe Express accounts
payment_links                — Generated payment links (Checkout Sessions)
payment_transactions         — All payment events (charges, refunds, etc.)
communications               — SMS/email delivery log
communication_templates      — Reusable message templates with variables
reminder_sequences           — Active reminder workflows per patient
write_offs                   — Write-off requests with approval workflow
write_off_policies           — Auto-approve thresholds and batch rules
patient_balances             — Current outstanding balance per patient
patient_ledger               — Immutable financial transaction log
```

All amounts stored in cents (CAD). JSONB used for flexible metadata fields.

## Integration Points

- **Patient AR tab** → `GET /api/payments/balances` + `POST /api/payments/link`
- **Balances tab** → `GET /api/payments/balances/aging` + `POST /api/payments/writeoffs/batch-small`
- **Outbox tab** → `GET /api/payments/communications/patient/:id` + `POST /api/payments/communications/send`
- **Admin tab** → `POST /api/payments/connect/account` + `GET /api/payments/writeoffs/summary`
- **Reconciliation engine** → Creates patient balance entries after claim resolution
- **Cron job** → `POST /api/payments/reminders/process` (daily)

## Test Coverage

32 tests covering:
- Stripe Connect account creation (4 tests)
- Payment link generation (4 tests)
- Refund processing (3 tests)
- Communication sending (5 tests)
- Reminder sequence management (5 tests)
- Write-off workflow (6 tests)
- Patient balance/ledger (5 tests)

## Environment Variables Required

```bash
# Stripe
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PLATFORM_FEE_PERCENT=1

# Twilio
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM_NUMBER=+1...

# SendGrid
SENDGRID_API_KEY=SG...
SENDGRID_FROM_EMAIL=noreply@collectrx.ca
SENDGRID_FROM_NAME=CollectRx

# Database (existing)
DATABASE_URL=postgresql://...
```

## Setup

```bash
# Run migration (after eligibility migration)
psql $DATABASE_URL -f src/migrations/payments-schema.sql

# Mount routes (in your Express app)
import { createPaymentsRouter } from './routes/payments'
app.use(createPaymentsRouter(pool, stripeConnectService, communicationService, reminderEngine, writeOffService))

# Run tests
npx vitest tests/payments.test.ts
```

## Known Limitations (for Pilot)

- Stripe Connect onboarding requires practice to complete KYC on Stripe's hosted page
- SMS delivery to Canadian numbers needs Twilio Canadian number provisioning
- Reminder cron job needs external scheduler (Railway cron or node-cron)
- Write-off auto-approve threshold is per-practice but defaults to $25 — may need tuning
- Patient ledger doesn't yet integrate with accounting export (QuickBooks, Xero)
- No patient portal — patients receive payment links via SMS/email only

## What's Complete (All 4 Phases)

| Phase | Scope | Files | Lines |
|-------|-------|-------|-------|
| 1-2 | Electron shell + React UI | 28 | ~5,300 |
| 3 | Eligibility engine + rules | 11 | ~7,600 |
| 4 | Patient payments + reminders | 8 | ~6,945 |
| **Total** | **Full platform** | **47** | **~19,845** |
