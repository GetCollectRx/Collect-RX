-- ============================================================================
-- CollectRx Eligibility Schema Migration
-- ============================================================================
--
-- Creates the complete database schema for the eligibility engine,
-- including plans, eligibility snapshots, estimates, reconciliations,
-- and carrier configurations.
--
-- This migration assumes the 'patients' table already exists (created in Phase 1).
--
-- Run with: psql -U collectrx -d collectrx -f eligibility-schema.sql
-- ============================================================================

-- ============================================================================
-- === UP MIGRATION ===
-- ============================================================================

-- Ensure UUID extension is available
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- TABLE: plans
-- ============================================================================
-- Insurance plan enrollment records for patients.
-- A patient may have multiple plans (primary/secondary from different carriers).
--
-- Tracks:
-- - Plan identification (carrier, group number, policy details)
-- - Coverage dates (effective and termination)
-- - Plan hierarchy (isPrimary, sequence for COB determination)
-- - Verification status (when eligibility was last confirmed with carrier)
--
COMMENT ON TABLE plans IS 'Insurance plan enrollment records. One plan per patient per carrier per enrollment period.';

CREATE TABLE IF NOT EXISTS plans (
  -- Identity
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,

  -- Carrier and plan details
  carrier_code VARCHAR(50) NOT NULL,
  plan_name VARCHAR(255),
  group_number VARCHAR(100),
  policy_number VARCHAR(100),

  -- Coverage dates
  effective_date DATE NOT NULL,
  termination_date DATE,

  -- Plan classification
  plan_type VARCHAR(20) NOT NULL DEFAULT 'group' CHECK (plan_type IN ('group', 'individual')),
  is_primary BOOLEAN NOT NULL DEFAULT true,
  sequence INTEGER DEFAULT 1,

  -- Verification
  last_verified_date TIMESTAMPTZ,
  notes TEXT,

  -- Audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN plans.id IS 'Unique identifier for the plan enrollment';
COMMENT ON COLUMN plans.patient_id IS 'Foreign key to patients table';
COMMENT ON COLUMN plans.carrier_code IS 'One of: sunlife_private, great_west, manulife, green_shield, rbc_insurance, telus_adjudicare';
COMMENT ON COLUMN plans.effective_date IS 'Date coverage begins (ISO date)';
COMMENT ON COLUMN plans.is_primary IS 'True if this is the primary (first-payer) plan for COB';
COMMENT ON COLUMN plans.sequence IS 'COB sequence: 1=primary, 2=secondary, etc.';
COMMENT ON COLUMN plans.last_verified_date IS 'Last date eligibility was confirmed with carrier';

CREATE INDEX idx_plans_patient_id ON plans(patient_id);
CREATE INDEX idx_plans_carrier_code ON plans(carrier_code);
CREATE INDEX idx_plans_is_primary ON plans(is_primary);
CREATE INDEX idx_plans_effective_date ON plans(effective_date);

-- ============================================================================
-- TABLE: eligibility_snapshots
-- ============================================================================
-- Point-in-time records of a patient's coverage status and claims history.
-- Captured at the time an estimate is requested or eligibility is verified.
--
-- Tracks:
-- - Coverage effectiveness and current status
-- - Year-to-date deductible and annual maximum usage
-- - Claims history for frequency rule enforcement
-- - Verification source and confidence assessment
--
COMMENT ON TABLE eligibility_snapshots IS 'Point-in-time eligibility records capturing coverage status, deductible usage, annual max usage, and claims history.';

CREATE TABLE IF NOT EXISTS eligibility_snapshots (
  -- Identity
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  plan_id UUID NOT NULL REFERENCES plans(id) ON DELETE CASCADE,

  -- Metadata
  captured_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  source VARCHAR(50) NOT NULL CHECK (source IN ('abeldent_sync', 'carrier_lookup', 'manual_entry')),
  is_active BOOLEAN NOT NULL DEFAULT true,

  -- Coverage dates
  effective_date DATE NOT NULL,
  termination_date DATE,

  -- Year-to-date usage (dollars)
  deductible_used_individual NUMERIC(10, 2) NOT NULL DEFAULT 0,
  deductible_used_family NUMERIC(10, 2) NOT NULL DEFAULT 0,
  annual_max_used_individual NUMERIC(10, 2) NOT NULL DEFAULT 0,
  annual_max_used_family JSONB DEFAULT '{}', -- JSON for per-member or per-tier breakdown

  -- Verification and history
  last_verified_date TIMESTAMPTZ,
  claims_history JSONB DEFAULT '[]', -- Array of ClaimHistoryEntry records
  notes TEXT,

  -- Audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN eligibility_snapshots.id IS 'Unique snapshot identifier';
COMMENT ON COLUMN eligibility_snapshots.source IS 'Data source: abeldent_sync (PMS), carrier_lookup (direct verification), or manual_entry (staff)';
COMMENT ON COLUMN eligibility_snapshots.is_active IS 'True if coverage is currently active';
COMMENT ON COLUMN eligibility_snapshots.deductible_used_individual IS 'Individual deductible used this year (dollars)';
COMMENT ON COLUMN eligibility_snapshots.annual_max_used_family IS 'JSON breakdown of annual max usage by family member ID or coverage tier';
COMMENT ON COLUMN eligibility_snapshots.claims_history IS 'JSON array of claim history entries used for frequency checking';

CREATE INDEX idx_eligibility_snapshots_patient_id ON eligibility_snapshots(patient_id);
CREATE INDEX idx_eligibility_snapshots_plan_id ON eligibility_snapshots(plan_id);
CREATE INDEX idx_eligibility_snapshots_captured_at ON eligibility_snapshots(captured_at);
CREATE INDEX idx_eligibility_snapshots_is_active ON eligibility_snapshots(is_active);
CREATE INDEX idx_eligibility_snapshots_source ON eligibility_snapshots(source);

-- ============================================================================
-- TABLE: estimates
-- ============================================================================
-- Pre-treatment benefit estimates for patient treatment plans.
-- One estimate per request (may cover multiple procedures).
--
-- Persists:
-- - Full request and response payloads (as JSONB for auditability)
-- - Calculated summary totals
-- - Confidence metrics
-- - Creator and timestamp for audit trail
--
COMMENT ON TABLE estimates IS 'Pre-treatment benefit estimates. Stores both request and full result for auditability and COB comparison.';

CREATE TABLE IF NOT EXISTS estimates (
  -- Identity
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  plan_id UUID NOT NULL REFERENCES plans(id) ON DELETE SET NULL,
  carrier_code VARCHAR(50) NOT NULL,

  -- Full request/response
  request_data JSONB NOT NULL, -- Full EstimateRequest
  result_data JSONB NOT NULL,  -- Full EstimateResult

  -- Summary totals (denormalized for quick queries)
  total_provider_fees NUMERIC(10, 2),
  total_insurance_portion NUMERIC(10, 2),
  total_patient_portion NUMERIC(10, 2),

  -- Confidence metrics
  confidence_score INTEGER, -- 0-100
  confidence_level VARCHAR(10), -- 'high', 'medium', 'low'

  -- Audit
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by VARCHAR(100)
);

COMMENT ON COLUMN estimates.id IS 'Unique estimate identifier';
COMMENT ON COLUMN estimates.request_data IS 'Full EstimateRequest as JSON for auditability';
COMMENT ON COLUMN estimates.result_data IS 'Full EstimateResult with all procedure details and assumptions';
COMMENT ON COLUMN estimates.confidence_score IS 'Confidence score 0-100 based on data freshness and source';

CREATE INDEX idx_estimates_patient_id ON estimates(patient_id);
CREATE INDEX idx_estimates_plan_id ON estimates(plan_id);
CREATE INDEX idx_estimates_carrier_code ON estimates(carrier_code);
CREATE INDEX idx_estimates_created_at ON estimates(created_at);
CREATE INDEX idx_estimates_confidence_score ON estimates(confidence_score);

-- ============================================================================
-- TABLE: reconciliations
-- ============================================================================
-- Claims reconciliation records comparing estimated vs. actual insurance payments.
-- One reconciliation per estimate (after claim is paid).
--
-- Stores:
-- - Full reconciliation results (line-item variance analysis)
-- - Summary totals and variance analysis
-- - Patient account adjustments recommended
-- - Financial impact metrics for practice reporting
--
COMMENT ON TABLE reconciliations IS 'Claim reconciliation records comparing estimates to actual insurance payments. Used for variance analysis and patient balance adjustments.';

CREATE TABLE IF NOT EXISTS reconciliations (
  -- Identity
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  estimate_id UUID NOT NULL REFERENCES estimates(id) ON DELETE CASCADE,
  patient_id UUID NOT NULL,
  carrier_code VARCHAR(50) NOT NULL,

  -- Results and summary
  results_data JSONB NOT NULL, -- Array of ReconciliationResult
  summary_data JSONB NOT NULL, -- ReconciliationSummary

  -- Summary totals (denormalized for reporting)
  total_estimated NUMERIC(10, 2),
  total_actual_paid NUMERIC(10, 2),
  total_variance NUMERIC(10, 2), -- negative = underpayment, positive = overpayment
  variance_percentage NUMERIC(5, 2), -- percentage of estimated amount

  -- Patient account impact
  total_patient_balance_change NUMERIC(10, 2), -- positive = patient owes more
  total_write_offs NUMERIC(10, 2), -- denied amount written off

  -- Audit
  reconciled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reconciled_by VARCHAR(100)
);

COMMENT ON COLUMN reconciliations.id IS 'Unique reconciliation identifier';
COMMENT ON COLUMN reconciliations.results_data IS 'Array of ReconciliationResult objects for each procedure';
COMMENT ON COLUMN reconciliations.summary_data IS 'ReconciliationSummary with variance breakdown by reason and carrier';
COMMENT ON COLUMN reconciliations.total_variance IS 'Actual paid minus estimated (negative = carrier underpaid)';
COMMENT ON COLUMN reconciliations.total_patient_balance_change IS 'How much patient balance increased/decreased from reconciliation';

CREATE INDEX idx_reconciliations_estimate_id ON reconciliations(estimate_id);
CREATE INDEX idx_reconciliations_patient_id ON reconciliations(patient_id);
CREATE INDEX idx_reconciliations_carrier_code ON reconciliations(carrier_code);
CREATE INDEX idx_reconciliations_reconciled_at ON reconciliations(reconciled_at);

-- ============================================================================
-- TABLE: carrier_plan_configs
-- ============================================================================
-- Cached carrier configurations (rules, coverage percentages, deductibles, etc.).
-- One record per carrier; updated when carrier rules change.
--
-- Stores:
-- - Complete CarrierConfig as JSONB (fully serializable)
-- - Version tracking for configuration changes
-- - Active/inactive flag for feature gating
-- - Update history (last_updated_at, updated_by)
--
COMMENT ON TABLE carrier_plan_configs IS 'Master carrier configuration rules. One row per carrier, updated when carrier policies change.';

CREATE TABLE IF NOT EXISTS carrier_plan_configs (
  -- Identity
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  carrier_code VARCHAR(50) NOT NULL UNIQUE,

  -- Configuration
  config_data JSONB NOT NULL, -- Full CarrierConfig (all rules, percentages, deductibles)
  version INTEGER NOT NULL DEFAULT 1,
  is_active BOOLEAN NOT NULL DEFAULT true,

  -- Audit
  last_updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by VARCHAR(100),
  notes TEXT
);

COMMENT ON COLUMN carrier_plan_configs.id IS 'Unique configuration record identifier';
COMMENT ON COLUMN carrier_plan_configs.carrier_code IS 'Carrier identifier (unique per carrier)';
COMMENT ON COLUMN carrier_plan_configs.config_data IS 'Full CarrierConfig JSON: coverage %, deductibles, annual max, frequency rules, waiting periods, COB method';
COMMENT ON COLUMN carrier_plan_configs.version IS 'Configuration version (incremented on updates)';

CREATE INDEX idx_carrier_plan_configs_carrier_code ON carrier_plan_configs(carrier_code);
CREATE INDEX idx_carrier_plan_configs_is_active ON carrier_plan_configs(is_active);

-- ============================================================================
-- === SEED DATA: Carrier Plan Configs ===
-- ============================================================================
-- Initialize the 6 supported Canadian carriers with their standard rules.
-- These are placeholder configurations; update with actual carrier rules.

INSERT INTO carrier_plan_configs (carrier_code, config_data, version, is_active, updated_by, notes)
VALUES
  (
    'sunlife_private',
    '{
      "code": "sunlife_private",
      "name": "Sun Life Private",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 80,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 80,
        "periodontic": 80,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 50,
        "family": 150,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": true
      },
      "annualMax": {
        "individual": 1200,
        "familyMax": 3600,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "standard",
      "notes": ["Sun Life standard group plan"]
    }',
    1,
    true,
    'system',
    'Standard Sun Life Private plan configuration'
  ),
  (
    'great_west',
    '{
      "code": "great_west",
      "name": "Great-West Life",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 75,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 75,
        "periodontic": 75,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 75,
        "family": 200,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": true
      },
      "annualMax": {
        "individual": 1500,
        "familyMax": 4500,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "non_duplication",
      "notes": ["Great-West standard plan", "Uses non-duplication COB"]
    }',
    1,
    true,
    'system',
    'Standard Great-West Life plan configuration'
  ),
  (
    'manulife',
    '{
      "code": "manulife",
      "name": "Manulife Financial",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 80,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 80,
        "periodontic": 80,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 50,
        "family": 150,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": false
      },
      "annualMax": {
        "individual": 1200,
        "familyMax": 3600,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "standard",
      "notes": ["Manulife standard plan", "Family deductible is aggregate"]
    }',
    1,
    true,
    'system',
    'Standard Manulife plan configuration'
  ),
  (
    'green_shield',
    '{
      "code": "green_shield",
      "name": "Green Shield Canada",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 70,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 70,
        "periodontic": 70,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 100,
        "family": 300,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": true
      },
      "annualMax": {
        "individual": 1000,
        "familyMax": 3000,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "carve_out",
      "notes": ["Green Shield standard plan", "Uses carve-out COB method"]
    }',
    1,
    true,
    'system',
    'Standard Green Shield plan configuration'
  ),
  (
    'rbc_insurance',
    '{
      "code": "rbc_insurance",
      "name": "RBC Insurance",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 80,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 80,
        "periodontic": 80,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 50,
        "family": 150,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": true
      },
      "annualMax": {
        "individual": 1200,
        "familyMax": 3600,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "standard",
      "notes": ["RBC Insurance standard plan"]
    }',
    1,
    true,
    'system',
    'Standard RBC Insurance plan configuration'
  ),
  (
    'telus_adjudicare',
    '{
      "code": "telus_adjudicare",
      "name": "Telus Adjudicare",
      "coveragePercentages": {
        "preventive": 100,
        "basic": 75,
        "major": 50,
        "orthodontic": 50,
        "endodontic": 75,
        "periodontic": 75,
        "prosthodontic": 50
      },
      "deductible": {
        "individual": 60,
        "family": 180,
        "waiveForPreventive": true,
        "appliesToTiers": ["basic", "major", "endodontic", "periodontic", "prosthodontic"],
        "perMember": true
      },
      "annualMax": {
        "individual": 1200,
        "familyMax": 3600,
        "includesPreventive": false
      },
      "frequencyRules": [],
      "waitingPeriods": [],
      "cobMethod": "standard",
      "notes": ["Telus Adjudicare standard plan"]
    }',
    1,
    true,
    'system',
    'Standard Telus Adjudicare plan configuration'
  )
ON CONFLICT (carrier_code) DO NOTHING;

-- ============================================================================
-- === DOWN MIGRATION ===
-- ============================================================================
-- To rollback this migration, run:
--
-- DROP TABLE IF EXISTS reconciliations;
-- DROP TABLE IF EXISTS estimates;
-- DROP TABLE IF EXISTS eligibility_snapshots;
-- DROP TABLE IF EXISTS carrier_plan_configs;
-- DROP TABLE IF EXISTS plans;
-- DROP EXTENSION IF EXISTS "uuid-ossp";
--
-- ============================================================================
