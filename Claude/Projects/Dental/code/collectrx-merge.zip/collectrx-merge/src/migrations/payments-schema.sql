-- ============================================================================
-- CollectRx Phase 4: Patient Payment System
-- PostgreSQL Schema Migration
-- ============================================================================
--
-- This migration creates the complete schema for the patient payment collection
-- system, including Stripe Connect integration, payment processing, communications,
-- reminder sequences, and financial write-offs.
--
-- All amounts are stored in cents (CAD) for precision in financial calculations.
-- The practice is the merchant of record via Stripe Connect.
--
-- Created: 2026-04-05
-- ============================================================================

BEGIN;

-- ============================================================================
-- STRIPE CONNECTED ACCOUNTS TABLE
-- ============================================================================
-- Stores Stripe Connect Express account details for each dental practice.
-- The practice is the merchant of record where patient payments flow through.

CREATE TABLE stripe_connected_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id UUID NOT NULL UNIQUE,
  stripe_account_id VARCHAR(255) NOT NULL UNIQUE,
  account_status VARCHAR(20) DEFAULT 'pending' NOT NULL,
  charges_enabled BOOLEAN DEFAULT false,
  payouts_enabled BOOLEAN DEFAULT false,
  business_name VARCHAR(255),
  email VARCHAR(255),
  onboarding_complete BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT account_status_check CHECK (account_status IN ('pending', 'active', 'restricted', 'disabled'))
);

CREATE INDEX idx_stripe_accounts_practice_id ON stripe_connected_accounts(practice_id);
CREATE INDEX idx_stripe_accounts_stripe_id ON stripe_connected_accounts(stripe_account_id);
CREATE INDEX idx_stripe_accounts_status ON stripe_connected_accounts(account_status);

COMMENT ON TABLE stripe_connected_accounts IS 'Stripe Connect Express accounts for dental practices as merchants of record';
COMMENT ON COLUMN stripe_connected_accounts.stripe_account_id IS 'Stripe account ID (format: acct_xxxxx)';
COMMENT ON COLUMN stripe_connected_accounts.account_status IS 'Onboarding/account status: pending, active, restricted, disabled';

-- ============================================================================
-- PAYMENT LINKS TABLE
-- ============================================================================
-- Represents payment collection links sent to patients via email/SMS.
-- Links can be in draft (not sent), active (sent and valid), paid, expired, or cancelled.

CREATE TABLE payment_links (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  stripe_payment_link_id VARCHAR(255),
  stripe_session_id VARCHAR(255),
  amount INTEGER NOT NULL,
  currency VARCHAR(3) DEFAULT 'cad' NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'draft' NOT NULL,
  line_items JSONB DEFAULT '[]'::jsonb,
  expires_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT status_check CHECK (status IN ('draft', 'active', 'paid', 'expired', 'cancelled')),
  CONSTRAINT amount_positive CHECK (amount > 0)
);

CREATE INDEX idx_payment_links_patient_id ON payment_links(patient_id);
CREATE INDEX idx_payment_links_practice_id ON payment_links(practice_id);
CREATE INDEX idx_payment_links_status ON payment_links(status);
CREATE INDEX idx_payment_links_created_at ON payment_links(created_at);
CREATE INDEX idx_payment_links_stripe_link_id ON payment_links(stripe_payment_link_id);

COMMENT ON TABLE payment_links IS 'Payment collection links sent to patients for outstanding balances';
COMMENT ON COLUMN payment_links.amount IS 'Total payment amount in cents CAD';
COMMENT ON COLUMN payment_links.line_items IS 'JSON array of service line items included in this payment';

-- ============================================================================
-- PAYMENT TRANSACTIONS TABLE
-- ============================================================================
-- Records individual payment transactions processed through Stripe.
-- Tracks payment intent, charges, refunds, and failure details.

CREATE TABLE payment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_link_id UUID REFERENCES payment_links(id),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  stripe_payment_intent_id VARCHAR(255),
  stripe_charge_id VARCHAR(255),
  amount INTEGER NOT NULL,
  currency VARCHAR(3) DEFAULT 'cad' NOT NULL,
  status VARCHAR(30) DEFAULT 'pending' NOT NULL,
  payment_method VARCHAR(20),
  receipt_url TEXT,
  refunded_amount INTEGER DEFAULT 0,
  refund_reason TEXT,
  failure_code VARCHAR(100),
  failure_message TEXT,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT status_check CHECK (status IN ('pending', 'processing', 'succeeded', 'failed', 'refunded', 'partially_refunded', 'disputed')),
  CONSTRAINT amount_positive CHECK (amount > 0),
  CONSTRAINT refunded_amount_check CHECK (refunded_amount >= 0 AND refunded_amount <= amount)
);

CREATE INDEX idx_payment_transactions_patient_id ON payment_transactions(patient_id);
CREATE INDEX idx_payment_transactions_practice_id ON payment_transactions(practice_id);
CREATE INDEX idx_payment_transactions_status ON payment_transactions(status);
CREATE INDEX idx_payment_transactions_created_at ON payment_transactions(created_at);
CREATE INDEX idx_payment_transactions_stripe_intent ON payment_transactions(stripe_payment_intent_id);
CREATE INDEX idx_payment_transactions_payment_link_id ON payment_transactions(payment_link_id);

COMMENT ON TABLE payment_transactions IS 'Individual payment transactions processed through Stripe Connect';
COMMENT ON COLUMN payment_transactions.amount IS 'Transaction amount in cents CAD';
COMMENT ON COLUMN payment_transactions.refunded_amount IS 'Refunded portion in cents CAD';

-- ============================================================================
-- COMMUNICATIONS TABLE
-- ============================================================================
-- Logs all SMS and email communications sent to patients.
-- Tracks delivery status, engagement (opened/clicked), and failures.

CREATE TABLE communications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  type VARCHAR(10) NOT NULL,
  purpose VARCHAR(30) NOT NULL,
  status VARCHAR(20) DEFAULT 'queued' NOT NULL,
  recipient VARCHAR(255) NOT NULL,
  subject VARCHAR(500),
  body TEXT NOT NULL,
  template_id UUID,
  payment_link_id UUID REFERENCES payment_links(id),
  sent_at TIMESTAMPTZ,
  delivered_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  failure_reason TEXT,
  external_id VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT type_check CHECK (type IN ('sms', 'email')),
  CONSTRAINT purpose_check CHECK (purpose IN ('payment_reminder', 'payment_receipt', 'payment_link', 'statement', 'collection_notice')),
  CONSTRAINT status_check CHECK (status IN ('queued', 'sent', 'delivered', 'failed', 'bounced', 'opened', 'clicked'))
);

CREATE INDEX idx_communications_patient_id ON communications(patient_id);
CREATE INDEX idx_communications_practice_id ON communications(practice_id);
CREATE INDEX idx_communications_status ON communications(status);
CREATE INDEX idx_communications_type ON communications(type);
CREATE INDEX idx_communications_purpose ON communications(purpose);
CREATE INDEX idx_communications_created_at ON communications(created_at);
CREATE INDEX idx_communications_external_id ON communications(external_id);

COMMENT ON TABLE communications IS 'All SMS and email communications sent to patients for payment collection';
COMMENT ON COLUMN communications.external_id IS 'Twilio SID for SMS or SendGrid message ID for email';
COMMENT ON COLUMN communications.opened_at IS 'Timestamp when recipient opened email (email tracking)';

-- ============================================================================
-- COMMUNICATION TEMPLATES TABLE
-- ============================================================================
-- Reusable message templates for different communication types and purposes.
-- Supports variable substitution for personalization.

CREATE TABLE communication_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id UUID,
  name VARCHAR(100) NOT NULL,
  type VARCHAR(10) NOT NULL,
  purpose VARCHAR(30) NOT NULL,
  subject VARCHAR(500),
  body TEXT NOT NULL,
  variables JSONB DEFAULT '[]'::jsonb,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT type_check CHECK (type IN ('sms', 'email')),
  CONSTRAINT purpose_check CHECK (purpose IN ('payment_reminder', 'payment_receipt', 'payment_link', 'statement', 'collection_notice'))
);

CREATE INDEX idx_comm_templates_practice_id ON communication_templates(practice_id);
CREATE INDEX idx_comm_templates_purpose ON communication_templates(purpose);
CREATE INDEX idx_comm_templates_type ON communication_templates(type);
CREATE INDEX idx_comm_templates_is_active ON communication_templates(is_active);

COMMENT ON TABLE communication_templates IS 'Reusable templates for SMS and email communications';
COMMENT ON COLUMN communication_templates.variables IS 'JSON array of variable names that can be substituted: e.g., ["{patientName}", "{amount}", "{dueDate}"]';

-- ============================================================================
-- REMINDER SEQUENCES TABLE
-- ============================================================================
-- Automated multi-step reminder sequences for patients with outstanding balances.
-- Manages escalating communications over time based on selected template.

CREATE TABLE reminder_sequences (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  payment_link_id UUID REFERENCES payment_links(id),
  balance_amount INTEGER NOT NULL,
  status VARCHAR(20) DEFAULT 'active' NOT NULL,
  current_step INTEGER DEFAULT 0,
  steps JSONB NOT NULL DEFAULT '[]'::jsonb,
  template_id UUID,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ,
  cancelled_at TIMESTAMPTZ,
  cancel_reason TEXT,

  CONSTRAINT status_check CHECK (status IN ('active', 'paused', 'completed', 'cancelled')),
  CONSTRAINT balance_positive CHECK (balance_amount > 0),
  CONSTRAINT step_non_negative CHECK (current_step >= 0)
);

CREATE INDEX idx_reminder_sequences_patient_id ON reminder_sequences(patient_id);
CREATE INDEX idx_reminder_sequences_practice_id ON reminder_sequences(practice_id);
CREATE INDEX idx_reminder_sequences_status ON reminder_sequences(status);
CREATE INDEX idx_reminder_sequences_started_at ON reminder_sequences(started_at);

COMMENT ON TABLE reminder_sequences IS 'Multi-step reminder sequences for escalating patient payment collection';
COMMENT ON COLUMN reminder_sequences.balance_amount IS 'Patient responsibility amount in cents CAD when sequence started';
COMMENT ON COLUMN reminder_sequences.steps IS 'JSON array of ReminderStep objects with timing and communication details';

-- ============================================================================
-- WRITE-OFFS TABLE
-- ============================================================================
-- Records all write-off requests with approval workflow tracking.
-- Supports auto-approval for small balances and explicit approval for larger amounts.

CREATE TABLE write_offs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  claim_id UUID,
  amount INTEGER NOT NULL,
  reason VARCHAR(30) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending_approval' NOT NULL,
  notes TEXT,
  requested_by VARCHAR(100) NOT NULL,
  requested_at TIMESTAMPTZ DEFAULT NOW(),
  approved_by VARCHAR(100),
  approved_at TIMESTAMPTZ,
  rejected_by VARCHAR(100),
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  reversed_at TIMESTAMPTZ,
  reversal_reason TEXT,

  CONSTRAINT amount_positive CHECK (amount > 0),
  CONSTRAINT reason_check CHECK (reason IN ('uncollectible', 'insurance_denial', 'billing_error', 'courtesy_adjustment', 'small_balance', 'hardship', 'other')),
  CONSTRAINT status_check CHECK (status IN ('pending_approval', 'approved', 'rejected', 'reversed'))
);

CREATE INDEX idx_write_offs_patient_id ON write_offs(patient_id);
CREATE INDEX idx_write_offs_practice_id ON write_offs(practice_id);
CREATE INDEX idx_write_offs_status ON write_offs(status);
CREATE INDEX idx_write_offs_reason ON write_offs(reason);
CREATE INDEX idx_write_offs_requested_at ON write_offs(requested_at);

COMMENT ON TABLE write_offs IS 'Write-off requests with approval workflow tracking';
COMMENT ON COLUMN write_offs.amount IS 'Write-off amount in cents CAD';
COMMENT ON COLUMN write_offs.claim_id IS 'Reference to associated insurance claim if applicable';

-- ============================================================================
-- WRITE-OFF POLICIES TABLE
-- ============================================================================
-- Configurable policies for automatic approval and limits on write-offs.
-- One policy per practice determines approval thresholds and allowed reasons.

CREATE TABLE write_off_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id UUID NOT NULL UNIQUE,
  auto_approve_threshold INTEGER DEFAULT 1000,
  require_approval_above INTEGER DEFAULT 1000,
  max_monthly_total INTEGER,
  allowed_reasons JSONB DEFAULT '["uncollectible", "insurance_denial", "billing_error", "courtesy_adjustment", "small_balance", "hardship", "other"]'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT auto_approve_positive CHECK (auto_approve_threshold >= 0),
  CONSTRAINT require_approval_positive CHECK (require_approval_above >= 0),
  CONSTRAINT monthly_total_positive CHECK (max_monthly_total IS NULL OR max_monthly_total > 0)
);

CREATE INDEX idx_write_off_policies_practice_id ON write_off_policies(practice_id);

COMMENT ON TABLE write_off_policies IS 'Practice-specific policies governing automatic write-off approval';
COMMENT ON COLUMN write_off_policies.auto_approve_threshold IS 'Amount in cents CAD below which write-offs are automatically approved';
COMMENT ON COLUMN write_off_policies.allowed_reasons IS 'JSON array of allowed write-off reasons for this practice';

-- ============================================================================
-- PATIENT BALANCES TABLE (Materialized View or Denormalized Table)
-- ============================================================================
-- Denormalized view of current patient balances for efficient querying.
-- Updated by transactions, payments, and write-offs.

CREATE TABLE patient_balances (
  patient_id UUID PRIMARY KEY,
  practice_id UUID NOT NULL,
  total_outstanding INTEGER DEFAULT 0,
  insurance_pending INTEGER DEFAULT 0,
  patient_responsibility INTEGER DEFAULT 0,
  total_paid INTEGER DEFAULT 0,
  total_written_off INTEGER DEFAULT 0,
  net_balance INTEGER DEFAULT 0,
  last_payment_date TIMESTAMPTZ,
  last_reminder_date TIMESTAMPTZ,
  reminder_sequence_id UUID,
  is_in_collections BOOLEAN DEFAULT false,
  balance_age INTEGER DEFAULT 0,
  updated_at TIMESTAMPTZ DEFAULT NOW(),

  CONSTRAINT all_amounts_non_negative CHECK (
    total_outstanding >= 0 AND
    insurance_pending >= 0 AND
    patient_responsibility >= 0 AND
    total_paid >= 0 AND
    total_written_off >= 0
  )
);

CREATE INDEX idx_patient_balances_practice_id ON patient_balances(practice_id);
CREATE INDEX idx_patient_balances_net_balance ON patient_balances(net_balance);
CREATE INDEX idx_patient_balances_is_in_collections ON patient_balances(is_in_collections);
CREATE INDEX idx_patient_balances_balance_age ON patient_balances(balance_age);

COMMENT ON TABLE patient_balances IS 'Denormalized current balance summary for each patient';
COMMENT ON COLUMN patient_balances.total_outstanding IS 'Total charges not yet paid or written off in cents CAD';
COMMENT ON COLUMN patient_balances.patient_responsibility IS 'Patient portion (after insurance) in cents CAD';
COMMENT ON COLUMN patient_balances.net_balance IS 'patient_responsibility - total_paid - total_written_off';
COMMENT ON COLUMN patient_balances.balance_age IS 'Days since oldest unpaid charge';

-- ============================================================================
-- PATIENT LEDGER TABLE
-- ============================================================================
-- Complete audit trail of all financial transactions for a patient.
-- Supports charges, payments, adjustments, write-offs, refunds, insurance payments.

CREATE TABLE patient_ledger (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL,
  practice_id UUID NOT NULL,
  type VARCHAR(20) NOT NULL,
  amount INTEGER NOT NULL,
  description TEXT NOT NULL,
  reference_id UUID,
  balance_after INTEGER NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by VARCHAR(100),

  CONSTRAINT type_check CHECK (type IN ('charge', 'payment', 'adjustment', 'write_off', 'refund', 'insurance_payment'))
);

CREATE INDEX idx_patient_ledger_patient_id ON patient_ledger(patient_id);
CREATE INDEX idx_patient_ledger_practice_id ON patient_ledger(practice_id);
CREATE INDEX idx_patient_ledger_type ON patient_ledger(type);
CREATE INDEX idx_patient_ledger_created_at ON patient_ledger(created_at);

COMMENT ON TABLE patient_ledger IS 'Complete audit trail of all patient financial transactions';
COMMENT ON COLUMN patient_ledger.amount IS 'Transaction amount in cents CAD (positive=debit/charge, negative=credit/payment)';
COMMENT ON COLUMN patient_ledger.balance_after IS 'Running balance after this transaction in cents CAD';
COMMENT ON COLUMN patient_ledger.reference_id IS 'Links to payment_link, payment_transaction, write_off, or claim ID depending on type';

-- ============================================================================
-- DEFAULT COMMUNICATION TEMPLATES (SEED DATA)
-- ============================================================================
-- 7 default templates covering common payment communication scenarios

INSERT INTO communication_templates (name, type, purpose, subject, body, variables, is_active)
VALUES
  (
    'Gentle Payment Reminder - SMS',
    'sms',
    'payment_reminder',
    NULL,
    'Hi {patientName}, we have a small balance of {amount} due for your recent visit. Would you like to pay now? Reply STOP to unsubscribe.',
    '["patientName", "amount"]'::jsonb,
    true
  ),
  (
    'Gentle Payment Reminder - Email',
    'email',
    'payment_reminder',
    'Friendly Payment Reminder from {practiceName}',
    'Dear {patientName},

We hope you''re doing well! We wanted to follow up on a small outstanding balance from your recent visit:

Amount Due: {amount}
Due Date: {dueDate}

If you''ve already made this payment, please disregard this message. Otherwise, you can pay securely here: {paymentLink}

Thank you!',
    '["patientName", "practiceName", "amount", "dueDate", "paymentLink"]'::jsonb,
    true
  ),
  (
    'Payment Receipt - Email',
    'email',
    'payment_receipt',
    'Payment Receipt from {practiceName}',
    'Dear {patientName},

Thank you for your payment! Here are your receipt details:

Amount Paid: {amount}
Date: {paymentDate}
Reference: {transactionId}

Your new balance: {newBalance}

Questions? Contact us anytime.',
    '["patientName", "practiceName", "amount", "paymentDate", "transactionId", "newBalance"]'::jsonb,
    true
  ),
  (
    'Urgent Payment Notice - SMS',
    'sms',
    'collection_notice',
    NULL,
    'URGENT: Your balance of {amount} is now {daysOverdue} days overdue. Contact us immediately: {phoneNumber}',
    '["amount", "daysOverdue", "phoneNumber"]'::jsonb,
    true
  ),
  (
    'Urgent Payment Notice - Email',
    'email',
    'collection_notice',
    'URGENT: Outstanding Balance Notice',
    'Dear {patientName},

Your account has an outstanding balance that requires immediate attention:

Amount Due: {amount}
Days Overdue: {daysOverdue}

Please pay within 5 business days to avoid further collection action. Click here to pay: {paymentLink}

Contact us: {phoneNumber} or {email}',
    '["patientName", "amount", "daysOverdue", "paymentLink", "phoneNumber", "email"]'::jsonb,
    true
  ),
  (
    'Payment Link - SMS',
    'sms',
    'payment_link',
    NULL,
    '{patientName}, we''ve sent a secure payment link for your {amount} balance. Tap here: {paymentLink}',
    '["patientName", "amount", "paymentLink"]'::jsonb,
    true
  ),
  (
    'Statement - Email',
    'email',
    'statement',
    'Account Statement from {practiceName}',
    'Dear {patientName},

Here''s your current account statement:

Total Due: {totalDue}
Insurance Pending: {insurancePending}
Your Responsibility: {patientResponsibility}

View your full statement: {statementLink}

Thank you for your business!',
    '["patientName", "practiceName", "totalDue", "insurancePending", "patientResponsibility", "statementLink"]'::jsonb,
    true
  );

-- ============================================================================
-- DEFAULT WRITE-OFF POLICY (SEED DATA)
-- ============================================================================
-- Default policy: auto-approve write-offs under $10 (1000 cents)

INSERT INTO write_off_policies (practice_id, auto_approve_threshold, require_approval_above, max_monthly_total, allowed_reasons)
VALUES
  (
    NULL,
    1000,
    1000,
    50000,
    '["uncollectible", "insurance_denial", "billing_error", "courtesy_adjustment", "small_balance", "hardship", "other"]'::jsonb
  );

COMMIT;

-- ============================================================================
-- DOWN MIGRATION
-- ============================================================================
-- This section is commented out and should be placed in a separate down migration file.
--
-- BEGIN;
--
-- DROP TABLE IF EXISTS patient_ledger CASCADE;
-- DROP TABLE IF EXISTS patient_balances CASCADE;
-- DROP TABLE IF EXISTS write_off_policies CASCADE;
-- DROP TABLE IF EXISTS write_offs CASCADE;
-- DROP TABLE IF EXISTS reminder_sequences CASCADE;
-- DROP TABLE IF EXISTS communication_templates CASCADE;
-- DROP TABLE IF EXISTS communications CASCADE;
-- DROP TABLE IF EXISTS payment_transactions CASCADE;
-- DROP TABLE IF EXISTS payment_links CASCADE;
-- DROP TABLE IF EXISTS stripe_connected_accounts CASCADE;
--
-- COMMIT;
