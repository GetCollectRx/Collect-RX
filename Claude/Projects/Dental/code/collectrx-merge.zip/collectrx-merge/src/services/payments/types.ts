/**
 * CollectRx Patient Payment System - TypeScript Types
 *
 * Comprehensive type definitions for the patient payment collection system.
 * Uses Stripe Connect where the dental practice is the merchant of record.
 * Funds are collected on behalf of the practice and transferred directly to their account.
 *
 * Financial System Note: All amounts are in cents (CAD) unless otherwise specified.
 * Precision is critical for accounting and reconciliation.
 */

// ============================================================================
// PAYMENT CORE TYPES
// ============================================================================

/**
 * Represents a connected Stripe account for a dental practice.
 * This is the merchant of record where patient payments flow through.
 * The practice owns the account; CollectRx facilitates on their behalf.
 */
export interface StripeConnectedAccount {
  /** Unique identifier in CollectRx database */
  id: string
  /** References the associated dental practice */
  practiceId: string
  /** Stripe account ID (format: acct_xxxxx) */
  stripeAccountId: string
  /** Current onboarding/account status */
  accountStatus: 'pending' | 'active' | 'restricted' | 'disabled'
  /** Whether the account can accept charges */
  chargesEnabled: boolean
  /** Whether the account can receive payouts */
  payoutsEnabled: boolean
  /** Business legal name as registered with Stripe */
  businessName: string
  /** Primary email associated with the Stripe account */
  email: string
  /** True if the practice has completed Stripe Connect onboarding */
  onboardingComplete: boolean
  /** ISO 8601 timestamp when the account was created */
  createdAt: string
  /** ISO 8601 timestamp of last update */
  updatedAt: string
}

/**
 * Status enum for payment links
 */
export type PaymentLinkStatus =
  | 'draft'      // Created but not yet sent to patient
  | 'active'     // Sent to patient, awaiting payment
  | 'paid'       // Successfully paid
  | 'expired'    // Expiration date passed without payment
  | 'cancelled'  // Manually cancelled by practice

/**
 * A line item in a payment link breakdown.
 * Maps to a specific service or claim portion the patient owes.
 */
export interface PaymentLineItem {
  /** Human-readable description of the charge (e.g., "Crown (D2750) — patient portion") */
  description: string
  /** Amount owed in cents (CAD) */
  amount: number
  /** Optional reference to the insurance claim this amount relates to */
  claimId?: string
  /** CDT code if applicable (e.g., "D2750" for crown) */
  cdtCode?: string
  /** Date of service for this line item */
  dateOfService?: string
}

/**
 * A payment link sent to a patient for collecting outstanding balance.
 * Contains all details of what the patient owes and the payment method.
 */
export interface PaymentLink {
  /** Unique identifier in CollectRx database */
  id: string
  /** The patient this link is for */
  patientId: string
  /** The dental practice requesting payment */
  practiceId: string
  /** Stripe Payment Link ID (format: plink_xxxxx), if created with Stripe API */
  stripePaymentLinkId?: string
  /** Stripe Checkout Session ID (format: cs_xxxxx), if using a session */
  stripeSessionId?: string
  /** Total amount to be paid in cents (CAD) */
  amount: number
  /** Always CAD for Canadian market */
  currency: 'cad'
  /** Summary description (e.g., "Balance for services on 2026-03-15") */
  description: string
  /** Current status of the link */
  status: PaymentLinkStatus
  /** Itemized breakdown of charges */
  lineItems: PaymentLineItem[]
  /** ISO 8601 timestamp when the link expires (if set) */
  expiresAt?: string
  /** ISO 8601 timestamp when payment was completed */
  paidAt?: string
  /** ISO 8601 timestamp when the link was cancelled */
  cancelledAt?: string
  /** ISO 8601 timestamp when the link was created */
  createdAt: string
  /** Metadata for tracking (patient info, claim references, etc.) */
  metadata: Record<string, string>
}

/**
 * Payment method type
 */
export type PaymentMethod =
  | 'card'           // Credit or debit card
  | 'bank_transfer'  // Direct bank transfer
  | 'interac'        // Interac e-Transfer (Canadian)

/**
 * Status of a payment transaction
 */
export type TransactionStatus =
  | 'pending'              // Payment initiated but not yet processed
  | 'processing'           // Currently being processed by Stripe
  | 'succeeded'            // Payment completed successfully
  | 'failed'               // Payment failed
  | 'refunded'             // Fully refunded
  | 'partially_refunded'   // Partially refunded
  | 'disputed'             // Customer disputed the charge

/**
 * A completed payment transaction.
 * Records the actual payment received from the patient.
 */
export interface PaymentTransaction {
  /** Unique identifier in CollectRx database */
  id: string
  /** The payment link that initiated this transaction */
  paymentLinkId: string
  /** The patient who made the payment */
  patientId: string
  /** The dental practice that received the payment */
  practiceId: string
  /** Stripe Payment Intent ID (format: pi_xxxxx) */
  stripePaymentIntentId: string
  /** Stripe Charge ID (format: ch_xxxxx), available after charge succeeds */
  stripeChargeId?: string
  /** Amount paid in cents (CAD) */
  amount: number
  /** Always CAD for Canadian market */
  currency: 'cad'
  /** Current status of the transaction */
  status: TransactionStatus
  /** Method used for payment */
  paymentMethod: PaymentMethod
  /** URL to the payment receipt */
  receiptUrl?: string
  /** Total amount refunded in cents (CAD) */
  refundedAmount: number
  /** Reason for refund if applicable */
  refundReason?: string
  /** Stripe failure code if payment failed */
  failureCode?: string
  /** Human-readable failure message if payment failed */
  failureMessage?: string
  /** ISO 8601 timestamp when payment was processed */
  processedAt: string
  /** ISO 8601 timestamp when the transaction record was created */
  createdAt: string
}

/**
 * Refund status enum
 */
export type RefundStatus =
  | 'pending'     // Refund requested, awaiting processing
  | 'processing'  // Refund is being processed
  | 'succeeded'   // Refund completed
  | 'failed'      // Refund failed

/**
 * Reason for requesting a refund
 */
export type RefundReason =
  | 'duplicate'           // Duplicate payment
  | 'requested_by_patient' // Patient requested
  | 'billing_error'       // Error in billing
  | 'other'               // Other reason

/**
 * A refund request for a completed payment.
 */
export interface RefundRequest {
  /** The transaction to refund */
  transactionId: string
  /** Amount to refund in cents (CAD). If omitted, refunds the full amount. */
  amount?: number
  /** Reason for the refund */
  reason: RefundReason
  /** Additional notes about the refund */
  notes: string
  /** User ID of the person requesting the refund */
  requestedBy: string
  /** ISO 8601 timestamp when refund was requested */
  requestedAt?: string
  /** Current status of the refund */
  status?: RefundStatus
  /** Stripe Refund ID (format: re_xxxxx) if processed */
  stripeRefundId?: string
}

// ============================================================================
// COMMUNICATION TYPES
// ============================================================================

/**
 * Communication channel type
 */
export type CommunicationType =
  | 'sms'   // Text message
  | 'email' // Email

/**
 * Status of a communication attempt
 */
export type CommunicationStatus =
  | 'queued'     // Waiting to be sent
  | 'sent'       // Sent to provider
  | 'delivered'  // Confirmed delivered
  | 'failed'     // Failed to send
  | 'bounced'    // Email bounced
  | 'opened'     // Email was opened
  | 'clicked'    // Link in email was clicked

/**
 * Purpose of the communication
 */
export type CommunicationPurpose =
  | 'payment_reminder'    // Reminder to pay outstanding balance
  | 'payment_receipt'     // Confirmation of payment received
  | 'payment_link'        // Initial payment link sent to patient
  | 'statement'           // Account statement/summary
  | 'collection_notice'   // Collections notice

/**
 * A sent communication (SMS or email) to a patient.
 * Records all details for compliance and audit purposes.
 */
export interface Communication {
  /** Unique identifier in CollectRx database */
  id: string
  /** The patient this communication is for */
  patientId: string
  /** The dental practice sending the communication */
  practiceId: string
  /** Type of communication (SMS or email) */
  type: CommunicationType
  /** Purpose of the communication */
  purpose: CommunicationPurpose
  /** Current status */
  status: CommunicationStatus
  /** Recipient phone number (for SMS) or email address (for email) */
  recipient: string
  /** Email subject line (email only) */
  subject?: string
  /** Message body or email content */
  body: string
  /** Template ID used to generate this communication */
  templateId?: string
  /** Payment link ID if this communication includes a payment link */
  paymentLinkId?: string
  /** ISO 8601 timestamp when the communication was sent */
  sentAt?: string
  /** ISO 8601 timestamp when delivery was confirmed */
  deliveredAt?: string
  /** ISO 8601 timestamp when the communication was opened (email only) */
  openedAt?: string
  /** Reason for failure if status is 'failed' */
  failureReason?: string
  /** External ID from provider (Twilio SID, SendGrid message ID, etc.) */
  externalId?: string
  /** ISO 8601 timestamp when the communication record was created */
  createdAt: string
}

/**
 * Template for generating communications.
 * Supports variable substitution for personalization.
 */
export interface CommunicationTemplate {
  /** Unique identifier in CollectRx database */
  id: string
  /** The dental practice this template belongs to */
  practiceId: string
  /** Human-readable template name */
  name: string
  /** Type of communication (SMS or email) */
  type: CommunicationType
  /** Purpose of this template */
  purpose: CommunicationPurpose
  /** Subject line for email templates */
  subject?: string
  /** Message/email body with {{variable}} placeholders */
  body: string
  /** List of variables used in this template (e.g., ['patientName', 'amount', 'dueDate']) */
  variables: string[]
  /** Whether this template is currently active */
  isActive: boolean
  /** ISO 8601 timestamp when the template was created */
  createdAt: string
  /** ISO 8601 timestamp when the template was last updated */
  updatedAt?: string
}

// ============================================================================
// REMINDER WORKFLOW TYPES
// ============================================================================

/**
 * Status of a reminder sequence
 */
export type ReminderSequenceStatus =
  | 'active'      // Currently running
  | 'paused'      // Temporarily paused
  | 'completed'   // All steps completed
  | 'cancelled'   // Cancelled before completion

/**
 * A single step in a reminder sequence.
 * Defines when and how to contact the patient.
 */
export interface ReminderStep {
  /** Position in the sequence (1-indexed) */
  stepNumber: number
  /** Communication type for this step */
  type: CommunicationType
  /** Purpose of this step's communication */
  purpose: CommunicationPurpose
  /** Days after the previous step (or sequence start for step 1) */
  delayDays: number
  /** Communication template to use */
  templateId: string
  /** ISO 8601 timestamp when this step is scheduled to run */
  scheduledAt?: string
  /** ISO 8601 timestamp when this step was actually sent */
  sentAt?: string
  /** Current status of this step */
  status: 'pending' | 'scheduled' | 'sent' | 'skipped' | 'failed'
  /** Reference to the Communication record if sent */
  communicationId?: string
  /** Reason if step was skipped */
  skipReason?: string
}

/**
 * A reminder sequence for collecting payment on a patient balance.
 * Automates a series of payment reminders following a defined schedule.
 */
export interface ReminderSequence {
  /** Unique identifier in CollectRx database */
  id: string
  /** The patient being reminded */
  patientId: string
  /** The dental practice initiating reminders */
  practiceId: string
  /** The payment link associated with this sequence */
  paymentLinkId: string
  /** Amount outstanding that reminders are for (in cents CAD) */
  balanceAmount: number
  /** Current status of the sequence */
  status: ReminderSequenceStatus
  /** Current step number (0 if not started) */
  currentStep: number
  /** Steps in the sequence */
  steps: ReminderStep[]
  /** ISO 8601 timestamp when the sequence started */
  startedAt: string
  /** ISO 8601 timestamp when the sequence completed */
  completedAt?: string
  /** ISO 8601 timestamp when the sequence was cancelled */
  cancelledAt?: string
  /** Reason for cancellation if applicable */
  cancelReason?: string
  /** ISO 8601 timestamp when the sequence was created */
  createdAt: string
  /** ISO 8601 timestamp when the sequence was last updated */
  updatedAt?: string
}

/**
 * Template for creating reminder sequences.
 * Defines the default workflow for collection reminders.
 */
export interface ReminderSequenceTemplate {
  /** Unique identifier in CollectRx database */
  id: string
  /** The dental practice this template belongs to */
  practiceId: string
  /** Template name (e.g., "Standard 30-day collection") */
  name: string
  /** Steps in the reminder sequence (without timestamp/status fields) */
  steps: Omit<ReminderStep, 'scheduledAt' | 'sentAt' | 'status' | 'communicationId'>[]
  /** Whether this is the default template for the practice */
  isDefault: boolean
  /** ISO 8601 timestamp when the template was created */
  createdAt: string
  /** ISO 8601 timestamp when the template was last updated */
  updatedAt?: string
}

// ============================================================================
// WRITE-OFF TYPES
// ============================================================================

/**
 * Status of a write-off request
 */
export type WriteOffStatus =
  | 'pending_approval' // Awaiting approval
  | 'approved'         // Approved and applied
  | 'rejected'         // Rejected by approver
  | 'reversed'         // Previously approved write-off that was reversed

/**
 * Reason for writing off a balance
 */
export type WriteOffReason =
  | 'uncollectible'      // Unable to collect (after collection efforts)
  | 'insurance_denial'   // Insurance denied the claim
  | 'billing_error'      // Error in billing
  | 'courtesy_adjustment' // Professional courtesy/goodwill
  | 'small_balance'      // Below cost of collection
  | 'hardship'           // Patient financial hardship
  | 'other'              // Other reason

/**
 * A write-off of patient balance.
 * Records when a practice decides a balance cannot be collected.
 */
export interface WriteOff {
  /** Unique identifier in CollectRx database */
  id: string
  /** The patient whose balance is being written off */
  patientId: string
  /** The dental practice writing off the balance */
  practiceId: string
  /** Optional reference to the insurance claim (if insurance-related) */
  claimId?: string
  /** Amount being written off in cents (CAD) */
  amount: number
  /** Reason for the write-off */
  reason: WriteOffReason
  /** Current status of the write-off */
  status: WriteOffStatus
  /** Notes providing context for the write-off */
  notes: string
  /** User ID of the person requesting the write-off */
  requestedBy: string
  /** ISO 8601 timestamp when write-off was requested */
  requestedAt: string
  /** User ID of the person who approved the write-off */
  approvedBy?: string
  /** ISO 8601 timestamp when write-off was approved */
  approvedAt?: string
  /** User ID of the person who rejected the write-off */
  rejectedBy?: string
  /** ISO 8601 timestamp when write-off was rejected */
  rejectedAt?: string
  /** Reason for rejection if applicable */
  rejectionReason?: string
  /** ISO 8601 timestamp when the write-off was reversed */
  reversedAt?: string
  /** Reason for reversal if applicable */
  reversalReason?: string
  /** ISO 8601 timestamp when the write-off record was created */
  createdAt: string
}

/**
 * Write-off policy for a dental practice.
 * Configures automatic approval thresholds and limits.
 */
export interface WriteOffPolicy {
  /** The dental practice this policy applies to */
  practiceId: string
  /** Automatically approve write-offs at or below this amount (cents CAD) */
  autoApproveThreshold: number
  /** Require manual approval for write-offs above this amount (cents CAD) */
  requireApprovalAbove: number
  /** Optional monthly cap on total write-offs (cents CAD) */
  maxMonthlyTotal?: number
  /** List of write-off reasons allowed for this practice */
  allowedReasons: WriteOffReason[]
  /** ISO 8601 timestamp when the policy was last updated */
  updatedAt: string
}

// ============================================================================
// PATIENT BALANCE TYPES
// ============================================================================

/**
 * Summary of a patient's financial standing with a practice.
 * Aggregates all charges, payments, and adjustments.
 */
export interface PatientBalance {
  /** The patient this balance is for */
  patientId: string
  /** The dental practice this balance is with */
  practiceId: string
  /** Total amount the patient owes (gross, in cents CAD) */
  totalOutstanding: number
  /** Amount awaiting insurance decision (in cents CAD) */
  insurancePending: number
  /** Confirmed amount the patient is responsible for (in cents CAD) */
  patientResponsibility: number
  /** Total amount the patient has paid (in cents CAD) */
  totalPaid: number
  /** Total amount written off (in cents CAD) */
  totalWrittenOff: number
  /** Net balance owed: patientResponsibility - totalPaid - totalWrittenOff (in cents CAD) */
  netBalance: number
  /** ISO 8601 timestamp of the most recent payment */
  lastPaymentDate?: string
  /** ISO 8601 timestamp of the most recent reminder sent */
  lastReminderDate?: string
  /** ID of the current active reminder sequence, if any */
  reminderSequenceId?: string
  /** Whether this account is currently in collections */
  isInCollections: boolean
  /** Age of the oldest unpaid charge in days */
  balanceAge: number
  /** ISO 8601 timestamp when this balance was last updated */
  updatedAt?: string
}

/**
 * Type of ledger entry
 */
export type LedgerEntryType =
  | 'charge'              // New charge (service provided)
  | 'payment'             // Patient payment received
  | 'adjustment'          // Adjustment to balance
  | 'write_off'           // Balance written off
  | 'refund'              // Refund to patient
  | 'insurance_payment'   // Insurance payment received

/**
 * A ledger entry recording a financial transaction.
 * Provides an immutable audit trail for compliance.
 */
export interface PatientLedgerEntry {
  /** Unique identifier in CollectRx database */
  id: string
  /** The patient this entry relates to */
  patientId: string
  /** The dental practice this entry relates to */
  practiceId: string
  /** Type of transaction */
  type: LedgerEntryType
  /** Amount in cents (CAD). Positive for charges, negative for payments/credits. */
  amount: number
  /** Description of the transaction */
  description: string
  /** Reference ID (claim ID, payment transaction ID, write-off ID, etc.) */
  referenceId?: string
  /** Running balance after this entry (in cents CAD) */
  balanceAfter: number
  /** ISO 8601 timestamp when the transaction occurred */
  createdAt: string
  /** User ID of the person who created this entry */
  createdBy: string
}

// ============================================================================
// API REQUEST/RESPONSE TYPES
// ============================================================================

/**
 * Request to create a new payment link
 */
export interface CreatePaymentLinkRequest {
  /** Patient to collect payment from */
  patientId: string
  /** Line items (services/charges) for the payment */
  lineItems: PaymentLineItem[]
  /** Whether to send a reminder communication immediately */
  sendReminder: boolean
  /** Type of reminder to send (SMS or email) */
  reminderType?: CommunicationType
  /** Days until the payment link expires (default: 30) */
  expiresInDays?: number
}

/**
 * Response when a payment link is created
 */
export interface CreatePaymentLinkResponse {
  /** The created payment link */
  paymentLink: PaymentLink
  /** URL the patient can visit to pay */
  url: string
  /** Communication record if a reminder was sent */
  communication?: Communication
}

/**
 * Request to process a Stripe webhook
 */
export interface ProcessWebhookRequest {
  /** Stripe webhook event (raw payload) */
  stripeEvent: any
  /** Webhook signature header from Stripe for verification */
  signature: string
}

/**
 * Comprehensive payment summary for a patient
 */
export interface PatientPaymentSummary {
  /** Patient information */
  patient: {
    id: string
    name: string
  }
  /** Current balance and financial summary */
  balance: PatientBalance
  /** Recent payments (last 10) */
  recentPayments: PaymentTransaction[]
  /** Active reminder sequences */
  activeReminders: ReminderSequence[]
  /** Pending write-off requests */
  pendingWriteOffs: WriteOff[]
  /** ISO 8601 timestamp when this summary was generated */
  generatedAt?: string
}

// ============================================================================
// STRIPE WEBHOOK EVENT TYPES
// ============================================================================

/**
 * Parsed Stripe webhook event data
 */
export interface StripeWebhookEvent {
  /** Stripe event ID */
  id: string
  /** Event type (e.g., "charge.succeeded", "charge.refunded") */
  type: string
  /** Created timestamp (Unix epoch) */
  created: number
  /** Event data */
  data: {
    object: any
    previous_attributes?: any
  }
  /** Account ID the event belongs to */
  account?: string
}

/**
 * Parsed charge data from Stripe webhook
 */
export interface StripeChargeData {
  /** Stripe charge ID */
  id: string
  /** Amount in cents */
  amount: number
  /** Currency code */
  currency: string
  /** Charge status */
  status: string
  /** Payment intent ID if applicable */
  payment_intent?: string
  /** Failure code if charge failed */
  failure_code?: string | null
  /** Failure message if charge failed */
  failure_message?: string | null
  /** Metadata (custom fields) */
  metadata: Record<string, string>
  /** Created timestamp (Unix epoch) */
  created: number
}

/**
 * Parsed refund data from Stripe webhook
 */
export interface StripeRefundData {
  /** Stripe refund ID */
  id: string
  /** Charge ID being refunded */
  charge: string
  /** Amount refunded in cents */
  amount: number
  /** Refund status */
  status: string
  /** Reason for refund */
  reason?: string | null
  /** Metadata (custom fields) */
  metadata: Record<string, string>
  /** Created timestamp (Unix epoch) */
  created: number
}
