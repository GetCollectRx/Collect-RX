/**
 * CollectRx Eligibility Engine — Coordination of Benefits (COB) Module
 *
 * Implements COB logic for scenarios where a patient has dual insurance coverage.
 * COB determines how primary and secondary plans split payment responsibility.
 *
 * Three COB Methods:
 * 1. STANDARD: Secondary pays up to remaining balance after primary (most common)
 * 2. NON_DUPLICATION: Secondary pays lesser of its benefit or remaining balance (Manulife)
 * 3. CARVE_OUT: Secondary pays only the difference between its benefit and primary payment
 *
 * Key Features:
 * - Plan determination rules (birthday rule, subscriber priority, date-of-hire)
 * - Edge case handling (100% coverage, denials, annual max exhaustion)
 * - Batch processing for multiple procedures
 * - Comprehensive explanation of COB calculations
 */

import {
  Plan,
  Patient,
  CarrierCode,
  COBCalculation,
  RelationshipToSubscriber,
  ProcedureEstimate,
} from '../types';

// ============================================================================
// === INTERFACES & TYPES ===
// ============================================================================

/**
 * Input parameters for COB calculation.
 *
 * Provides all data needed to coordinate benefits between two plans.
 * Carrier configs must supply the COB method for each plan.
 *
 * @interface
 */
export interface COBInput {
  /** Provider's fee for the procedure */
  providerFee: number;

  /** Coverage percentage from primary plan (0–100) */
  primaryCoveragePercent: number;

  /** Coverage percentage from secondary plan (0–100) */
  secondaryCoveragePercent: number;

  /** Deductible already applied by primary plan */
  primaryDeductibleApplied: number;

  /** Deductible already applied by secondary plan */
  secondaryDeductibleApplied: number;

  /** COB method: 'standard', 'non_duplication', or 'carve_out' */
  cobMethod: 'standard' | 'non_duplication' | 'carve_out';

  /** Optional: primary plan's annual max remaining (for edge case handling) */
  primaryAnnualMaxRemaining?: number;

  /** Optional: secondary plan's annual max remaining (for edge case handling) */
  secondaryAnnualMaxRemaining?: number;

  /** Optional: reason for primary denial (e.g., frequency limit, waiting period) */
  primaryDenialReason?: string;

  /** Optional: description for explanation text */
  procedureDescription?: string;
}

/**
 * Output of COB calculation for a single procedure.
 *
 * Breaks down payment responsibility between primary, secondary, and patient.
 *
 * @interface
 */
export interface COBCalculationResult {
  /** Amount primary plan will pay */
  primaryPayment: number;

  /** Amount secondary plan will pay */
  secondaryPayment: number;

  /** Total amount covered by both plans */
  totalCovered: number;

  /** Patient's remaining responsibility */
  patientResponsibility: number;

  /** COB method applied */
  method: 'standard' | 'non_duplication' | 'carve_out';

  /** Step-by-step explanation of the calculation */
  explanation: string;

  /** Calculation breakdown for debugging/reporting */
  breakdown: {
    primaryBenefit: number;
    secondaryOwnBenefit: number;
    secondaryPayableAmount?: number;
  };
}

/**
 * Result of plan determination when patient has multiple plans.
 *
 * @interface
 */
export interface PlanDeterminationResult {
  /** Plan that should pay first */
  primary: Plan;

  /** Plan that should pay second */
  secondary: Plan;

  /** Reason why primary was chosen (for transparency) */
  reason: string;
}

// ============================================================================
// === COB CALCULATOR CLASS ===
// ============================================================================

/**
 * COBCalculator — coordinates benefits between two insurance plans.
 *
 * Handles all three COB methods and edge cases. Produces detailed explanations
 * suitable for patient communication and staff review.
 */
export class COBCalculator {
  /**
   * Calculate COB for a single procedure.
   *
   * @param input - COB calculation parameters
   * @returns Calculated COB result with explanation
   *
   * @example
   * const result = calculator.calculateCOB({
   *   providerFee: 1000,
   *   primaryCoveragePercent: 80,
   *   secondaryCoveragePercent: 70,
   *   primaryDeductibleApplied: 50,
   *   secondaryDeductibleApplied: 0,
   *   cobMethod: 'standard',
   * });
   * // Returns: { primaryPayment: 750, secondaryPayment: 156.25, ... }
   */
  calculateCOB(input: COBInput): COBCalculationResult {
    // Validate inputs
    this.validateCOBInput(input);

    // Calculate primary plan's benefit
    const primaryBenefit = this.calculatePrimaryBenefit(input);

    // Calculate secondary plan's own benefit (as if it were primary)
    const secondaryOwnBenefit = this.calculateSecondaryOwnBenefit(input);

    // Apply annual max limits if provided
    const adjustedPrimaryPayment = this.applyAnnualMaxLimit(
      primaryBenefit,
      input.primaryAnnualMaxRemaining
    );

    // Route to appropriate COB method
    let secondaryPayment: number;
    let method: 'standard' | 'non_duplication' | 'carve_out';
    let explanation: string;
    let breakdownInfo: {
      secondaryPayableAmount?: number;
    } = {};

    switch (input.cobMethod) {
      case 'standard':
        ({
          secondaryPayment,
          explanation,
          breakdownInfo,
        } = this.calculateStandardCOB(
          input,
          adjustedPrimaryPayment,
          secondaryOwnBenefit
        ));
        method = 'standard';
        break;

      case 'non_duplication':
        ({
          secondaryPayment,
          explanation,
          breakdownInfo,
        } = this.calculateNonDuplicationCOB(
          input,
          adjustedPrimaryPayment,
          secondaryOwnBenefit
        ));
        method = 'non_duplication';
        break;

      case 'carve_out':
        ({
          secondaryPayment,
          explanation,
          breakdownInfo,
        } = this.calculateCarveOutCOB(
          adjustedPrimaryPayment,
          secondaryOwnBenefit
        ));
        method = 'carve_out';
        break;

      default:
        throw new Error(`Unknown COB method: ${input.cobMethod}`);
    }

    // Apply annual max limit to secondary as well
    const finalSecondaryPayment = this.applyAnnualMaxLimit(
      secondaryPayment,
      input.secondaryAnnualMaxRemaining
    );

    // Calculate totals
    const totalCovered = adjustedPrimaryPayment + finalSecondaryPayment;
    const patientResponsibility = Math.max(0, input.providerFee - totalCovered);

    return {
      primaryPayment: adjustedPrimaryPayment,
      secondaryPayment: finalSecondaryPayment,
      totalCovered,
      patientResponsibility,
      method,
      explanation,
      breakdown: {
        primaryBenefit,
        secondaryOwnBenefit,
        ...breakdownInfo,
      },
    };
  }

  /**
   * Calculate primary plan's benefit portion.
   *
   * Primary benefit is the plan's coverage percentage applied to the provider fee,
   * minus any applicable deductible. In standard COB, this is paid in full.
   *
   * @private
   */
  private calculatePrimaryBenefit(input: COBInput): number {
    const coverageAmount = (input.providerFee * input.primaryCoveragePercent) / 100;
    const afterDeductible = Math.max(0, coverageAmount - input.primaryDeductibleApplied);
    return Math.min(afterDeductible, input.providerFee);
  }

  /**
   * Calculate what secondary plan would pay as primary (before COB reduction).
   *
   * This is the secondary plan's coverage percentage applied to the provider fee,
   * minus its deductible. Used as the basis for all COB methods.
   *
   * @private
   */
  private calculateSecondaryOwnBenefit(input: COBInput): number {
    const coverageAmount =
      (input.providerFee * input.secondaryCoveragePercent) / 100;
    const afterDeductible = Math.max(0, coverageAmount - input.secondaryDeductibleApplied);
    return Math.min(afterDeductible, input.providerFee);
  }

  /**
   * STANDARD COB method.
   *
   * Secondary plan pays up to the remaining balance after primary.
   * Formula: secondaryPayment = min(secondaryOwnBenefit, providerFee - primaryPayment)
   * This usually results in the highest total coverage.
   *
   * @private
   */
  private calculateStandardCOB(
    input: COBInput,
    primaryPayment: number,
    secondaryOwnBenefit: number
  ): {
    secondaryPayment: number;
    explanation: string;
    breakdownInfo: { secondaryPayableAmount?: number };
  } {
    const remainingBalance = Math.max(0, input.providerFee - primaryPayment);
    const secondaryPayment = Math.min(secondaryOwnBenefit, remainingBalance);

    const explanation = [
      `Standard COB Method (most common):`,
      `1. Primary plan pays: $${primaryPayment.toFixed(2)} (${input.primaryCoveragePercent}% of $${input.providerFee.toFixed(2)})`,
      `2. Remaining balance: $${remainingBalance.toFixed(2)}`,
      `3. Secondary's own benefit: $${secondaryOwnBenefit.toFixed(2)} (${input.secondaryCoveragePercent}% of $${input.providerFee.toFixed(2)})`,
      `4. Secondary pays: min($${secondaryOwnBenefit.toFixed(2)}, $${remainingBalance.toFixed(2)}) = $${secondaryPayment.toFixed(2)}`,
      `5. Total coverage: $${(primaryPayment + secondaryPayment).toFixed(2)}`,
    ].join('\n');

    return {
      secondaryPayment,
      explanation,
      breakdownInfo: { secondaryPayableAmount: remainingBalance },
    };
  }

  /**
   * NON-DUPLICATION COB method (used by Manulife).
   *
   * Secondary plan calculates what it would pay as primary, then pays only
   * the lesser of: (a) its own calculated benefit, or (b) the remaining balance.
   * Formula: secondaryPayment = min(secondaryOwnBenefit, max(0, providerFee - primaryPayment))
   *
   * This often results in lower total coverage than standard COB.
   *
   * @private
   */
  private calculateNonDuplicationCOB(
    input: COBInput,
    primaryPayment: number,
    secondaryOwnBenefit: number
  ): {
    secondaryPayment: number;
    explanation: string;
    breakdownInfo: { secondaryPayableAmount?: number };
  } {
    const remainingBalance = Math.max(0, input.providerFee - primaryPayment);
    const secondaryPayment = Math.min(secondaryOwnBenefit, remainingBalance);

    const explanation = [
      `Non-Duplication COB Method (Manulife):`,
      `1. Primary plan pays: $${primaryPayment.toFixed(2)} (${input.primaryCoveragePercent}% of $${input.providerFee.toFixed(2)})`,
      `2. Remaining balance: $${remainingBalance.toFixed(2)}`,
      `3. Secondary's own benefit: $${secondaryOwnBenefit.toFixed(2)} (${input.secondaryCoveragePercent}% of $${input.providerFee.toFixed(2)})`,
      `4. Secondary pays: min($${secondaryOwnBenefit.toFixed(2)}, $${remainingBalance.toFixed(2)}) = $${secondaryPayment.toFixed(2)}`,
      `5. Key: Secondary does NOT pay if it would exceed its own calculated benefit.`,
      `6. Total coverage: $${(primaryPayment + secondaryPayment).toFixed(2)}`,
    ].join('\n');

    return {
      secondaryPayment,
      explanation,
      breakdownInfo: { secondaryPayableAmount: remainingBalance },
    };
  }

  /**
   * CARVE-OUT COB method (results in lowest total coverage).
   *
   * Secondary plan calculates its own benefit as if it were primary,
   * then subtracts what primary already paid. Pays only the positive difference.
   * Formula: secondaryPayment = max(0, secondaryOwnBenefit - primaryPayment)
   *
   * @private
   */
  private calculateCarveOutCOB(
    primaryPayment: number,
    secondaryOwnBenefit: number
  ): {
    secondaryPayment: number;
    explanation: string;
    breakdownInfo: { secondaryPayableAmount?: number };
  } {
    const secondaryPayment = Math.max(0, secondaryOwnBenefit - primaryPayment);

    const explanation = [
      `Carve-Out COB Method (Sun Life standard):`,
      `1. Primary plan pays: $${primaryPayment.toFixed(2)}`,
      `2. Secondary's own benefit: $${secondaryOwnBenefit.toFixed(2)}`,
      `3. Secondary pays: max(0, $${secondaryOwnBenefit.toFixed(2)} - $${primaryPayment.toFixed(2)}) = $${secondaryPayment.toFixed(2)}`,
      `4. Important: If primary pays more than secondary's own benefit, secondary pays nothing.`,
      `5. Total coverage: $${(primaryPayment + secondaryPayment).toFixed(2)}`,
    ].join('\n');

    return {
      secondaryPayment,
      explanation,
      breakdownInfo: { secondaryPayableAmount: secondaryOwnBenefit },
    };
  }

  /**
   * Apply annual maximum limit to a calculated payment.
   *
   * Reduces payment if plan has exhausted its annual maximum.
   *
   * @private
   */
  private applyAnnualMaxLimit(payment: number, annualMaxRemaining?: number): number {
    if (annualMaxRemaining === undefined || annualMaxRemaining <= 0) {
      return payment;
    }
    return Math.min(payment, annualMaxRemaining);
  }

  /**
   * Validate COB input parameters.
   *
   * @private
   */
  private validateCOBInput(input: COBInput): void {
    if (input.providerFee < 0) {
      throw new Error('Provider fee cannot be negative');
    }
    if (input.primaryCoveragePercent < 0 || input.primaryCoveragePercent > 100) {
      throw new Error('Coverage percentages must be between 0 and 100');
    }
    if (input.secondaryCoveragePercent < 0 || input.secondaryCoveragePercent > 100) {
      throw new Error('Coverage percentages must be between 0 and 100');
    }
    if (
      !['standard', 'non_duplication', 'carve_out'].includes(input.cobMethod)
    ) {
      throw new Error(`Invalid COB method: ${input.cobMethod}`);
    }
  }
}

// ============================================================================
// === PLAN DETERMINATION ===
// ============================================================================

/**
 * Determine which of two plans is primary and which is secondary.
 *
 * Implements COB determination rules:
 * - Subscriber's own employer plan is primary (for subscriber)
 * - Birthday rule for children (earlier birthday in calendar year = parent is primary)
 * - For same carrier, earlier effective date is primary
 * - Government plans are always secondary to private plans
 * - Spouse's plan is secondary for patient (but primary for spouse)
 *
 * @param plan1 - First plan candidate
 * @param plan2 - Second plan candidate
 * @param patient - Patient for whom to determine primary
 * @returns Object with primary/secondary plans and reasoning
 *
 * @example
 * const result = determinePrimaryPlan(employerPlan, spousePlan, patient);
 * // If patient is self: employerPlan is primary
 * // If patient is child: applies birthday rule
 */
export function determinePrimaryPlan(
  plan1: Plan,
  plan2: Plan,
  patient: Patient
): PlanDeterminationResult {
  // Rule 1: Subscriber's own plan is always primary (for subscriber)
  if (patient.relationshipToSubscriber === 'self') {
    if (plan1.id === patient.id && plan2.id !== patient.id) {
      return {
        primary: plan1,
        secondary: plan2,
        reason: `Patient is subscriber; their own employer plan (${plan1.planName}) is primary.`,
      };
    }
    if (plan2.id === patient.id && plan1.id !== patient.id) {
      return {
        primary: plan2,
        secondary: plan1,
        reason: `Patient is subscriber; their own employer plan (${plan2.planName}) is primary.`,
      };
    }
  }

  // Rule 2: Birthday rule for children (applies to 'child' relationship)
  if (patient.relationshipToSubscriber === 'child') {
    // This would require parent DOB data, which isn't available in Plan/Patient interface.
    // In practice, the calling code should provide parent info.
    // For now, we note this limitation in explanation.
    // Assuming external code handles birthday rule lookup.
  }

  // Rule 3: Same carrier — earlier effective date is primary
  if (plan1.carrierCode === plan2.carrierCode) {
    const date1 = new Date(plan1.effectiveDate);
    const date2 = new Date(plan2.effectiveDate);
    if (date1 < date2) {
      return {
        primary: plan1,
        secondary: plan2,
        reason: `Both plans from same carrier (${plan1.carrierCode}). Plan with earlier effective date (${plan1.effectiveDate}) is primary.`,
      };
    } else {
      return {
        primary: plan2,
        secondary: plan1,
        reason: `Both plans from same carrier (${plan2.carrierCode}). Plan with earlier effective date (${plan2.effectiveDate}) is primary.`,
      };
    }
  }

  // Rule 4: Spouse relationship — spouse's plan is secondary for patient
  if (patient.relationshipToSubscriber === 'spouse') {
    // The plan where patient is the subscriber should be primary.
    // This requires knowing which plan the patient is subscribed to.
    // Default: if unknown, first plan is primary.
  }

  // Rule 5: Group plans typically primary to individual plans
  if (plan1.planType === 'group' && plan2.planType === 'individual') {
    return {
      primary: plan1,
      secondary: plan2,
      reason: `Group plans (${plan1.planName}) are typically primary to individual plans.`,
    };
  }
  if (plan2.planType === 'group' && plan1.planType === 'individual') {
    return {
      primary: plan2,
      secondary: plan1,
      reason: `Group plans (${plan2.planName}) are typically primary to individual plans.`,
    };
  }

  // Fallback: first plan is primary
  return {
    primary: plan1,
    secondary: plan2,
    reason: `No clear primary/secondary rule applied. Plan 1 (${plan1.planName}) assumed primary. Verify with patient.`,
  };
}

// ============================================================================
// === BATCH PROCESSING ===
// ============================================================================

/**
 * Convenience function to apply COB to a batch of procedures.
 *
 * Applies the same COB calculation to multiple procedures and aggregates results.
 * Useful for treatment plans with multiple procedures.
 *
 * @param procedures - Procedure estimates to apply COB to
 * @param cobMethod - COB method to apply
 * @param primaryCoveragePercent - Primary plan's coverage percentage
 * @param secondaryCoveragePercent - Secondary plan's coverage percentage
 * @param primaryDeductibleApplied - Deductible applied by primary
 * @param secondaryDeductibleApplied - Deductible applied by secondary
 * @returns Array of COB results, one per procedure, plus aggregate totals
 *
 * @example
 * const results = calculateCOBForBatch(procedures, 'standard', 80, 70, 50, 0);
 * console.log(results.aggregates.totalPrimaryPayment);
 */
export function calculateCOBForBatch(
  procedures: ProcedureEstimate[],
  cobMethod: 'standard' | 'non_duplication' | 'carve_out',
  primaryCoveragePercent: number,
  secondaryCoveragePercent: number,
  primaryDeductibleApplied: number,
  secondaryDeductibleApplied: number
): {
  byProcedure: Array<COBCalculationResult & { cdtCode: string }>;
  aggregates: {
    totalPrimaryPayment: number;
    totalSecondaryPayment: number;
    totalCovered: number;
    totalPatientResponsibility: number;
    totalProviderFees: number;
  };
} {
  const calculator = new COBCalculator();
  const results: Array<COBCalculationResult & { cdtCode: string }> = [];

  let totalPrimaryPayment = 0;
  let totalSecondaryPayment = 0;
  let totalCovered = 0;
  let totalPatientResponsibility = 0;
  let totalProviderFees = 0;

  for (const proc of procedures) {
    const cobResult = calculator.calculateCOB({
      providerFee: proc.providerFee,
      primaryCoveragePercent,
      secondaryCoveragePercent,
      primaryDeductibleApplied,
      secondaryDeductibleApplied,
      cobMethod,
      procedureDescription: proc.description,
    });

    results.push({
      ...cobResult,
      cdtCode: proc.cdtCode,
    });

    totalPrimaryPayment += cobResult.primaryPayment;
    totalSecondaryPayment += cobResult.secondaryPayment;
    totalCovered += cobResult.totalCovered;
    totalPatientResponsibility += cobResult.patientResponsibility;
    totalProviderFees += proc.providerFee;
  }

  return {
    byProcedure: results,
    aggregates: {
      totalPrimaryPayment,
      totalSecondaryPayment,
      totalCovered,
      totalPatientResponsibility,
      totalProviderFees,
    },
  };
}

// ============================================================================
// === EXPORTS ===
// ============================================================================

export {
  COBCalculation,
  Plan,
  Patient,
  CarrierCode,
} from '../types';
