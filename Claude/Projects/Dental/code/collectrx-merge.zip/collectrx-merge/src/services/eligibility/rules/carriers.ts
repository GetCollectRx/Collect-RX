/**
 * Carrier Rule Configuration for CollectRx Eligibility Engine
 *
 * This file defines coverage rules, deductibles, frequency limits, and waiting periods
 * for 6 Canadian dental insurance carriers. These are DATA configurations, not code,
 * making it easy to update rules without redeploying the application.
 *
 * Each carrier config specifies:
 * - Coverage percentages by service category
 * - Deductible amounts (individual & family)
 * - Annual maximum benefits
 * - Frequency limits for specific procedures (per ADA code)
 * - Waiting periods for major and ortho services
 * - Coordination of Benefits (COB) method
 * - Notes for AI system and manual review
 */

/**
 * Carrier code enumeration for type safety
 */
export type CarrierCode =
  | 'sunlife_private'
  | 'great_west'
  | 'manulife'
  | 'green_shield'
  | 'rbc_insurance'
  | 'telus_adjudicare';

/**
 * Service category for coverage percentage lookup
 */
export type ServiceCategory =
  | 'preventive'
  | 'basic'
  | 'major'
  | 'ortho'
  | 'endo'
  | 'perio'
  | 'prostho';

/**
 * Frequency limit rule tied to procedure codes
 */
export interface FrequencyRule {
  codes: string[]; // ADA procedure codes
  limit: number; // Maximum count
  period: 'months'; // Time period type
  months: number; // Number of months in period
  ageLimit?: number; // Optional: only applies to patients under this age
  note?: string; // Optional: clarification or special rules
}

/**
 * Deductible structure
 */
export interface Deductible {
  individual: number; // Amount in dollars
  family: number; // Amount in dollars
  waivedForPreventive: boolean; // If true, deductible does not apply to preventive
  appliesTo: ServiceCategory[]; // Categories subject to deductible
}

/**
 * Annual maximum structure
 */
export interface AnnualMax {
  individual: number; // Individual limit in dollars
  family?: number; // Optional: family aggregate limit
  preventiveCountsTowardMax: boolean; // If true, preventive counts against the max
  note?: string; // Optional: special rules or clarifications
}

/**
 * Coordination of Benefits method
 */
export type COBMethod = 'standard' | 'non_duplication';

/**
 * Waiting period structure
 */
export interface WaitingPeriod {
  category: ServiceCategory;
  months: number; // Waiting period in months
  appliesToNewPlansOnly: boolean; // If true, only applies to new members or plan changes
}

/**
 * Complete carrier configuration
 */
export interface CarrierConfig {
  code: CarrierCode;
  name: string;
  coverage: Partial<Record<ServiceCategory, number>>; // Percentage coverage by category
  deductible: Deductible;
  annualMax: AnnualMax;
  frequencyRules: FrequencyRule[];
  waitingPeriods: WaitingPeriod[];
  cob: COBMethod;
  notes: string;
}

// ============================================================================
// 1. SUN LIFE (sunlife_private)
// ============================================================================

/**
 * Sun Life Private plan configuration
 * Largest Canadian dental carrier with strong coverage and online portal
 */
const SUNLIFE_PRIVATE: CarrierConfig = {
  code: 'sunlife_private',
  name: 'Sun Life',
  coverage: {
    preventive: 100,
    basic: 80,
    major: 50,
    ortho: 50,
    endo: 80,
    perio: 80,
    prostho: 50,
  },
  deductible: {
    individual: 50,
    family: 150,
    waivedForPreventive: true,
    appliesTo: ['basic', 'major', 'ortho', 'endo', 'perio', 'prostho'],
  },
  annualMax: {
    individual: 1500,
    preventiveCountsTowardMax: false,
    note: 'Preventive services do NOT count toward the $1,500 individual maximum',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy - child, adult
      limit: 2,
      period: 'months',
      months: 6,
      note: 'Cleanings: 2 per 6 months',
    },
    {
      codes: ['D0120', 'D0150'], // Periodic oral evaluation, comprehensive oral eval
      limit: 2,
      period: 'months',
      months: 12,
      note: 'Exams: 2 per 12 months',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings - four radiographic images, bitewings - seven to eight radiographic images
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Intraoral - full mouth radiographic images
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Full mouth X-rays: 1 per 36 months',
    },
    {
      codes: ['D0330'], // Panoramic radiographic images
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Panoramic X-rays: 1 per 36 months',
    },
    {
      codes: ['D1206', 'D1208'], // Topical fluoride - child, topical fluoride - adult
      limit: 2,
      period: 'months',
      months: 12,
      ageLimit: 19,
      note: 'Fluoride: 2 per 12 months (age <19 only)',
    },
  ],
  waitingPeriods: [
    {
      category: 'ortho',
      months: 12,
      appliesToNewPlansOnly: true,
      note: 'APPROXIMATE — verify post-pilot',
    },
  ],
  cob: 'standard',
  notes:
    'Largest Canadian dental carrier. Online portal for claim status. Pre-authorization required for procedures over $500.',
};

// ============================================================================
// 2. CANADA LIFE / GREAT-WEST (great_west)
// ============================================================================

/**
 * Canada Life / Great-West Life plan configuration
 * Known for lower annual max and stricter X-ray frequency limits
 */
const GREAT_WEST: CarrierConfig = {
  code: 'great_west',
  name: 'Canada Life / Great-West',
  coverage: {
    preventive: 100,
    basic: 80,
    major: 50,
    endo: 80,
    perio: 80,
    prostho: 50,
    // Note: No ortho coverage in standard plans
  },
  deductible: {
    individual: 75,
    family: 225,
    waivedForPreventive: true,
    appliesTo: ['basic', 'major', 'endo', 'perio', 'prostho'],
  },
  annualMax: {
    individual: 1200,
    preventiveCountsTowardMax: true,
    note: 'Lower annual max than competitors. Preventive DOES count toward the max.',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy - child, adult
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Cleanings: 1 per 6 months (stricter than Sun Life)',
    },
    {
      codes: ['D0120', 'D0150'], // Periodic and comprehensive exams
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Exams: 1 per 6 months',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Full mouth X-rays
      limit: 1,
      period: 'months',
      months: 60,
      note: 'Full mouth X-rays: 1 per 60 months (every 5 years — strictest limit)',
    },
    {
      codes: ['D0330'], // Panoramic
      limit: 1,
      period: 'months',
      months: 60,
      note: 'Panoramic X-rays: 1 per 60 months (every 5 years)',
    },
  ],
  waitingPeriods: [],
  cob: 'standard',
  notes:
    'Formerly Great-West Life. Lower annual max than competitors. Strict on X-ray frequency (5-year intervals).',
};

// ============================================================================
// 3. MANULIFE (manulife)
// ============================================================================

/**
 * Manulife plan configuration
 * Highest annual max, zero deductible, non-duplication COB method
 */
const MANULIFE: CarrierConfig = {
  code: 'manulife',
  name: 'Manulife',
  coverage: {
    preventive: 100,
    basic: 85,
    major: 60,
    ortho: 50,
    endo: 85,
    perio: 85,
    prostho: 60,
  },
  deductible: {
    individual: 0,
    family: 0,
    waivedForPreventive: true,
    appliesTo: [],
    note: 'Zero deductible — no deductible applies',
  },
  annualMax: {
    individual: 2000,
    family: 6000,
    preventiveCountsTowardMax: false,
    note: 'Highest annual max. Preventive does NOT count toward max. Family aggregate max is $6,000.',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Cleanings: 1 per 6 months',
    },
    {
      codes: ['D0120', 'D0150'], // Exams
      limit: 2,
      period: 'months',
      months: 12,
      note: 'Exams: 2 per 12 months',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Full mouth X-rays
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Full mouth X-rays: 1 per 36 months',
    },
    {
      codes: ['D0330'], // Panoramic
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Panoramic X-rays: 1 per 36 months',
    },
    {
      codes: ['D1206', 'D1208'], // Fluoride
      limit: 1,
      period: 'months',
      months: 12,
      ageLimit: 18,
      note: 'Fluoride: 1 per 12 months (age <18 only)',
    },
  ],
  waitingPeriods: [
    {
      category: 'major',
      months: 6,
      appliesToNewPlansOnly: true,
      note: 'APPROXIMATE — verify post-pilot',
    },
    {
      category: 'ortho',
      months: 12,
      appliesToNewPlansOnly: true,
      note: 'APPROXIMATE — verify post-pilot',
    },
  ],
  cob: 'non_duplication',
  notes:
    'Highest annual max. Zero deductible. Family aggregate max is distinct from individual. Non-duplication COB: Manulife pays the lesser of their calculated benefit or the remaining balance.',
};

// ============================================================================
// 4. GREEN SHIELD CANADA (green_shield)
// ============================================================================

/**
 * Green Shield Canada plan configuration
 * Known for strictest frequency limitations and 9-month cleaning intervals
 */
const GREEN_SHIELD: CarrierConfig = {
  code: 'green_shield',
  name: 'Green Shield Canada',
  coverage: {
    preventive: 100,
    basic: 80,
    major: 50,
    endo: 80,
    perio: 80,
    prostho: 50,
    // Note: No standard ortho coverage
  },
  deductible: {
    individual: 50,
    family: 150,
    waivedForPreventive: true,
    appliesTo: ['basic', 'major', 'endo', 'perio', 'prostho'],
  },
  annualMax: {
    individual: 1500,
    preventiveCountsTowardMax: true,
    note: 'Preventive DOES count toward the $1,500 max.',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy
      limit: 1,
      period: 'months',
      months: 9,
      note: 'Cleanings: 1 per 9 months (stricter than most — known for denying frequency violations)',
    },
    {
      codes: ['D0120', 'D0150'], // Exams
      limit: 1,
      period: 'months',
      months: 9,
      note: 'Exams: 1 per 9 months (stricter than most)',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Full mouth X-rays
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Full mouth X-rays: 1 per 36 months',
    },
    {
      codes: ['D0330'], // Panoramic
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Panoramic X-rays: 1 per 36 months',
    },
    {
      codes: ['D4341', 'D4342'], // Periodontal scaling and root planing
      limit: 8,
      period: 'months',
      months: 12,
      note: 'Scaling/root planing: 8 units per 12 months (APPROXIMATE — verify post-pilot)',
    },
  ],
  waitingPeriods: [],
  cob: 'standard',
  notes:
    'Strictest frequency limitations of all 6 carriers. 9-month cleaning interval instead of 6. Known for denying frequency-limited claims. Digital claims submission only.',
};

// ============================================================================
// 5. RBC INSURANCE (rbc_insurance)
// ============================================================================

/**
 * RBC Insurance plan configuration
 * Higher deductible than competitors, good annual max
 */
const RBC_INSURANCE: CarrierConfig = {
  code: 'rbc_insurance',
  name: 'RBC Insurance',
  coverage: {
    preventive: 100,
    basic: 80,
    major: 50,
    ortho: 50,
    endo: 80,
    perio: 80,
    prostho: 50,
  },
  deductible: {
    individual: 100,
    family: 300,
    waivedForPreventive: true,
    appliesTo: ['basic', 'major', 'ortho', 'endo', 'perio', 'prostho'],
  },
  annualMax: {
    individual: 1800,
    preventiveCountsTowardMax: false,
    note: 'Good annual max. Preventive does NOT count toward the max.',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Cleanings: 1 per 6 months',
    },
    {
      codes: ['D0120', 'D0150'], // Exams
      limit: 2,
      period: 'months',
      months: 12,
      note: 'Exams: 2 per 12 months',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Full mouth X-rays
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Full mouth X-rays: 1 per 36 months',
    },
    {
      codes: ['D0330'], // Panoramic
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Panoramic X-rays: 1 per 36 months',
    },
  ],
  waitingPeriods: [
    {
      category: 'ortho',
      months: 12,
      appliesToNewPlansOnly: true,
      note: 'APPROXIMATE — verify post-pilot',
    },
  ],
  cob: 'standard',
  notes:
    'Higher deductible ($100 individual) than competitors. Good annual max of $1,800. Pre-authorization recommended for major work over $800.',
};

// ============================================================================
// 6. TELUS ADJUDICARE (telus_adjudicare)
// ============================================================================

/**
 * TELUS AdjudiCare plan configuration
 * Digital-first TPA/clearinghouse — requires identification of underlying employer plan
 */
const TELUS_ADJUDICARE: CarrierConfig = {
  code: 'telus_adjudicare',
  name: 'TELUS AdjudiCare',
  coverage: {
    preventive: 100,
    basic: 80,
    major: 50,
    endo: 80,
    perio: 80,
    prostho: 50,
    // Note: No standard ortho coverage
  },
  deductible: {
    individual: 50,
    family: 150,
    waivedForPreventive: true,
    appliesTo: ['basic', 'major', 'endo', 'perio', 'prostho'],
  },
  annualMax: {
    individual: 1500,
    preventiveCountsTowardMax: true,
    note: 'Preventive DOES count toward the max. These are defaults; actual limits depend on underlying plan.',
  },
  frequencyRules: [
    {
      codes: ['D1110', 'D1120'], // Prophy
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Cleanings: 1 per 6 months (default rule — may vary by employer group)',
    },
    {
      codes: ['D0120', 'D0150'], // Exams
      limit: 1,
      period: 'months',
      months: 6,
      note: 'Exams: 1 per 6 months (default rule — may vary by employer group)',
    },
    {
      codes: ['D0272', 'D0274'], // Bitewings
      limit: 1,
      period: 'months',
      months: 12,
      note: 'Bitewing X-rays: 1 per 12 months',
    },
    {
      codes: ['D0210'], // Full mouth X-rays
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Full mouth X-rays: 1 per 36 months',
    },
    {
      codes: ['D0330'], // Panoramic
      limit: 1,
      period: 'months',
      months: 36,
      note: 'Panoramic X-rays: 1 per 36 months',
    },
  ],
  waitingPeriods: [],
  cob: 'standard',
  notes:
    'TELUS AdjudiCare is a clearinghouse/TPA — not a single insurer. Must identify the specific TPA before calling. Digital-first carrier with real-time adjudication. Rules here are defaults; actual rules depend on the underlying employer group plan.',
};

// ============================================================================
// CARRIER REGISTRY
// ============================================================================

/**
 * Comprehensive map of all supported carriers
 */
export const CARRIER_CONFIGS: Record<CarrierCode, CarrierConfig> = {
  sunlife_private: SUNLIFE_PRIVATE,
  great_west: GREAT_WEST,
  manulife: MANULIFE,
  green_shield: GREEN_SHIELD,
  rbc_insurance: RBC_INSURANCE,
  telus_adjudicare: TELUS_ADJUDICARE,
};

/**
 * Array of all supported carrier codes
 * Useful for iteration, validation, and UI population
 */
export const SUPPORTED_CARRIERS: CarrierCode[] = [
  'sunlife_private',
  'great_west',
  'manulife',
  'green_shield',
  'rbc_insurance',
  'telus_adjudicare',
];

/**
 * Lookup a carrier configuration by code
 *
 * @param code - The carrier code to look up
 * @returns The carrier configuration
 * @throws Error if the carrier code is not supported
 *
 * @example
 * const sunLifeRules = getCarrierConfig('sunlife_private');
 */
export function getCarrierConfig(code: CarrierCode): CarrierConfig {
  const config = CARRIER_CONFIGS[code];

  if (!config) {
    throw new Error(
      `Unknown carrier code: ${code}. Supported carriers: ${SUPPORTED_CARRIERS.join(', ')}`
    );
  }

  return config;
}

/**
 * Check if a carrier code is supported
 *
 * @param code - The code to validate
 * @returns True if the carrier is supported
 */
export function isSupportedCarrier(code: string): code is CarrierCode {
  return SUPPORTED_CARRIERS.includes(code as CarrierCode);
}

/**
 * Get all carrier names as display strings
 *
 * @returns Array of carrier names in display format
 */
export function getCarrierNames(): string[] {
  return SUPPORTED_CARRIERS.map((code) => CARRIER_CONFIGS[code].name);
}
