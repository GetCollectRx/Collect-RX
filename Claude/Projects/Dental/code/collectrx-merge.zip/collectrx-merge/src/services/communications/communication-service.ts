/**
 * CollectRx Communication Service
 *
 * Handles sending SMS (via Twilio) and emails (via SendGrid) for payment reminders,
 * receipts, statements, and collection notices to patients in Canadian dental practices.
 *
 * Supports template-based personalization, delivery tracking, and comprehensive
 * analytics on email and SMS engagement.
 */

import twilio from 'twilio'
import sgMail from '@sendgrid/mail'
import { v4 as uuidv4 } from 'uuid'
import {
  Communication,
  CommunicationTemplate,
  CommunicationType,
  CommunicationStatus,
  CommunicationPurpose,
} from '../payments/types'

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

/**
 * Configuration for the CommunicationService constructor
 */
export interface CommunicationServiceConfig {
  twilioAccountSid: string
  twilioAuthToken: string
  twilioPhoneNumber: string
  sendgridApiKey: string
  sendgridFromEmail: string
  sendgridFromName: string
}

/**
 * Parameters for sending SMS
 */
interface SendSMSParams {
  to: string
  body: string
  patientId: string
  practiceId: string
  purpose: CommunicationPurpose
  paymentLinkId?: string
}

/**
 * Parameters for sending email
 */
interface SendEmailParams {
  to: string
  subject: string
  body: string
  htmlBody?: string
  patientId: string
  practiceId: string
  purpose: CommunicationPurpose
  paymentLinkId?: string
}

/**
 * Parameters for template-based communication
 */
interface SendFromTemplateParams {
  templateId: string
  variables: Record<string, string>
  recipient: {
    email?: string
    phone?: string
  }
  context: {
    patientId: string
    practiceId: string
    paymentLinkId?: string
  }
}

/**
 * Result of phone number validation
 */
interface PhoneValidationResult {
  valid: boolean
  formatted: string
  error?: string
}

/**
 * Result of email validation
 */
interface EmailValidationResult {
  valid: boolean
  error?: string
}

/**
 * Delivery statistics for a practice
 */
export interface DeliveryStats {
  totalSent: number
  totalDelivered: number
  totalFailed: number
  totalOpened: number
  totalClicked: number
  deliveryRate: number
  openRate: number
  clickRate: number
  bySMS: {
    sent: number
    delivered: number
    failed: number
  }
  byEmail: {
    sent: number
    delivered: number
    failed: number
    opened: number
    clicked: number
  }
  byPurpose: Record<CommunicationPurpose, number>
}

/**
 * Rendered template content
 */
interface RenderedTemplate {
  subject?: string
  body: string
}

// ============================================================================
// COMMUNICATION SERVICE
// ============================================================================

/**
 * Service for managing patient communications via SMS and email.
 * Handles sending, tracking, and analytics for all communication channels.
 *
 * Canadian context: Phone numbers must be in E.164 format (+1XXXXXXXXXX)
 * All timestamps are ISO 8601 format
 * Currency is always CAD
 */
export class CommunicationService {
  private twilioClient: ReturnType<typeof twilio>
  private config: CommunicationServiceConfig

  /**
   * Creates a new CommunicationService instance
   *
   * @param config - Configuration containing Twilio and SendGrid credentials
   */
  constructor(config: CommunicationServiceConfig) {
    this.config = config

    // Initialize Twilio client
    // Twilio Note: Account SID and Auth Token are used for SMS authentication
    this.twilioClient = twilio(config.twilioAccountSid, config.twilioAuthToken)

    // Initialize SendGrid client
    // SendGrid Note: API key is set globally for all email operations
    sgMail.setApiKey(config.sendgridApiKey)
  }

  /**
   * Sends an SMS to a patient with optional payment link tracking
   *
   * @param params - SMS parameters including recipient, message, and context
   * @returns Communication record with sent status and external provider ID
   * @throws Error if phone number is invalid or Twilio API call fails
   *
   * @example
   * const comm = await service.sendSMS({
   *   to: '+14165551234',
   *   body: 'Hi John, you have an outstanding balance of $150...',
   *   patientId: 'pat_123',
   *   practiceId: 'prc_456',
   *   purpose: 'payment_reminder',
   * })
   */
  async sendSMS(params: SendSMSParams): Promise<Communication> {
    const { to, body, patientId, practiceId, purpose, paymentLinkId } = params

    // Validate phone number format (Canadian)
    const validation = this.validatePhoneNumber(to)
    if (!validation.valid) {
      throw new Error(
        `Invalid phone number format: ${validation.error}. Expected Canadian number in format +1XXXXXXXXXX`
      )
    }

    const formattedPhone = validation.formatted

    try {
      // Send via Twilio
      // Twilio Note: SMS are sent from the configured Twilio phone number
      const message = await this.twilioClient.messages.create({
        body: body,
        from: this.config.twilioPhoneNumber,
        to: formattedPhone,
      })

      // Create Communication record
      const communication: Communication = {
        id: uuidv4(),
        patientId,
        practiceId,
        type: 'sms',
        purpose,
        status: 'sent',
        recipient: formattedPhone,
        body,
        paymentLinkId,
        sentAt: new Date().toISOString(),
        externalId: message.sid, // Twilio SID for tracking
        createdAt: new Date().toISOString(),
      }

      return communication
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)

      // Handle specific Twilio errors
      if (errorMessage.includes('Invalid phone number')) {
        throw new Error(
          `Twilio rejected phone number ${formattedPhone}: Invalid number for country`
        )
      } else if (errorMessage.includes('Account is suspended')) {
        throw new Error('Twilio account is suspended. Cannot send SMS.')
      } else if (errorMessage.includes('Too many requests')) {
        throw new Error(
          'Twilio rate limit exceeded. Please retry after a brief delay.'
        )
      }

      throw new Error(`Failed to send SMS via Twilio: ${errorMessage}`)
    }
  }

  /**
   * Sends an email to a patient with optional HTML and payment link tracking
   *
   * @param params - Email parameters including recipient, subject, body, and context
   * @returns Communication record with sent status and SendGrid message ID
   * @throws Error if email address is invalid or SendGrid API call fails
   *
   * @example
   * const comm = await service.sendEmail({
   *   to: 'john@example.com',
   *   subject: 'Outstanding Balance Reminder',
   *   body: 'You have an outstanding balance of $150...',
   *   htmlBody: '<p>You have an outstanding balance of $150...</p>',
   *   patientId: 'pat_123',
   *   practiceId: 'prc_456',
   *   purpose: 'payment_reminder',
   * })
   */
  async sendEmail(params: SendEmailParams): Promise<Communication> {
    const {
      to,
      subject,
      body,
      htmlBody,
      patientId,
      practiceId,
      purpose,
      paymentLinkId,
    } = params

    // Validate email format
    const validation = this.validateEmail(to)
    if (!validation.valid) {
      throw new Error(
        `Invalid email address: ${validation.error}. Please check the email format.`
      )
    }

    try {
      // Send via SendGrid
      // SendGrid Note: Uses configured from email and name; HTML body is optional
      const response = await sgMail.send({
        to: to,
        from: {
          email: this.config.sendgridFromEmail,
          name: this.config.sendgridFromName,
        },
        subject,
        text: body,
        html: htmlBody || undefined,
        // Track opens and clicks via SendGrid
        trackingSettings: {
          openTracking: { enable: true },
          clickTracking: { enable: true },
        },
      })

      // Extract message ID from response header
      const messageId = response[0].headers['x-message-id'] as string

      // Create Communication record
      const communication: Communication = {
        id: uuidv4(),
        patientId,
        practiceId,
        type: 'email',
        purpose,
        status: 'sent',
        recipient: to,
        subject,
        body,
        paymentLinkId,
        sentAt: new Date().toISOString(),
        externalId: messageId, // SendGrid message ID for tracking
        createdAt: new Date().toISOString(),
      }

      return communication
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)

      // Handle specific SendGrid errors
      if (errorMessage.includes('Invalid email')) {
        throw new Error(
          `SendGrid rejected email address: ${to}. Check for typos in the address.`
        )
      } else if (errorMessage.includes('Unauthorized')) {
        throw new Error('SendGrid API key is invalid or has insufficient permissions.')
      } else if (errorMessage.includes('Too many requests')) {
        throw new Error(
          'SendGrid rate limit exceeded. Please retry after a brief delay.'
        )
      }

      throw new Error(`Failed to send email via SendGrid: ${errorMessage}`)
    }
  }

  /**
   * Sends a communication using a template with variable substitution
   *
   * Routes to either SMS or email based on template type.
   * Replaces all {{variable}} placeholders with provided values.
   *
   * @param templateId - ID of the communication template
   * @param variables - Object mapping variable names to values for substitution
   * @param recipient - Phone number and/or email address for the recipient
   * @param context - Practice and patient context for the communication
   * @returns Communication record created from the template
   * @throws Error if template not found, required variables missing, or send fails
   *
   * @example
   * const comm = await service.sendFromTemplate('payment_reminder_sms', {
   *   patientName: 'John Doe',
   *   amount: '$150.00',
   *   practiceName: 'Smile Dental',
   *   paymentLink: 'https://pay.collectrx.ca/link123',
   * }, {
   *   phone: '+14165551234',
   * }, {
   *   patientId: 'pat_123',
   *   practiceId: 'prc_456',
   *   paymentLinkId: 'plink_789',
   * })
   */
  async sendFromTemplate(
    templateId: string,
    variables: Record<string, string>,
    recipient: {
      email?: string
      phone?: string
    },
    context: {
      patientId: string
      practiceId: string
      paymentLinkId?: string
    }
  ): Promise<Communication> {
    // Find the template
    const template = DEFAULT_TEMPLATES.find((t) => t.id === templateId)
    if (!template) {
      throw new Error(
        `Template not found: ${templateId}. Check that the template exists and is active.`
      )
    }

    // Validate that all required variables are provided
    const missingVars = template.variables.filter((v) => !(v in variables))
    if (missingVars.length > 0) {
      throw new Error(
        `Missing required template variables: ${missingVars.join(', ')}. ` +
          `Please provide values for: ${template.variables.join(', ')}`
      )
    }

    // Render the template with variables
    const rendered = this.renderTemplate(template, variables)

    // Route to appropriate channel
    if (template.type === 'sms') {
      if (!recipient.phone) {
        throw new Error(
          `SMS template requires a phone number, but none was provided in recipient`
        )
      }

      return this.sendSMS({
        to: recipient.phone,
        body: rendered.body,
        patientId: context.patientId,
        practiceId: context.practiceId,
        purpose: template.purpose,
        paymentLinkId: context.paymentLinkId,
      })
    } else if (template.type === 'email') {
      if (!recipient.email) {
        throw new Error(
          `Email template requires an email address, but none was provided in recipient`
        )
      }

      return this.sendEmail({
        to: recipient.email,
        subject: rendered.subject || template.subject || 'Payment Required',
        body: rendered.body,
        patientId: context.patientId,
        practiceId: context.practiceId,
        purpose: template.purpose,
        paymentLinkId: context.paymentLinkId,
      })
    }

    throw new Error(`Unknown template type: ${template.type}`)
  }

  /**
   * Renders a template by replacing {{variable}} placeholders with values
   *
   * Supports variable substitution in both subject and body.
   * Variables are case-sensitive: {{patientName}} is different from {{patientname}}.
   *
   * @param template - The communication template to render
   * @param variables - Object mapping variable names to replacement values
   * @returns Rendered template with subject and body
   * @throws Error if a required variable is missing from the variables map
   *
   * @example
   * const rendered = service.renderTemplate(template, {
   *   patientName: 'John Doe',
   *   amount: '$150.00',
   * })
   * // rendered.body = 'Hi John Doe, you owe $150.00'
   */
  renderTemplate(
    template: CommunicationTemplate,
    variables: Record<string, string>
  ): RenderedTemplate {
    let body = template.body
    let subject = template.subject || ''

    // Replace all {{variableName}} placeholders
    // Variables are case-sensitive
    for (const [key, value] of Object.entries(variables)) {
      const placeholder = new RegExp(`{{${key}}}`, 'g')
      body = body.replace(placeholder, value)
      subject = subject.replace(placeholder, value)
    }

    // Check for any remaining unreplaced placeholders (indicates missing variables)
    const unreplacedInBody = body.match(/{{[^}]+}}/g)
    const unreplacedInSubject = subject.match(/{{[^}]+}}/g)
    const unreplaced = [...(unreplacedInBody || []), ...(unreplacedInSubject || [])]

    if (unreplaced.length > 0) {
      throw new Error(
        `Failed to replace all template variables. ` +
          `Unreplaced placeholders: ${[...new Set(unreplaced)].join(', ')}. ` +
          `Available variables: ${Object.keys(variables).join(', ')}`
      )
    }

    return {
      subject: subject || undefined,
      body,
    }
  }

  /**
   * Handles Twilio status callback for SMS delivery tracking
   *
   * Updates Communication record status based on Twilio webhook callback.
   * Twilio Note: Callbacks are sent for 'sent', 'delivered', 'failed', and 'undelivered' statuses.
   *
   * @param data - Twilio webhook payload containing message status update
   * @throws Error if external ID is missing or database update fails
   *
   * @example
   * // Called by webhook handler route
   * await service.handleTwilioStatusCallback({
   *   MessageSid: 'SM1234567890abcdef1234567890abcdef',
   *   MessageStatus: 'delivered',
   * })
   */
  async handleTwilioStatusCallback(data: any): Promise<void> {
    const { MessageSid, MessageStatus } = data

    if (!MessageSid) {
      throw new Error('Twilio callback missing MessageSid (external ID)')
    }

    // Map Twilio status to our Communication status
    let status: CommunicationStatus = 'sent'
    switch (MessageStatus) {
      case 'sent':
        status = 'sent'
        break
      case 'delivered':
        status = 'delivered'
        break
      case 'failed':
      case 'undelivered':
        status = 'failed'
        break
      default:
        // Unknown status, log but don't fail
        console.warn(`Unknown Twilio message status: ${MessageStatus}`)
        return
    }

    // In production, query database for Communication record with externalId = MessageSid
    // and update its status. This is a placeholder for that operation.
    // Example: await db.communications.update({ externalId: MessageSid }, { status })
    console.log(
      `[Twilio Callback] Updated SMS ${MessageSid} to status: ${status}`
    )
  }

  /**
   * Handles SendGrid webhook events for email delivery tracking
   *
   * Updates Communication record status based on SendGrid events.
   * SendGrid Note: Supports 'delivered', 'opened', 'clicked', 'bounced', and 'dropped' events.
   *
   * @param events - Array of SendGrid webhook events
   * @throws Error if event processing fails
   *
   * @example
   * // Called by webhook handler route
   * await service.handleSendGridWebhook([
   *   {
   *     email: 'john@example.com',
   *     timestamp: 1704067200,
   *     sg_event_id: 'sendgrid_internal_id',
   *     event: 'delivered',
   *     sg_message_id: 'msg_1234567890abcdef1234567890abcdef',
   *   },
   * ])
   */
  async handleSendGridWebhook(events: any[]): Promise<void> {
    for (const event of events) {
      const { sg_message_id, event: eventType, timestamp } = event

      if (!sg_message_id) {
        console.warn('SendGrid event missing sg_message_id')
        continue
      }

      // Map SendGrid event to our Communication status
      let status: CommunicationStatus = 'sent'
      switch (eventType) {
        case 'delivered':
          status = 'delivered'
          break
        case 'opened':
          status = 'opened'
          break
        case 'clicked':
          status = 'clicked'
          break
        case 'bounced':
          status = 'bounced'
          break
        case 'dropped':
          status = 'failed'
          break
        default:
          // Ignore other events like 'processed', 'send', 'spamreport', etc.
          continue
      }

      // In production, query database for Communication record with externalId = sg_message_id
      // and update its status and relevant timestamp. This is a placeholder.
      // Example: await db.communications.update({ externalId: sg_message_id }, { status, deliveredAt: ... })
      const eventTimestamp = new Date(timestamp * 1000).toISOString()
      console.log(
        `[SendGrid Webhook] Updated email ${sg_message_id} to status: ${status} at ${eventTimestamp}`
      )
    }
  }

  /**
   * Validates a Canadian phone number and returns it in E.164 format
   *
   * Accepts various formats and normalizes to +1XXXXXXXXXX (E.164).
   * Canadian phone numbers must be 10 digits after the country code +1.
   *
   * @param phone - Phone number in any reasonable format
   * @returns Validation result with formatted number or error message
   *
   * @example
   * const result = service.validatePhoneNumber('(416) 555-1234')
   * // result.valid === true
   * // result.formatted === '+14165551234'
   *
   * const invalid = service.validatePhoneNumber('416-123-4')
   * // invalid.valid === false
   * // invalid.error === 'Number is too short'
   */
  validatePhoneNumber(phone: string): PhoneValidationResult {
    // Strip all non-digit characters except leading +
    let cleaned = phone.replace(/\D/g, '')

    // If it has a + at the start, prepend 1 if needed (for Canadian format)
    // Otherwise, just work with digits
    if (phone.startsWith('+')) {
      cleaned = phone.replace(/\D/g, '')
    }

    // Handle cases where user includes country code
    if (cleaned.length === 11 && cleaned.startsWith('1')) {
      cleaned = cleaned.substring(1) // Remove leading 1
    }

    // Canadian phone numbers must be 10 digits
    if (cleaned.length !== 10) {
      return {
        valid: false,
        formatted: '',
        error: `Invalid length. Expected 10 digits, got ${cleaned.length}.`,
      }
    }

    // Check that all characters are digits
    if (!/^\d{10}$/.test(cleaned)) {
      return {
        valid: false,
        formatted: '',
        error: 'Contains non-digit characters after cleaning.',
      }
    }

    // Format as E.164 for Canada: +1XXXXXXXXXX
    const formatted = `+1${cleaned}`

    // Additional validation: area code should not start with 0 or 1
    const areaCode = cleaned.substring(0, 3)
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return {
        valid: false,
        formatted: '',
        error: `Invalid area code: ${areaCode}. Canadian area codes cannot start with 0 or 1.`,
      }
    }

    return {
      valid: true,
      formatted,
    }
  }

  /**
   * Validates an email address format
   *
   * Performs basic RFC 5322-inspired validation and checks for common typos
   * in Canadian ISP domains (e.g., gmail.com, yahoo.ca, hotmail.com).
   *
   * @param email - Email address to validate
   * @returns Validation result with error message if invalid
   *
   * @example
   * const valid = service.validateEmail('john@example.com')
   * // valid.valid === true
   *
   * const invalid = service.validateEmail('john@gmial.com')
   * // invalid.valid === false
   * // invalid.error === 'Common typo detected: gmial.com (did you mean gmail.com?)'
   */
  validateEmail(email: string): EmailValidationResult {
    // Basic email regex (simplified RFC 5322)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

    if (!emailRegex.test(email)) {
      return {
        valid: false,
        error: 'Invalid email format. Must contain local@domain.extension',
      }
    }

    // Check for common Canadian ISP domain typos
    const domain = email.split('@')[1].toLowerCase()
    const commonCanadianDomains = [
      'gmail.com',
      'gmail.ca',
      'yahoo.com',
      'yahoo.ca',
      'hotmail.com',
      'hotmail.ca',
      'outlook.com',
      'outlook.ca',
      'bell.ca',
      'rogers.com',
      'telus.net',
      'shaw.ca',
    ]

    // Simple typo detection: check if domain is similar to a known domain
    for (const knownDomain of commonCanadianDomains) {
      if (
        domain !== knownDomain &&
        this.levenshteinDistance(domain, knownDomain) <= 2
      ) {
        return {
          valid: false,
          error: `Possible typo detected: ${domain} (did you mean ${knownDomain}?)`,
        }
      }
    }

    return { valid: true }
  }

  /**
   * Calculates the Levenshtein distance between two strings
   * Used for detecting email domain typos
   *
   * @param str1 - First string
   * @param str2 - Second string
   * @returns Edit distance (number of single-character edits required)
   */
  private levenshteinDistance(str1: string, str2: string): number {
    const len1 = str1.length
    const len2 = str2.length
    const matrix: number[][] = Array(len1 + 1)
      .fill(null)
      .map(() => Array(len2 + 1).fill(0))

    for (let i = 0; i <= len1; i++) matrix[i][0] = i
    for (let j = 0; j <= len2; j++) matrix[0][j] = j

    for (let i = 1; i <= len1; i++) {
      for (let j = 1; j <= len2; j++) {
        const cost = str1[i - 1] === str2[j - 1] ? 0 : 1
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1, // deletion
          matrix[i][j - 1] + 1, // insertion
          matrix[i - 1][j - 1] + cost // substitution
        )
      }
    }

    return matrix[len1][len2]
  }

  /**
   * Retrieves delivery statistics for a practice within a date range
   *
   * Aggregates all communications by type, purpose, and status to provide
   * insights into SMS and email effectiveness, delivery rates, and engagement.
   *
   * @param practiceId - ID of the practice to retrieve stats for
   * @param dateRange - Date range for the statistics (ISO 8601 strings)
   * @returns Aggregated delivery statistics
   *
   * @example
   * const stats = await service.getDeliveryStats('prc_456', {
   *   from: '2026-03-01',
   *   to: '2026-03-31',
   * })
   * // stats.deliveryRate === 97.5
   * // stats.byEmail.openRate === 42.3
   */
  async getDeliveryStats(
    practiceId: string,
    dateRange: { from: string; to: string }
  ): Promise<DeliveryStats> {
    // In production, query database for all Communications for this practice
    // within the date range and aggregate statistics.
    // This is a placeholder implementation showing the structure.

    // Example query pattern:
    // const communications = await db.communications.find({
    //   practiceId,
    //   sentAt: { $gte: dateRange.from, $lte: dateRange.to }
    // })

    // For now, return a zero-initialized structure
    const stats: DeliveryStats = {
      totalSent: 0,
      totalDelivered: 0,
      totalFailed: 0,
      totalOpened: 0,
      totalClicked: 0,
      deliveryRate: 0,
      openRate: 0,
      clickRate: 0,
      bySMS: {
        sent: 0,
        delivered: 0,
        failed: 0,
      },
      byEmail: {
        sent: 0,
        delivered: 0,
        failed: 0,
        opened: 0,
        clicked: 0,
      },
      byPurpose: {
        payment_reminder: 0,
        payment_receipt: 0,
        payment_link: 0,
        statement: 0,
        collection_notice: 0,
      },
    }

    // Calculate rates
    if (stats.totalSent > 0) {
      stats.deliveryRate = (stats.totalDelivered / stats.totalSent) * 100
    }
    if (stats.byEmail.sent > 0) {
      stats.openRate = (stats.totalOpened / stats.byEmail.sent) * 100
      stats.clickRate = (stats.totalClicked / stats.byEmail.sent) * 100
    }

    return stats
  }
}

// ============================================================================
// DEFAULT TEMPLATES
// ============================================================================

/**
 * Built-in communication templates for common use cases
 *
 * These templates provide a starting point for patient communications.
 * Practices can override these or create custom templates in the database.
 *
 * Template variables are case-sensitive and must be surrounded by {{ }}
 */
export const DEFAULT_TEMPLATES: CommunicationTemplate[] = [
  {
    id: 'payment_reminder_sms',
    practiceId: 'default',
    name: 'Payment Reminder (SMS)',
    type: 'sms',
    purpose: 'payment_reminder',
    body: 'Hi {{patientName}}, you have an outstanding balance of {{amount}} at {{practiceName}}. Pay securely here: {{paymentLink}}',
    variables: ['patientName', 'amount', 'practiceName', 'paymentLink'],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'payment_reminder_email',
    practiceId: 'default',
    name: 'Payment Reminder (Email)',
    type: 'email',
    purpose: 'payment_reminder',
    subject: 'Outstanding Balance Reminder from {{practiceName}}',
    body: `Hello {{patientName}},

We noticed you have an outstanding balance of {{amount}} with {{practiceName}}.

Please settle this balance at your earliest convenience to avoid any disruption to your care.

Click the button below to pay securely:
{{paymentLink}}

If you have any questions about this balance or need to make payment arrangements, please contact our office.

Best regards,
{{practiceName}} Team`,
    variables: ['patientName', 'amount', 'practiceName', 'paymentLink'],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'payment_receipt_sms',
    practiceId: 'default',
    name: 'Payment Receipt (SMS)',
    type: 'sms',
    purpose: 'payment_receipt',
    body: 'Your payment of {{amount}} to {{practiceName}} was received. Thank you!',
    variables: ['amount', 'practiceName'],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'payment_receipt_email',
    practiceId: 'default',
    name: 'Payment Receipt (Email)',
    type: 'email',
    purpose: 'payment_receipt',
    subject: 'Payment Receipt from {{practiceName}}',
    body: `Hello {{patientName}},

Thank you for your payment of {{amount}}. Your payment has been received and processed.

Receipt Details:
- Amount: {{amount}}
- Date: {{paymentDate}}
- Receipt Number: {{receiptNumber}}

A detailed receipt is available here: {{receiptUrl}}

If you have any questions about this receipt, please contact our office.

Best regards,
{{practiceName}} Team`,
    variables: [
      'patientName',
      'amount',
      'paymentDate',
      'receiptNumber',
      'receiptUrl',
      'practiceName',
    ],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'statement_email',
    practiceId: 'default',
    name: 'Account Statement (Email)',
    type: 'email',
    purpose: 'statement',
    subject: 'Your {{practiceName}} Account Statement for {{month}}',
    body: `Hello {{patientName}},

Please find your account statement below for {{month}}.

Summary:
- Previous Balance: {{previousBalance}}
- Charges: {{charges}}
- Payments: {{payments}}
- Adjustments: {{adjustments}}
- Current Balance Due: {{balanceDue}}

Detailed transactions are shown in the attached statement.

To pay your balance, please visit: {{paymentLink}}

If you have questions about any charges or need to make payment arrangements, please contact our office.

Best regards,
{{practiceName}} Team`,
    variables: [
      'patientName',
      'month',
      'previousBalance',
      'charges',
      'payments',
      'adjustments',
      'balanceDue',
      'practiceName',
      'paymentLink',
    ],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'collection_notice_sms',
    practiceId: 'default',
    name: 'Collection Notice (SMS)',
    type: 'sms',
    purpose: 'collection_notice',
    body: '{{patientName}}, your account at {{practiceName}} is {{daysPastDue}} days past due ({{amount}}). Please contact us or pay here: {{paymentLink}}',
    variables: [
      'patientName',
      'practiceName',
      'daysPastDue',
      'amount',
      'paymentLink',
    ],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
  {
    id: 'collection_notice_email',
    practiceId: 'default',
    name: 'Collection Notice (Email)',
    type: 'email',
    purpose: 'collection_notice',
    subject: 'Important: Account Past Due at {{practiceName}}',
    body: `Hello {{patientName}},

Your account with {{practiceName}} is now {{daysPastDue}} days past due with an outstanding balance of {{amount}}.

Despite previous reminders, we have not yet received payment. To avoid further action, please settle this balance immediately.

You can pay securely here: {{paymentLink}}

If there are extenuating circumstances or you wish to make payment arrangements, please contact our office as soon as possible at {{practicePhone}}.

We value your business and hope to resolve this matter promptly.

{{practiceName}} Team`,
    variables: [
      'patientName',
      'practiceName',
      'daysPastDue',
      'amount',
      'paymentLink',
      'practicePhone',
    ],
    isActive: true,
    createdAt: new Date().toISOString(),
  },
]
