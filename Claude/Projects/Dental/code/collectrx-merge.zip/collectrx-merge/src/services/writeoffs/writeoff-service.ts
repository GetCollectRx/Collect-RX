/**
 * CollectRx Write-Off Management Service
 *
 * Handles the complete lifecycle of write-off requests including creation,
 * approval workflows, reversals, and ledger integration. Provides batch
 * operations for small balance write-offs and comprehensive reporting.
 *
 * Financial System Note: All amounts are in cents (CAD).
 */

import { v4 as uuidv4 } from 'uuid'
import {
  WriteOff,
  WriteOffStatus,
  WriteOffReason,
  WriteOffPolicy,
  PatientLedgerEntry,
} from '../payments/types'

/**
 * Summary report of write-off activity.
 * Aggregates write-off metrics by status, reason, and time period.
 */
export interface WriteOffSummary {
  /** Total write-offs requested in the period */
  totalRequested: number
  /** Total write-offs approved */
  totalApproved: number
  /** Total write-offs rejected */
  totalRejected: number
  /** Total write-offs reversed */
  totalReversed: number
  /** Total write-offs still pending approval */
  totalPending: number
  /** Sum of approved write-off amounts (cents CAD) */
  approvedAmount: number
  /** Sum of rejected write-off amounts (cents CAD) */
  rejectedAmount: number
  /** Sum of reversed write-off amounts (cents CAD) */
  reversedAmount: number
  /** Sum of pending write-off amounts (cents CAD) */
  pendingAmount: number
  /** Breakdown of write-offs by reason */
  byReason: Record<
    WriteOffReason,
    { count: number; amount: number }
  >
  /** Monthly write-off trend */
  monthlyTrend: Array<{ month: string; amount: number; count: number }>
  /** Average write-off amount (cents CAD) */
  averageAmount: number
  /** Percentage of write-offs auto-approved */
  autoApprovedPercentage: number
}

/**
 * Write-off management service for CollectRx.
 *
 * Manages the complete lifecycle of patient balance write-offs including
 * creation, approval workflows, reversals, and integration with patient
 * ledger for audit trail compliance.
 */
export class WriteOffService {
  /**
   * Creates a new WriteOffService instance.
   *
   * @param defaultPolicy - Default write-off policy to apply if none specified
   */
  constructor(private defaultPolicy?: WriteOffPolicy) {}

  /**
   * Creates a new write-off request.
   *
   * Validates the write-off against policy, determines if auto-approval
   * conditions are met, and generates the write-off record.
   *
   * @param params - Write-off creation parameters
   * @param params.patientId - Patient whose balance is being written off
   * @param params.practiceId - Practice initiating the write-off
   * @param params.claimId - Optional insurance claim reference
   * @param params.amount - Amount in cents (CAD) to write off
   * @param params.reason - Reason for the write-off
   * @param params.notes - Additional context notes
   * @param params.requestedBy - User ID requesting the write-off
   * @param policy - Optional write-off policy to apply (uses default if not provided)
   * @returns The created WriteOff record
   * @throws Error if amount is invalid or reason is not allowed by policy
   */
  async createWriteOff(
    params: {
      patientId: string
      practiceId: string
      claimId?: string
      amount: number
      reason: WriteOffReason
      notes: string
      requestedBy: string
    },
    policy?: WriteOffPolicy,
  ): Promise<WriteOff> {
    // Validate amount
    if (params.amount <= 0) {
      throw new Error('Write-off amount must be greater than 0')
    }

    const effectivePolicy =
      policy || this.defaultPolicy || this.getDefaultPolicy()

    // Validate against policy
    const validation = this.validateAgainstPolicy(
      params.amount,
      params.reason,
      effectivePolicy,
    )
    if (!validation.valid) {
      throw new Error(
        `Write-off validation failed: ${validation.errors.join(', ')}`,
      )
    }

    // Determine auto-approval status
    const autoApproved =
      !validation.requiresApproval ||
      params.amount <= effectivePolicy.autoApproveThreshold

    const now = new Date().toISOString()

    const writeOff: WriteOff = {
      id: uuidv4(),
      patientId: params.patientId,
      practiceId: params.practiceId,
      claimId: params.claimId,
      amount: params.amount,
      reason: params.reason,
      status: autoApproved ? 'approved' : 'pending_approval',
      notes: params.notes,
      requestedBy: params.requestedBy,
      requestedAt: now,
      ...(autoApproved && {
        approvedBy: 'system_auto',
        approvedAt: now,
      }),
      createdAt: now,
    }

    return writeOff
  }

  /**
   * Approves a pending write-off request.
   *
   * Transitions the write-off from pending_approval to approved status.
   *
   * @param writeOff - The write-off to approve
   * @param approvedBy - User ID of the approver
   * @returns Updated WriteOff with approved status
   * @throws Error if write-off is not in pending_approval status
   */
  approveWriteOff(writeOff: WriteOff, approvedBy: string): WriteOff {
    if (writeOff.status !== 'pending_approval') {
      throw new Error(
        `Cannot approve write-off with status: ${writeOff.status}. Only pending_approval can be approved.`,
      )
    }

    const now = new Date().toISOString()

    return {
      ...writeOff,
      status: 'approved' as WriteOffStatus,
      approvedBy,
      approvedAt: now,
    }
  }

  /**
   * Rejects a pending write-off request.
   *
   * Transitions the write-off from pending_approval to rejected status
   * with rejection reason recorded.
   *
   * @param writeOff - The write-off to reject
   * @param rejectedBy - User ID of the person rejecting
   * @param rejectionReason - Reason for rejection
   * @returns Updated WriteOff with rejected status
   * @throws Error if write-off is not in pending_approval status
   */
  rejectWriteOff(
    writeOff: WriteOff,
    rejectedBy: string,
    rejectionReason: string,
  ): WriteOff {
    if (writeOff.status !== 'pending_approval') {
      throw new Error(
        `Cannot reject write-off with status: ${writeOff.status}. Only pending_approval can be rejected.`,
      )
    }

    const now = new Date().toISOString()

    return {
      ...writeOff,
      status: 'rejected' as WriteOffStatus,
      rejectedBy,
      rejectedAt: now,
      rejectionReason,
    }
  }

  /**
   * Reverses a previously approved write-off.
   *
   * Transitions the write-off to reversed status. The balance credit
   * is restored to the patient account via ledger adjustment.
   *
   * @param writeOff - The approved write-off to reverse
   * @param reversalReason - Reason for reversal
   * @returns Updated WriteOff with reversed status
   * @throws Error if write-off is not in approved status
   */
  reverseWriteOff(writeOff: WriteOff, reversalReason: string): WriteOff {
    if (writeOff.status !== 'approved') {
      throw new Error(
        `Cannot reverse write-off with status: ${writeOff.status}. Only approved write-offs can be reversed.`,
      )
    }

    const now = new Date().toISOString()

    return {
      ...writeOff,
      status: 'reversed' as WriteOffStatus,
      reversedAt: now,
      reversalReason,
    }
  }

  /**
   * Processes small balance write-offs in batch.
   *
   * Automatically writes off all balances at or below the specified threshold
   * with small_balance reason. All write-offs are auto-approved.
   *
   * @param balances - Array of patient balances to process
   * @param threshold - Amount threshold in cents (CAD)
   * @param requestedBy - User ID requesting the batch write-off
   * @returns Created write-offs with totals and count
   */
  async processSmallBalanceWriteOffs(
    balances: Array<{ patientId: string; practiceId: string; netBalance: number }>,
    threshold: number,
    requestedBy: string,
  ): Promise<{ writeOffs: WriteOff[]; totalAmount: number; count: number }> {
    const writeOffs: WriteOff[] = []
    let totalAmount = 0

    for (const balance of balances) {
      if (balance.netBalance > 0 && balance.netBalance <= threshold) {
        const now = new Date().toISOString()
        const writeOff: WriteOff = {
          id: uuidv4(),
          patientId: balance.patientId,
          practiceId: balance.practiceId,
          amount: balance.netBalance,
          reason: 'small_balance',
          status: 'approved',
          notes: `Auto-approved small balance write-off under $${(threshold / 100).toFixed(2)} threshold`,
          requestedBy,
          requestedAt: now,
          approvedBy: 'system_auto',
          approvedAt: now,
          createdAt: now,
        }

        writeOffs.push(writeOff)
        totalAmount += balance.netBalance
      }
    }

    return {
      writeOffs,
      totalAmount,
      count: writeOffs.length,
    }
  }

  /**
   * Validates a write-off request against policy.
   *
   * Checks that the reason is allowed and the amount is within policy limits.
   * Determines whether the write-off requires approval or can be auto-approved.
   *
   * @param amount - Write-off amount in cents (CAD)
   * @param reason - Write-off reason
   * @param policy - Write-off policy to validate against
   * @returns Validation result with any error messages
   */
  validateAgainstPolicy(
    amount: number,
    reason: WriteOffReason,
    policy: WriteOffPolicy,
  ): { valid: boolean; requiresApproval: boolean; errors: string[] } {
    const errors: string[] = []

    // Check reason is allowed
    if (!policy.allowedReasons.includes(reason)) {
      errors.push(
        `Reason '${reason}' not allowed by policy. Allowed: ${policy.allowedReasons.join(', ')}`,
      )
    }

    // Determine if approval is required
    const requiresApproval = amount > policy.autoApproveThreshold

    return {
      valid: errors.length === 0,
      requiresApproval,
      errors,
    }
  }

  /**
   * Gets the default write-off policy.
   *
   * Returns a sensible default policy with:
   * - Auto-approval for amounts <= $10 CAD (1000 cents)
   * - Manual approval required above $10
   * - Monthly cap of $5,000 CAD
   * - All write-off reasons allowed
   *
   * @returns Default WriteOffPolicy
   */
  getDefaultPolicy(): WriteOffPolicy {
    return {
      practiceId: '', // Will be set by caller
      autoApproveThreshold: 1000, // $10 CAD
      requireApprovalAbove: 1000, // $10 CAD
      maxMonthlyTotal: 500000, // $5,000 CAD
      allowedReasons: [
        'uncollectible',
        'insurance_denial',
        'billing_error',
        'courtesy_adjustment',
        'small_balance',
        'hardship',
        'other',
      ],
      updatedAt: new Date().toISOString(),
    }
  }

  /**
   * Generates a comprehensive write-off summary report.
   *
   * Aggregates write-off metrics by status, reason, and time period.
   * Includes monthly trends and auto-approval statistics.
   *
   * @param writeOffs - Array of write-offs to summarize
   * @param dateRange - Optional date range filter (ISO 8601 dates)
   * @returns WriteOffSummary report
   */
  generateWriteOffSummary(
    writeOffs: WriteOff[],
    dateRange?: { from: string; to: string },
  ): WriteOffSummary {
    // Filter by date range if provided
    let filtered = writeOffs
    if (dateRange) {
      const fromDate = new Date(dateRange.from)
      const toDate = new Date(dateRange.to)
      filtered = writeOffs.filter((wo) => {
        const createdDate = new Date(wo.createdAt)
        return createdDate >= fromDate && createdDate <= toDate
      })
    }

    // Count by status
    const statusCounts = {
      pending_approval: 0,
      approved: 0,
      rejected: 0,
      reversed: 0,
    }

    const statusAmounts = {
      pending_approval: 0,
      approved: 0,
      rejected: 0,
      reversed: 0,
    }

    // Count by reason
    const reasonBreakdown: Record<
      WriteOffReason,
      { count: number; amount: number }
    > = {
      uncollectible: { count: 0, amount: 0 },
      insurance_denial: { count: 0, amount: 0 },
      billing_error: { count: 0, amount: 0 },
      courtesy_adjustment: { count: 0, amount: 0 },
      small_balance: { count: 0, amount: 0 },
      hardship: { count: 0, amount: 0 },
      other: { count: 0, amount: 0 },
    }

    // Count auto-approved (system_auto)
    let autoApprovedCount = 0

    // Monthly trend
    const monthlyMap: Record<string, { amount: number; count: number }> = {}

    for (const writeOff of filtered) {
      // Status counts
      statusCounts[writeOff.status]++
      statusAmounts[writeOff.status] += writeOff.amount

      // Reason breakdown
      reasonBreakdown[writeOff.reason].count++
      reasonBreakdown[writeOff.reason].amount += writeOff.amount

      // Auto-approved tracking
      if (writeOff.approvedBy === 'system_auto') {
        autoApprovedCount++
      }

      // Monthly trend
      const month = writeOff.createdAt.substring(0, 7) // YYYY-MM
      if (!monthlyMap[month]) {
        monthlyMap[month] = { amount: 0, count: 0 }
      }
      monthlyMap[month].amount += writeOff.amount
      monthlyMap[month].count++
    }

    // Build monthly trend array
    const monthlyTrend = Object.entries(monthlyMap)
      .sort()
      .map(([month, data]) => ({
        month,
        amount: data.amount,
        count: data.count,
      }))

    // Calculate averages
    const totalCount = filtered.length
    const totalAmount = statusAmounts.approved +
      statusAmounts.rejected +
      statusAmounts.pending_approval +
      statusAmounts.reversed || 1 // Avoid division by zero
    const averageAmount = totalCount > 0 ? Math.round(totalAmount / totalCount) : 0
    const autoApprovedPercentage =
      totalCount > 0
        ? Math.round((autoApprovedCount / totalCount) * 100)
        : 0

    return {
      totalRequested: totalCount,
      totalApproved: statusCounts.approved,
      totalRejected: statusCounts.rejected,
      totalReversed: statusCounts.reversed,
      totalPending: statusCounts.pending_approval,
      approvedAmount: statusAmounts.approved,
      rejectedAmount: statusAmounts.rejected,
      reversedAmount: statusAmounts.reversed,
      pendingAmount: statusAmounts.pending_approval,
      byReason: reasonBreakdown,
      monthlyTrend,
      averageAmount,
      autoApprovedPercentage,
    }
  }

  /**
   * Creates a patient ledger entry for an approved write-off.
   *
   * Records the write-off as a credit (negative amount) to the patient account
   * in the audit trail. This reduces the patient's outstanding balance.
   *
   * @param writeOff - The approved write-off
   * @returns PatientLedgerEntry representing the write-off
   */
  createLedgerEntry(writeOff: WriteOff): PatientLedgerEntry {
    return {
      id: uuidv4(),
      patientId: writeOff.patientId,
      practiceId: writeOff.practiceId,
      type: 'write_off',
      amount: -writeOff.amount, // Negative: credit to patient
      description: `Write-off: ${writeOff.reason}${
        writeOff.claimId ? ` (Claim: ${writeOff.claimId})` : ''
      }. ${writeOff.notes}`,
      referenceId: writeOff.id,
      balanceAfter: 0, // Will be calculated by ledger system
      createdAt: writeOff.approvedAt || writeOff.createdAt,
      createdBy: writeOff.approvedBy || writeOff.requestedBy,
    }
  }

  /**
   * Creates a patient ledger entry for a write-off reversal.
   *
   * Records the reversal as a debit (positive amount) to the patient account,
   * restoring the written-off balance to outstanding accounts receivable.
   *
   * @param writeOff - The reversed write-off
   * @returns PatientLedgerEntry representing the reversal
   */
  createReversalLedgerEntry(writeOff: WriteOff): PatientLedgerEntry {
    return {
      id: uuidv4(),
      patientId: writeOff.patientId,
      practiceId: writeOff.practiceId,
      type: 'adjustment',
      amount: writeOff.amount, // Positive: debit, balance restored
      description: `Reversal of write-off ${writeOff.id}: ${writeOff.reversalReason}. Original reason: ${writeOff.reason}`,
      referenceId: writeOff.id,
      balanceAfter: 0, // Will be calculated by ledger system
      createdAt: writeOff.reversedAt || writeOff.createdAt,
      createdBy: 'system', // Reversals are system-generated
    }
  }
}
