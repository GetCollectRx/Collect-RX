/**
 * CollectRx Eligibility Engine — Type Definitions
 *
 * Comprehensive type system for the dental insurance eligibility calculator,
 * serving 6 Canadian carriers (Sun Life, Great-West, Manulife, Green Shield, RBC, Telus).
 *
 * This module defines the complete data model for:
 * - Carrier & plan configuration
 * - Patient & insurance coverage data
 * - Procedure estimates & COB calculations
 * - Claims reconciliation & variance analysis
 */

// ============================================================================
// === CARRIER & PLAN CONFIGURATION ===
// ============================================================================

/**
 * Coverage tier — the category a procedure falls into for benefit calculation.
 * Used to determine coverage percentages and waiting period applicability.
 */
export type CoverageTier =
  | 'preventive'     // Cleanings, exams, X-rays (typically 100%)
  | 'basic'          // Fillings, extractions, root canals (typically 70–80%)
  | 'major'          // Crowns, bridges, implants (typically 50%)
  | 'orthodontic'    // Braces, aligners
  | 'endodontic'     // Root canal therapy
  | 'periodontic'    // Gum surgery, scaling
  | 'prosthodontic'; // Dentures, partial dentures

/**
 * Carrier code — identifier for the 6 supported Canadian dental insurance carriers.
 * Used throughout the system to reference carrier-specific rules.
 */
export type CarrierCode =
  | 'sunlife_private'    // Sun Life (private/group plans)
  | 'great_west'         // Great-West Life
  | 'manulife'           // Manulife Financial
  | 'green_shield'       // Green Shield Canada
  | 'rbc_insurance'      // RBC Insurance
  | 'telus_adjudicare';  // Telus Adjudicare

/**
 * FrequencyRule — defines how often a procedure can be claimed under a plan.
 *
 * Examples:
 * - Prophy (D1110): max 2 per year (24 months)
 * - Exam (D0120): max 2 per year (24 months)
 * - Periapical X-ray (D0220): max 4 per year (12 months)
 * - Full mouth series (D0210): max 1 per 36 months
 *
 * @interface
 */
export interface FrequencyRule {
  /** CDT codes this rule applies to (e.g., ['D1110', 'D1120']) */
  cdtCodes: string[];

  /** Human-readable description (e.g., "Cleaning — 2x per calendar year") */
  description: string;

  /** Maximum times this procedure can be claimed in the period */
  maxPerPeriod: number;

  /**
   * Period in months for the frequency limit.
   * Examples: 12 (calendar year), 24 (every 2 years), 36 (every 3 years)
   */
  periodMonths: number;

  /**
   * Whether the frequency limit is per-tooth or per-patient.
   * True = each tooth can have max X claims; False = patient total is max X
   */
  perTooth: boolean;

  /**
   * Optional reset behavior. If provided, frequency count resets
   * on the specified date or pattern (e.g., "calendar_year", "plan_anniversary")
   */
  resetPattern?: 'calendar_year' | 'plan_anniversary' | 'rolling';
}

/**
 * WaitingPeriodRule — defines waiting periods before a coverage tier becomes active.
 *
 * Waiting periods prevent immediate coverage of expensive procedures
 * when a plan first starts or when a patient upgrades coverage.
 *
 * @interface
 */
export interface WaitingPeriodRule {
  /** Coverage tier this waiting period applies to */
  tier: CoverageTier;

  /** Number of months from effective date before this tier is covered */
  months: number;

  /** Does this waiting period apply only to new plan enrollments? */
  appliesToNewPlans: boolean;

  /** Does this waiting period apply when switching plans? */
  appliesToPlanChanges: boolean;

  /** Human-readable description (e.g., "6-month wait on major coverage") */
  description?: string;
}

/**
 * CarrierConfig — complete carrier rule definition (JSON-serializable).
 *
 * This is the master configuration for a single carrier, containing all rules
 * needed to calculate eligibility, coverage percentages, deductibles, and COB.
 * Loaded from JSON and cached in the rules engine.
 *
 * @interface
 */
export interface CarrierConfig {
  /** Carrier identifier (one of the 6 supported carriers) */
  code: CarrierCode;

  /** Human-readable carrier name (e.g., "Sun Life Private") */
  name: string;

  /**
   * Coverage percentages by tier.
   * Example: { preventive: 100, basic: 80, major: 50, orthodontic: 50 }
   * Represents the percentage of the provider fee insurance will cover.
   */
  coveragePercentages: Record<CoverageTier, number>;

  /** Deductible configuration */
  deductible: {
    /** Annual individual deductible in cents or dollars */
    individual: number;

    /** Annual family deductible (aggregate across all family members) */
    family: number;

    /** If true, preventive services do not count toward deductible */
    waiveForPreventive: boolean;

    /** Coverage tiers to which deductible applies */
    appliesToTiers: CoverageTier[];

    /** Optional: deductible applies per-member (vs. aggregate) in family plans */
    perMember?: boolean;
  };

  /** Annual maximum coverage */
  annualMax: {
    /** Per-person annual maximum benefit */
    individual: number;

    /** Optional: family aggregate annual maximum */
    familyMax?: number;

    /** Whether preventive procedures count toward annual maximum */
    includesPreventive: boolean;

    /** Optional: per-tier annual maximums (e.g., major procedures capped separately) */
    byTier?: Record<CoverageTier, number>;
  };

  /** All frequency rules for this carrier */
  frequencyRules: FrequencyRule[];

  /** All waiting period rules for this carrier */
  waitingPeriods: WaitingPeriodRule[];

  /**
   * Coordination of Benefits method used by this carrier.
   * - 'standard': lesser of (plan benefit, amount payable)
   * - 'non_duplication': reduces secondary benefit to avoid duplication
   * - 'carve_out': secondary only pays for specific carved-out procedures
   */
  cobMethod: 'standard' | 'non_duplication' | 'carve_out';

  /** Carrier-specific quirks, edge cases, and implementation notes */
  notes: string[];

  /** Optional: when this configuration was last updated */
  lastUpdated?: string; // ISO datetime

  /** Optional: configuration version for tracking changes */
  version?: string;
}

// ============================================================================
// === PATIENT & PLAN DATA ===
// ============================================================================

/**
 * Relationship of patient to insurance subscriber.
 * Used for family plan eligibility and COB determination.
 */
export type RelationshipToSubscriber =
  | 'self'      // Patient is the subscriber/primary
  | 'spouse'    // Patient is spouse of subscriber
  | 'child'     // Patient is child of subscriber
  | 'dependent'; // Patient is other dependent

/**
 * Patient — demographic and insurance enrollment data.
 *
 * Identifies a patient and their insurance coverage relationships.
 * Multiple plans can be linked to a single patient (primary/secondary coverage).
 *
 * @interface
 */
export interface Patient {
  /** Unique patient identifier in CollectRx system */
  id: string;

  /** Patient's first name */
  firstName: string;

  /** Patient's last name */
  lastName: string;

  /** Date of birth (ISO date YYYY-MM-DD) — used for age-based coverage rules */
  dateOfBirth: string;

  /** Insurance ID / Member ID provided by the carrier */
  insuranceId: string;

  /** Group number from the employer/plan */
  groupNumber: string;

  /** Patient's relationship to the policy subscriber */
  relationshipToSubscriber: RelationshipToSubscriber;

  /**
   * If patient is a dependent, link to the subscriber's patient ID.
   * Allows aggregating family deductibles and annual maximums.
   */
  subscriberId?: string;

  /** Optional: patient's preferred language for communications */
  language?: 'en' | 'fr';

  /** Optional: contact email for estimate delivery */
  email?: string;

  /** Optional: contact phone for verification calls */
  phone?: string;
}

/**
 * Plan — insurance plan enrollment record for a patient.
 *
 * Represents a single instance of coverage. A patient may have multiple
 * plans (e.g., primary + secondary) with different carriers or plan types.
 *
 * @interface
 */
export interface Plan {
  /** Unique plan identifier */
  id: string;

  /** Patient this plan is enrolled under */
  patientId: string;

  /** Carrier of this plan */
  carrierCode: CarrierCode;

  /** Friendly name of the plan (e.g., "Comprehensive Plus") */
  planName: string;

  /** Group number (for group plans) */
  groupNumber: string;

  /** When coverage became effective (ISO date YYYY-MM-DD) */
  effectiveDate: string;

  /** When coverage ends, if terminated (ISO date YYYY-MM-DD) */
  terminationDate?: string;

  /** Plan type: employer group or individual */
  planType: 'group' | 'individual';

  /**
   * For Coordination of Benefits: is this the primary plan?
   * Only one plan should be primary for a patient.
   */
  isPrimary: boolean;

  /**
   * COB sequence number: 1 = primary, 2 = secondary, etc.
   * Determines payment order.
   */
  sequence?: number;

  /** Optional: carrier's internal policy number */
  policyNumber?: string;

  /** Optional: date when eligibility was last verified with carrier */
  lastVerifiedDate?: string;

  /** Optional: notes about the plan (e.g., "Coverage under spouse's plan") */
  notes?: string;
}

// ============================================================================
// === ELIGIBILITY SNAPSHOT ===
// ============================================================================

/**
 * ClaimHistoryEntry — record of a claim processed this year.
 *
 * Used for frequency rule enforcement (e.g., "patient already had 2 cleanings,
 * can't have another until next year").
 *
 * @interface
 */
export interface ClaimHistoryEntry {
  /** Claim ID in the system */
  claimId: string;

  /** CDT code of the procedure claimed */
  cdtCode: string;

  /** Date procedure was performed (ISO date) */
  dateOfService: string;

  /** Amount the dentist billed */
  amountBilled: number;

  /** Amount insurance paid */
  amountPaid: number;

  /** Optional: specific tooth affected (for per-tooth frequency tracking) */
  toothNumber?: string;

  /** Optional: date claim was processed */
  processedDate?: string;

  /** Optional: claim status (approved, partial, denied, pending) */
  status?: 'approved' | 'partial' | 'denied' | 'pending';
}

/**
 * EligibilitySnapshot — a point-in-time record of patient's coverage status.
 *
 * Captured from carrier at time of estimate request. Includes current-year
 * deductible and annual max usage, plus claims history for frequency checks.
 * Multiple snapshots can exist for the same plan (tracking changes over time).
 *
 * @interface
 */
export interface EligibilitySnapshot {
  /** Unique snapshot ID */
  id: string;

  /** Patient this snapshot belongs to */
  patientId: string;

  /** Plan this snapshot describes */
  planId: string;

  /** When this snapshot was captured (ISO datetime) */
  capturedAt: string;

  /**
   * Data source for this eligibility record.
   * Affects confidence score (verified directly with carrier is higher confidence).
   */
  source:
    | 'abeldent_sync'   // Synced from Abeldent (PMS)
    | 'carrier_lookup'  // Verified directly with carrier
    | 'manual_entry';   // Manually entered by staff

  /** Is this coverage currently active? */
  isActive: boolean;

  /** Coverage effective date (ISO date) */
  effectiveDate: string;

  /** Coverage termination date, if applicable (ISO date) */
  terminationDate?: string;

  /** Deductible used this plan year */
  deductibleUsed: {
    /** Individual deductible amount used */
    individual: number;

    /** Family aggregate deductible used */
    family: number;
  };

  /** Annual maximum used this plan year */
  annualMaxUsed: {
    /** Individual annual max used */
    individual: number;

    /** Optional: per-family-member annual max usage */
    byMember?: Record<string, number>; // key = patientId

    /** Optional: per-tier annual max usage */
    byTier?: Record<CoverageTier, number>;
  };

  /**
   * When eligibility data was last confirmed with the carrier.
   * Used to assess confidence in estimates.
   */
  lastVerifiedDate?: string;

  /** Claims processed this plan year (used for frequency checking) */
  claimsHistory: ClaimHistoryEntry[];

  /** Optional: notes about eligibility (e.g., "On hold pending documentation") */
  notes?: string;
}

// ============================================================================
// === PROCEDURE & ESTIMATE ===
// ============================================================================

/**
 * ProcedureInput — input data for a single procedure in an estimate request.
 *
 * Dentist provides this information when requesting a patient estimate.
 * The engine matches CDT codes to carrier rules and calculates benefits.
 *
 * @interface
 */
export interface ProcedureInput {
  /** CDT code of the procedure (e.g., "D1110" for adult prophy) */
  cdtCode: string;

  /** Optional: description of the procedure for clarity */
  description?: string;

  /** Fee the dentist charges for this procedure */
  providerFee: number;

  /** Quantity (usually 1, but can be >1 for multiple units) */
  quantity: number;

  /** Date procedure will be/was performed (ISO date) */
  dateOfService: string;

  /**
   * Optional: specific tooth number (1–32, or FDI notation).
   * Required for per-tooth frequency limits (e.g., crown on tooth #14).
   */
  toothNumber?: string;

  /**
   * Optional: surfaces treated (e.g., "MOD" for mesial-occlusal-distal).
   * For insurance classification and predetermination.
   */
  surface?: string;

  /** Optional: clinical notes or additional context */
  notes?: string;
}

/**
 * ProcedureEstimate — calculated estimate for a single procedure.
 *
 * Result of running a procedure through the eligibility rules.
 * Shows coverage percentage, patient responsibility, and any limitations.
 *
 * @interface
 */
export interface ProcedureEstimate {
  /** CDT code */
  cdtCode: string;

  /** Procedure description from carrier fee schedule or input */
  description: string;

  /** Benefit tier (preventive, basic, major, etc.) */
  tier: CoverageTier;

  /** Provider's fee for this procedure */
  providerFee: number;

  /** Quantity of this procedure */
  quantity: number;

  /** Coverage percentage from plan (e.g., 80 for 80%) */
  coveragePercentage: number;

  /** Calculated amount insurance should pay (after all deductions) */
  insurancePortion: number;

  /** Calculated amount patient owes (before COB) */
  patientPortion: number;

  /** Deductible applied to this procedure */
  deductibleApplied: number;

  /** Portion of this procedure applied toward annual maximum */
  annualMaxApplied: number;

  /** Was this procedure limited by frequency rules? */
  frequencyLimited: boolean;

  /** Optional: explanation of frequency limitation (e.g., "2x cleaning limit reached") */
  frequencyNote?: string;

  /** Does a waiting period apply to this procedure? */
  waitingPeriodApplies: boolean;

  /** Optional: waiting period explanation (e.g., "6-month wait on major, expires 2026-09-15") */
  waitingPeriodNote?: string;

  /** Is this procedure excluded from coverage under the plan? */
  excluded: boolean;

  /** Optional: reason for exclusion */
  exclusionReason?: string;

  /** Additional notes, warnings, or assumptions */
  notes: string[];

  /** Optional: tooth number (if provided in input) */
  toothNumber?: string;
}

/**
 * ConfidenceLevel — qualitative confidence assessment.
 *
 * Indicates how reliable the estimate is based on:
 * - Data freshness (how recently eligibility was verified)
 * - Data source (direct carrier vs. PMS vs. manual entry)
 * - Plan complexity (family plans, COB, etc.)
 */
export type ConfidenceLevel = 'high' | 'medium' | 'low';

/**
 * ConfidenceFactor — single factor contributing to estimate confidence.
 *
 * Estimate confidence is the sum of all factors (capped at 0–100).
 * Allows clients to understand why a score is high or low.
 *
 * @interface
 */
export interface ConfidenceFactor {
  /** Name of the factor (e.g., "eligibility_verified", "plan_change_recent") */
  factor: string;

  /**
   * Impact on confidence score (-20 to +20).
   * Negative = reduces confidence, positive = increases confidence.
   */
  impact: number;

  /** Human-readable explanation */
  description: string;
}

/**
 * EstimateResult — complete estimate for a patient's treatment plan.
 *
 * Output of the eligibility engine. Contains line-item estimates for each
 * procedure, summary totals, confidence assessment, and assumptions/warnings.
 *
 * @interface
 */
export interface EstimateResult {
  /** Unique estimate ID */
  id: string;

  /** Patient this estimate is for */
  patientId: string;

  /** Plan this estimate is based on */
  planId: string;

  /** Carrier code (from the plan) */
  carrierCode: CarrierCode;

  /** When this estimate was created (ISO datetime) */
  createdAt: string;

  /** All estimated procedures */
  procedures: ProcedureEstimate[];

  /** Summary totals */
  summary: {
    /** Sum of all provider fees */
    totalProviderFees: number;

    /** Sum of all insurance portions (what insurance should pay) */
    totalInsurancePortion: number;

    /** Sum of all patient portions (deductible + coinsurance) */
    totalPatientPortion: number;

    /** Total deductible applied across all procedures */
    totalDeductibleApplied: number;

    /** Remaining annual max available */
    annualMaxRemaining: number;

    /** Deductible remaining (individual and family) */
    deductibleRemaining: {
      individual: number;
      family: number;
    };

    /** Optional: per-tier breakdown */
    byTier?: Record<CoverageTier, {
      totalFees: number;
      insurancePortion: number;
      patientPortion: number;
    }>;
  };

  /** Confidence assessment */
  confidence: {
    /** Confidence score 0–100 */
    score: number;

    /** Qualitative level (high, medium, low) */
    level: ConfidenceLevel;

    /** Individual factors contributing to the score */
    factors: ConfidenceFactor[];
  };

  /**
   * List of assumptions the estimate is based on.
   * Examples:
   * - "Deductible from plan snapshot dated 2026-03-15"
   * - "Annual maximum calculated from effective date 2026-01-01"
   * - "Preventive coverage waives deductible per plan rules"
   */
  assumptions: string[];

  /**
   * Warnings or potential issues the dentist should know about.
   * Examples:
   * - "Waiting period applies: major coverage begins 2026-09-15"
   * - "Patient at 90% of annual maximum; some procedures may not be fully covered"
   * - "Frequency check failed: patient already had 2 cleanings this year"
   */
  warnings: string[];

  /** Optional: detailed explanation of estimate methodology */
  methodology?: string;

  /** Optional: when this estimate expires (ISO date) */
  expiresAt?: string;
}

// ============================================================================
// === RECONCILIATION ===
// ============================================================================

/**
 * ActualClaimPayment — actual payment received from insurance carrier.
 *
 * After claim submission, carrier provides payment details (usually via EOB).
 * Used to reconcile against pre-claim estimate and identify variances.
 *
 * @interface
 */
export interface ActualClaimPayment {
  /** Carrier's claim ID or reference number */
  claimId: string;

  /** Patient the claim is for */
  patientId: string;

  /** Plan used for this claim */
  planId: string;

  /** Carrier that processed the claim */
  carrierCode: CarrierCode;

  /** CDT code of procedure claimed */
  cdtCode: string;

  /** Date procedure was performed (ISO date) */
  dateOfService: string;

  /** Amount dentist billed */
  amountBilled: number;

  /** Amount carrier actually paid */
  amountPaid: number;

  /** Amount carrier denied/rejected */
  amountDenied: number;

  /** Optional: reason for any denial (e.g., "Exceeds frequency limit") */
  denialReason?: string;

  /**
   * Optional: adjustment codes from carrier (e.g., "FREQ" for frequency limit,
   * "WAIT" for waiting period, "ANNUAL_MAX" for annual maximum exceeded)
   */
  adjustmentCodes?: string[];

  /** Date carrier paid the claim (ISO date) */
  paymentDate: string;

  /** Optional: reference number from EOB for verification */
  eobReference?: string;

  /** Optional: patient's responsibility (what insurance determined patient owes) */
  patientResponsibility?: number;

  /** Optional: explanation of adjustment (free-text from carrier) */
  adjustmentExplanation?: string;
}

/**
 * VarianceReason — explanation for difference between estimate and actual payment.
 *
 * The estimate might predict $80 coverage, but carrier actually paid $50.
 * Variance reasons explain why (e.g., deductible not met, frequency limit, etc.).
 */
export type VarianceReason =
  | 'deductible_not_met'         // Deductible wasn't satisfied
  | 'annual_max_exceeded'        // Claim exceeded remaining annual max
  | 'frequency_limit'            // Procedure claimed too many times
  | 'waiting_period'             // Waiting period not satisfied
  | 'procedure_excluded'         // Carrier excluded this procedure
  | 'coverage_percentage_different'  // Actual % differs from plan
  | 'cob_adjustment'             // Reduced due to COB with other plan
  | 'plan_terminated'            // Coverage wasn't active on DOS
  | 'claim_denied'               // Claim denied for other reason
  | 'fee_schedule_difference'    // Carrier's allowed amount less than billed
  | 'other';                     // Unclassified reason

/**
 * ReconciliationResult — comparison of estimated vs. actual claim payment.
 *
 * After claim is paid, system reconciles actual payment against pre-claim estimate.
 * Identifies variances and suggests patient account adjustments (write-offs, etc.).
 *
 * @interface
 */
export interface ReconciliationResult {
  /** Unique reconciliation ID */
  id: string;

  /** Estimate this reconciliation is based on */
  estimateId: string;

  /** Actual claim this reconciliation analyzes */
  claimId: string;

  /** Patient the claim is for */
  patientId: string;

  /** Carrier that processed the claim */
  carrierCode: CarrierCode;

  /** When reconciliation was performed (ISO datetime) */
  reconciledAt: string;

  /** Estimated amounts (from pre-claim estimate) */
  estimated: {
    /** What estimate predicted insurance would pay */
    insurancePortion: number;

    /** What estimate predicted patient would owe */
    patientPortion: number;
  };

  /** Actual amounts (from carrier payment) */
  actual: {
    /** What carrier actually paid */
    insurancePaid: number;

    /** What carrier determined patient owes */
    patientResponsibility: number;
  };

  /** Variance analysis */
  variance: {
    /** Difference: actual.insurancePaid - estimated.insurancePortion */
    amount: number;

    /** Variance as percentage of estimated insurance portion */
    percentage: number;

    /** Classified reasons for the variance */
    reasons: VarianceReason[];

    /** Human-readable explanation of the variance */
    explanation: string;
  };

  /** Suggested patient account adjustment */
  adjustment: {
    /** Type of adjustment to make */
    type: 'none' | 'patient_balance_increase' | 'patient_balance_decrease' | 'write_off';

    /** Dollar amount of adjustment */
    amount: number;

    /** Why this adjustment is recommended */
    reason: string;
  };

  /** Optional: notes for front desk or accounting staff */
  notes?: string;
}

// ============================================================================
// === COORDINATION OF BENEFITS (COB) ===
// ============================================================================

/**
 * COBCalculation — result of coordinating benefits between two plans.
 *
 * When patient has primary and secondary coverage, COB determines:
 * 1. How much primary plan pays
 * 2. How much secondary plan pays
 * 3. Total coverage (should not exceed provider fee)
 * 4. Patient's remaining responsibility
 *
 * @interface
 */
export interface COBCalculation {
  /** Primary (first-payer) plan */
  primaryPlan: Plan;

  /** Secondary (second-payer) plan */
  secondaryPlan: Plan;

  /** Amount primary plan will pay */
  primaryPayment: number;

  /** Amount secondary plan will pay */
  secondaryPayment: number;

  /** Total coverage from both plans */
  totalCovered: number;

  /** Patient's remaining responsibility after both plans */
  patientResponsibility: number;

  /**
   * COB method used by the carrier.
   * Affects how secondary benefit is calculated.
   */
  method: 'standard' | 'non_duplication' | 'carve_out';

  /** Detailed explanation of the COB calculation */
  explanation: string;

  /** Optional: per-procedure COB breakdown */
  byProcedure?: Record<string, {
    cdtCode: string;
    primaryPayment: number;
    secondaryPayment: number;
  }>;
}

// ============================================================================
// === ENGINE INPUT/OUTPUT ===
// ============================================================================

/**
 * EstimateRequest — input to the eligibility engine for generating an estimate.
 *
 * Dentist submits this request to get a patient benefit estimate before
 * treatment. Engine looks up carrier rules and calculates coverage.
 *
 * @interface
 */
export interface EstimateRequest {
  /** Patient requesting the estimate */
  patient: Patient;

  /** Primary insurance plan */
  plan: Plan;

  /** Optional: secondary insurance plan (for COB) */
  secondaryPlan?: Plan;

  /** Procedures to estimate */
  procedures: ProcedureInput[];

  /**
   * Optional: current eligibility snapshot.
   * If not provided, engine will attempt to retrieve or use defaults.
   */
  eligibility?: EligibilitySnapshot;

  /** Optional: secondary plan eligibility (for COB) */
  secondaryEligibility?: EligibilitySnapshot;

  /** Optional: request timestamp (defaults to now) */
  requestedAt?: string;

  /** Optional: notes or context for the request */
  notes?: string;
}

/**
 * ReconcileRequest — input to reconciliation engine after claim is paid.
 *
 * Submitted after receiving actual payment from carrier.
 * Engine compares actual to estimated and suggests adjustments.
 *
 * @interface
 */
export interface ReconcileRequest {
  /** Estimate to reconcile against */
  estimateId: string;

  /** Actual claim payments from carrier */
  actualPayments: ActualClaimPayment[];

  /** Optional: notes or context */
  notes?: string;
}

/**
 * EligibilityStatusResponse — quick status check of a patient's coverage.
 *
 * Lightweight response for real-time eligibility queries (e.g., at front desk).
 * Contains current active status, deductible, and annual max info.
 *
 * @interface
 */
export interface EligibilityStatusResponse {
  /** Is coverage currently active? */
  isActive: boolean;

  /** Coverage effective date (ISO date) */
  effectiveDate: string;

  /** Coverage termination date, if applicable (ISO date) */
  terminationDate?: string;

  /** Individual deductible remaining */
  deductibleRemaining: {
    individual: number;
    family: number;
  };

  /** Annual maximum remaining */
  annualMaxRemaining: number;

  /** Carrier name (human-readable) */
  carrierName: string;

  /** Plan name (human-readable) */
  planName: string;

  /** When this status was last verified (ISO date) */
  lastVerified?: string;

  /** Optional: current-year totals for context */
  usedThisYear?: {
    deductible: number;
    annualMax: number;
  };

  /** Optional: any notes about the coverage */
  notes?: string;
}

/**
 * CobComparison — detailed comparison of plans for COB selection.
 *
 * Helps determine which plan should be primary when patient has multiple options.
 * Compares coverage levels, deductibles, and annual maxes.
 *
 * @interface
 */
export interface CobComparison {
  /** Primary plan candidate */
  primaryPlan: Plan;

  /** Secondary plan candidate */
  secondaryPlan: Plan;

  /** Coverage comparison */
  coverage: {
    primaryCoveragePercentage: number;
    secondaryCoveragePercentage: number;
    primaryCoverageTiers: CoverageTier[];
    secondaryCoverageTiers: CoverageTier[];
  };

  /** Deductible comparison */
  deductibles: {
    primaryIndividual: number;
    primaryFamily: number;
    secondaryIndividual: number;
    secondaryFamily: number;
  };

  /** Annual maximum comparison */
  annualMaxes: {
    primaryIndividual: number;
    secondaryIndividual: number;
  };

  /** Recommendation for which should be primary */
  recommendation: 'plan1_primary' | 'plan2_primary' | 'comparable';

  /** Explanation of recommendation */
  reasoning: string;
}
