/**
 * CollectRx Reconciliation Engine
 *
 * Compares actual insurance claim payments against pre-treatment estimates to identify
 * variance, determine patient balances, and generate adjustment recommendations.
 *
 * This module processes claim reconciliation in three stages:
 * 1. Match procedures to actual payments (by CDT code + date of service)
 * 2. Calculate variance and classify reasons
 * 3. Generate patient statements and identify patterns
 *
 * Production-grade implementation with comprehensive variance analysis and reporting.
 */

import {
  EstimateResult,
  ActualClaimPayment,
  ReconciliationResult,
  VarianceReason,
  Patient,
  CarrierCode,
} from './types';

// ============================================================================
// === INTERFACES ===
// ============================================================================

/**
 * Reconciliation summary showing aggregate variance across all claims.
 * Used for practice-level financial reporting and carrier analysis.
 */
export interface ReconciliationSummary {
  /** Total amount estimated to be paid by insurance */
  totalEstimated: number;

  /** Total amount actually paid by insurance */
  totalActualPaid: number;

  /** Total variance across all claims (actual - estimated) */
  totalVariance: number;

  /** Variance as percentage of total estimated amount */
  variancePercentage: number;

  /** Total adjustment to patient balances (positive = patient owes more) */
  totalPatientBalanceChange: number;

  /** Total amount written off (denied claims) */
  totalWriteOffs: number;

  /**
   * Breakdown of variance by classified reason.
   * Shows how many claims were affected by each variance type and total impact.
   */
  byVarianceReason: Record<
    VarianceReason,
    {
      count: number;
      totalAmount: number;
    }
  >;

  /**
   * Breakdown of variance by insurance carrier.
   * Identifies which carriers consistently over/under pay.
   */
  byCarrier: Record<
    string,
    {
      estimated: number;
      actual: number;
      variance: number;
    }
  >;

  /** List of actionable recommendations for practice leadership */
  recommendations: string[];

  /** When this reconciliation summary was generated (ISO datetime) */
  reconciliationDate: string;
}

/**
 * Systematic variance pattern detected across multiple claims.
 *
 * Identifies when a carrier consistently under/over pays, or when certain procedures
 * have systematic issues. Used to flag configuration errors or carrier-specific quirks.
 */
export interface VariancePattern {
  /** Human-readable description of the pattern */
  pattern: string;

  /** Number of claims affected by this pattern */
  affectedClaims: number;

  /** Total financial impact of this pattern */
  totalImpact: number;

  /** Severity assessment: low (cosmetic), medium (investigate), high (urgent) */
  severity: 'low' | 'medium' | 'high';

  /** Recommended action to resolve the pattern */
  recommendation: string;
}

/**
 * Patient-facing statement showing charges, insurance payments, and balance due.
 *
 * Generated from reconciliation results to communicate actual treatment costs
 * and any adjustments to the patient's account after insurance processes claims.
 */
export interface PatientStatement {
  /** Patient identifier */
  patientId: string;

  /** Patient's full name (for display) */
  patientName: string;

  /** When this statement was generated (ISO date) */
  statementDate: string;

  /**
   * Line-by-line breakdown of services, insurance payments, and patient responsibility.
   * One entry per procedure claim.
   */
  lineItems: Array<{
    /** Date the procedure was performed (ISO date) */
    dateOfService: string;

    /** CDT code and description of the procedure */
    procedure: string;

    /** Amount the provider billed */
    providerFee: number;

    /** Amount insurance actually paid */
    insurancePaid: number;

    /** Amount estimated before claim was adjudicated */
    priorEstimate: number;

    /** Adjustment made after reconciliation (positive = patient owes more) */
    adjustment: number;

    /** Amount patient now owes for this procedure */
    patientOwes: number;
  }>;

  /** Balance patient had before these claims were processed */
  previousBalance: number;

  /** Total new charges (provider fees) from these claims */
  newCharges: number;

  /** Total adjustments (both positive and negative) */
  adjustments: number;

  /** Total amount patient now owes on account */
  totalDue: number;

  /** Suggested due date for payment (ISO date) */
  dueDate: string;
}

// ============================================================================
// === RECONCILIATION ENGINE CLASS ===
// ============================================================================

/**
 * ReconciliationEngine — Core reconciliation logic.
 *
 * Handles matching procedures to payments, calculating variances,
 * detecting patterns, and generating patient statements.
 *
 * @class
 */
export class ReconciliationEngine {
  /**
   * Reconcile an estimate against actual claim payments.
   *
   * For each procedure in the estimate, attempts to find a matching actual payment
   * by CDT code and date of service. Calculates variance and recommends adjustments.
   *
   * Handles:
   * - Perfect match (one procedure → one payment)
   * - Missing payment (claim not yet adjudicated)
   * - Extra payments (payment without matching estimate)
   * - Split payments (multiple payments for same procedure)
   *
   * @param estimate — The pre-claim estimate
   * @param actualPayments — Actual claim payments from carrier
   * @returns Array of reconciliation results (one per matched procedure)
   *
   * @example
   * const engine = new ReconciliationEngine();
   * const results = engine.reconcile(estimate, actualPayments);
   * // results[0].variance.amount < 0 means insurance paid less than estimated
   */
  reconcile(
    estimate: EstimateResult,
    actualPayments: ActualClaimPayment[]
  ): ReconciliationResult[] {
    const results: ReconciliationResult[] = [];
    const matchedPayments = new Set<string>();

    // Process each estimated procedure
    for (const procedure of estimate.procedures) {
      // Find all actual payments matching this procedure (CDT code + DOS)
      const matchingPayments = actualPayments.filter(
        (payment) =>
          payment.cdtCode === procedure.cdtCode &&
          payment.dateOfService === procedure.dateOfService &&
          payment.carrierCode === estimate.carrierCode
      );

      if (matchingPayments.length === 0) {
        // Missing payment — claim not yet adjudicated
        const result = this._buildReconciliationResult(
          estimate,
          procedure,
          null,
          'claim_not_adjudicated'
        );
        results.push(result);
      } else if (matchingPayments.length === 1) {
        // Perfect match
        const payment = matchingPayments[0];
        matchedPayments.add(payment.claimId);
        const result = this._buildReconciliationResult(
          estimate,
          procedure,
          payment,
          null
        );
        results.push(result);
      } else {
        // Split payments — multiple payments for same procedure
        let totalPaid = 0;
        for (const payment of matchingPayments) {
          matchedPayments.add(payment.claimId);
          totalPaid += payment.amountPaid;
        }

        // Create a synthetic payment combining all splits
        const combinedPayment: ActualClaimPayment = {
          ...matchingPayments[0],
          amountPaid: totalPaid,
          adjustmentExplanation: `Split across ${matchingPayments.length} payments`,
        };

        const result = this._buildReconciliationResult(
          estimate,
          procedure,
          combinedPayment,
          'split_payment'
        );
        results.push(result);
      }
    }

    // Flag extra payments (payments without matching estimate)
    for (const payment of actualPayments) {
      if (!matchedPayments.has(payment.claimId)) {
        // Extra payment — not in estimate
        // This might be a correction, supplemental, or orphaned payment
        console.warn(
          `Orphaned payment: claim ${payment.claimId} (${payment.cdtCode} on ${payment.dateOfService}) not in estimate ${estimate.id}`
        );
      }
    }

    return results;
  }

  /**
   * Build a single reconciliation result comparing estimate to actual payment.
   *
   * @private
   */
  private _buildReconciliationResult(
    estimate: EstimateResult,
    procedure: any,
    payment: ActualClaimPayment | null,
    overrideReason: string | null
  ): ReconciliationResult {
    const estimatedInsurance = procedure.insurancePortion;
    const actualInsurance = payment?.amountPaid ?? 0;
    const varianceAmount = actualInsurance - estimatedInsurance;
    const variancePercentage =
      estimatedInsurance > 0
        ? (varianceAmount / estimatedInsurance) * 100
        : 0;

    // Classify variance reasons
    const reasons = this._classifyVarianceReasons(
      procedure,
      payment,
      overrideReason
    );

    // Generate variance explanation
    const explanation = this._generateVarianceExplanation(
      procedure,
      payment,
      varianceAmount,
      reasons
    );

    // Recommend adjustment
    const adjustment = this._recommendAdjustment(
      varianceAmount,
      reasons,
      payment
    );

    return {
      id: `recon_${estimate.id}_${procedure.cdtCode}_${procedure.dateOfService}`,
      estimateId: estimate.id,
      claimId: payment?.claimId ?? `pending_${estimate.id}`,
      patientId: estimate.patientId,
      carrierCode: estimate.carrierCode,
      reconciledAt: new Date().toISOString(),
      estimated: {
        insurancePortion: estimatedInsurance,
        patientPortion: procedure.patientPortion,
      },
      actual: {
        insurancePaid: actualInsurance,
        patientResponsibility: payment?.patientResponsibility ?? 0,
      },
      variance: {
        amount: varianceAmount,
        percentage: variancePercentage,
        reasons,
        explanation,
      },
      adjustment,
      notes: payment?.adjustmentExplanation
        ? `Carrier note: ${payment.adjustmentExplanation}`
        : undefined,
    };
  }

  /**
   * Classify variance reasons based on denial codes, adjustment codes, and claim status.
   *
   * @private
   */
  private _classifyVarianceReasons(
    procedure: any,
    payment: ActualClaimPayment | null,
    overrideReason: string | null
  ): VarianceReason[] {
    const reasons: VarianceReason[] = [];

    // Handle override (used for special cases like claim not adjudicated)
    if (overrideReason === 'claim_not_adjudicated') {
      return ['other'];
    }

    if (!payment) {
      return ['other'];
    }

    // Check for full denial
    if (payment.amountPaid === 0 && payment.amountDenied > 0) {
      reasons.push('claim_denied');
    }

    // Parse adjustment codes if present
    if (payment.adjustmentCodes && payment.adjustmentCodes.length > 0) {
      for (const code of payment.adjustmentCodes) {
        const normalized = code.toUpperCase().trim();

        if (normalized.includes('DEDUCT') || normalized === 'DED') {
          reasons.push('deductible_not_met');
        } else if (
          normalized.includes('ANNUAL') ||
          normalized === 'AMAX' ||
          normalized === 'MAX'
        ) {
          reasons.push('annual_max_exceeded');
        } else if (normalized.includes('FREQ')) {
          reasons.push('frequency_limit');
        } else if (normalized.includes('WAIT') || normalized === 'WP') {
          reasons.push('waiting_period');
        } else if (normalized.includes('EXCL') || normalized === 'EXC') {
          reasons.push('procedure_excluded');
        } else if (normalized.includes('COB')) {
          reasons.push('cob_adjustment');
        } else if (normalized.includes('TERM')) {
          reasons.push('plan_terminated');
        } else if (normalized.includes('FEE') || normalized.includes('ALLOW')) {
          reasons.push('fee_schedule_difference');
        }
      }
    }

    // Check denial reason text
    if (payment.denialReason) {
      const reason = payment.denialReason.toUpperCase();

      if (reason.includes('DEDUCTIBLE')) {
        reasons.push('deductible_not_met');
      } else if (reason.includes('ANNUAL') || reason.includes('MAXIMUM')) {
        reasons.push('annual_max_exceeded');
      } else if (reason.includes('FREQUENCY')) {
        reasons.push('frequency_limit');
      } else if (reason.includes('WAITING')) {
        reasons.push('waiting_period');
      } else if (reason.includes('EXCLUDE') || reason.includes('NOT COVERED')) {
        reasons.push('procedure_excluded');
      } else if (reason.includes('TERMINATE') || reason.includes('TERMINATED')) {
        reasons.push('plan_terminated');
      } else if (reason.includes('FEE') || reason.includes('ALLOWED')) {
        reasons.push('fee_schedule_difference');
      }
    }

    // Infer coverage percentage difference if variance seems systematic
    if (
      reasons.length === 0 &&
      payment.amountPaid > 0 &&
      payment.amountPaid < payment.amountBilled
    ) {
      const actualPercentage =
        (payment.amountPaid / payment.amountBilled) * 100;
      const expectedPercentage = procedure.coveragePercentage;

      if (
        Math.abs(actualPercentage - expectedPercentage) > 5 &&
        actualPercentage > 0
      ) {
        reasons.push('coverage_percentage_different');
      }
    }

    // Default to 'other' if no specific reason found
    if (reasons.length === 0) {
      reasons.push('other');
    }

    // Remove duplicates
    return Array.from(new Set(reasons));
  }

  /**
   * Generate human-readable explanation of the variance.
   *
   * @private
   */
  private _generateVarianceExplanation(
    procedure: any,
    payment: ActualClaimPayment | null,
    varianceAmount: number,
    reasons: VarianceReason[]
  ): string {
    if (!payment) {
      return 'Claim has not been adjudicated yet. No payment received from carrier.';
    }

    if (varianceAmount === 0) {
      return 'Estimate matched actual payment perfectly.';
    }

    if (varianceAmount > 0) {
      // Insurance paid more than estimated
      return (
        `Carrier paid $${(varianceAmount / 100).toFixed(2)} more than estimated. ` +
        `Reason(s): ${reasons.join(', ')}. ` +
        `Patient receives credit for overpayment.`
      );
    }

    // Insurance paid less than estimated
    const shortfall = Math.abs(varianceAmount);
    const shortfallStr = (shortfall / 100).toFixed(2);

    const reasonText = this._explainReasons(reasons);

    return (
      `Carrier paid $${shortfallStr} less than estimated. ` +
      reasonText +
      ` Patient may owe additional amount.`
    );
  }

  /**
   * Convert variance reasons into plain-English explanation.
   *
   * @private
   */
  private _explainReasons(reasons: VarianceReason[]): string {
    const explanations: string[] = [];

    for (const reason of reasons) {
      switch (reason) {
        case 'deductible_not_met':
          explanations.push('Deductible was not fully met');
          break;
        case 'annual_max_exceeded':
          explanations.push('Claim exceeded annual maximum');
          break;
        case 'frequency_limit':
          explanations.push('Procedure frequency limit was exceeded');
          break;
        case 'waiting_period':
          explanations.push('Waiting period had not expired');
          break;
        case 'procedure_excluded':
          explanations.push('Procedure is excluded from coverage');
          break;
        case 'coverage_percentage_different':
          explanations.push('Actual coverage percentage differed from plan');
          break;
        case 'cob_adjustment':
          explanations.push('COB (Coordination of Benefits) was applied');
          break;
        case 'plan_terminated':
          explanations.push('Coverage was not active on date of service');
          break;
        case 'claim_denied':
          explanations.push('Claim was denied by carrier');
          break;
        case 'fee_schedule_difference':
          explanations.push("Carrier's allowed fee was lower than billed");
          break;
        case 'other':
          explanations.push('Reason is unclear or unclassified');
          break;
      }
    }

    if (explanations.length === 0) {
      return 'Reason unknown.';
    }

    if (explanations.length === 1) {
      return `Reason: ${explanations[0]}.`;
    }

    return (
      `Reasons: ${explanations.slice(0, -1).join(', ')}, and ${explanations[explanations.length - 1]}.`
    );
  }

  /**
   * Recommend a patient account adjustment based on variance.
   *
   * @private
   */
  private _recommendAdjustment(
    varianceAmount: number,
    reasons: VarianceReason[],
    payment: ActualClaimPayment | null
  ): ReconciliationResult['adjustment'] {
    const MINOR_THRESHOLD = 200; // $2.00 in cents

    // Variance is negligible
    if (Math.abs(varianceAmount) < MINOR_THRESHOLD) {
      return {
        type: 'none',
        amount: 0,
        reason: 'Variance is negligible (less than $2.00); no adjustment needed.',
      };
    }

    // Insurance paid more than estimated
    if (varianceAmount > 0) {
      return {
        type: 'patient_balance_decrease',
        amount: varianceAmount,
        reason: `Insurance overpaid by $${(varianceAmount / 100).toFixed(2)}. Apply credit to patient account.`,
      };
    }

    // Claim was fully denied — recommend write-off if practice absorbs
    if (
      payment &&
      payment.amountPaid === 0 &&
      payment.amountDenied > 0 &&
      reasons.includes('claim_denied')
    ) {
      return {
        type: 'write_off',
        amount: Math.abs(varianceAmount),
        reason:
          'Claim denied. Consider writing off patient responsibility or pursuing appeal.',
      };
    }

    // Insurance paid less than estimated — patient owes the difference
    const shortfall = Math.abs(varianceAmount);
    const reasonSummary =
      reasons.length > 0
        ? reasons[0].replace(/_/g, ' ')
        : 'unclassified reason';

    return {
      type: 'patient_balance_increase',
      amount: shortfall,
      reason: `Insurance paid less than estimated due to ${reasonSummary}. Patient owes additional $${(shortfall / 100).toFixed(2)}.`,
    };
  }

  /**
   * Generate a summary of reconciliation results across all claims.
   *
   * Aggregates variance data and generates actionable recommendations
   * for practice leadership and finance team.
   *
   * @param results — All reconciliation results
   * @returns Summary with aggregate data and recommendations
   *
   * @example
   * const summary = engine.generateReconciliationSummary(results);
   * console.log(`Total variance: $${(summary.totalVariance / 100).toFixed(2)}`);
   * summary.recommendations.forEach(rec => console.log(rec));
   */
  generateReconciliationSummary(
    results: ReconciliationResult[]
  ): ReconciliationSummary {
    // Initialize aggregators
    let totalEstimated = 0;
    let totalActualPaid = 0;
    let totalVariance = 0;
    let totalPatientBalanceChange = 0;
    let totalWriteOffs = 0;

    const byVarianceReason: Record<
      VarianceReason,
      { count: number; totalAmount: number }
    > = {
      deductible_not_met: { count: 0, totalAmount: 0 },
      annual_max_exceeded: { count: 0, totalAmount: 0 },
      frequency_limit: { count: 0, totalAmount: 0 },
      waiting_period: { count: 0, totalAmount: 0 },
      procedure_excluded: { count: 0, totalAmount: 0 },
      coverage_percentage_different: { count: 0, totalAmount: 0 },
      cob_adjustment: { count: 0, totalAmount: 0 },
      plan_terminated: { count: 0, totalAmount: 0 },
      claim_denied: { count: 0, totalAmount: 0 },
      fee_schedule_difference: { count: 0, totalAmount: 0 },
      other: { count: 0, totalAmount: 0 },
    };

    const byCarrier: Record<
      string,
      { estimated: number; actual: number; variance: number }
    > = {};

    // Process each result
    for (const result of results) {
      totalEstimated += result.estimated.insurancePortion;
      totalActualPaid += result.actual.insurancePaid;
      totalVariance += result.variance.amount;

      // Track adjustments
      if (result.adjustment.type === 'patient_balance_increase') {
        totalPatientBalanceChange += result.adjustment.amount;
      } else if (result.adjustment.type === 'patient_balance_decrease') {
        totalPatientBalanceChange -= result.adjustment.amount;
      } else if (result.adjustment.type === 'write_off') {
        totalWriteOffs += result.adjustment.amount;
      }

      // Track by variance reason
      for (const reason of result.variance.reasons) {
        byVarianceReason[reason].count += 1;
        byVarianceReason[reason].totalAmount += Math.abs(result.variance.amount);
      }

      // Track by carrier
      if (!byCarrier[result.carrierCode]) {
        byCarrier[result.carrierCode] = {
          estimated: 0,
          actual: 0,
          variance: 0,
        };
      }
      byCarrier[result.carrierCode].estimated += result.estimated.insurancePortion;
      byCarrier[result.carrierCode].actual += result.actual.insurancePaid;
      byCarrier[result.carrierCode].variance += result.variance.amount;
    }

    // Generate recommendations
    const recommendations = this._generateRecommendations(
      results,
      byVarianceReason,
      byCarrier,
      totalVariance,
      totalEstimated
    );

    return {
      totalEstimated,
      totalActualPaid,
      totalVariance,
      variancePercentage:
        totalEstimated > 0 ? (totalVariance / totalEstimated) * 100 : 0,
      totalPatientBalanceChange,
      totalWriteOffs,
      byVarianceReason,
      byCarrier,
      recommendations,
      reconciliationDate: new Date().toISOString(),
    };
  }

  /**
   * Generate actionable recommendations based on variance patterns.
   *
   * @private
   */
  private _generateRecommendations(
    results: ReconciliationResult[],
    byVarianceReason: Record<
      VarianceReason,
      { count: number; totalAmount: number }
    >,
    byCarrier: Record<string, { estimated: number; actual: number; variance: number }>,
    totalVariance: number,
    totalEstimated: number
  ): string[] {
    const recommendations: string[] = [];

    // Check for major variance
    if (totalEstimated > 0) {
      const variancePercent = (totalVariance / totalEstimated) * 100;

      if (variancePercent < -10) {
        recommendations.push(
          `Insurance underpaid by ${Math.abs(variancePercent).toFixed(1)}% overall. ` +
            `Review carrier payment patterns and consider increasing appeal rate.`
        );
      } else if (variancePercent > 5) {
        recommendations.push(
          `Insurance overpaid by ${variancePercent.toFixed(1)}%. ` +
            `Verify estimates are conservative; update if estimates are too pessimistic.`
        );
      }
    }

    // Check for high-impact variance reasons
    if (byVarianceReason.deductible_not_met.count > 0) {
      recommendations.push(
        `Deductible mismatches in ${byVarianceReason.deductible_not_met.count} claims. ` +
          `Review deductible data accuracy in eligibility verification.`
      );
    }

    if (byVarianceReason.annual_max_exceeded.count > 0) {
      recommendations.push(
        `Annual maximum exceeded in ${byVarianceReason.annual_max_exceeded.count} claims. ` +
          `Track annual max usage more carefully in patient planning.`
      );
    }

    if (byVarianceReason.frequency_limit.count > 0) {
      recommendations.push(
        `Frequency limit violations in ${byVarianceReason.frequency_limit.count} claims. ` +
          `Ensure treatment planning adheres to carrier frequency rules.`
      );
    }

    // Check carrier-specific patterns
    for (const [carrier, stats] of Object.entries(byCarrier)) {
      if (stats.estimated > 0) {
        const carrierVariancePercent = (stats.variance / stats.estimated) * 100;

        if (carrierVariancePercent < -15) {
          recommendations.push(
            `${carrier} underpaying by ${Math.abs(carrierVariancePercent).toFixed(1)}%. ` +
            `Consider reviewing their fee schedule or increasing appeals rate.`
          );
        }
      }
    }

    // Check for high write-off rate
    const writeOffCount = results.filter(
      (r) => r.adjustment.type === 'write_off'
    ).length;
    if (writeOffCount > 0) {
      const writeOffRate = ((writeOffCount / results.length) * 100).toFixed(1);
      recommendations.push(
        `${writeOffCount} claims resulted in write-offs (${writeOffRate}% of total). ` +
          `Review denial patterns and appeal strategy.`
      );
    }

    if (recommendations.length === 0) {
      recommendations.push(
        'Reconciliation complete. Variance patterns are within expected range.'
      );
    }

    return recommendations;
  }

  /**
   * Detect systematic variance patterns across multiple claims.
   *
   * Identifies when a carrier consistently over/under pays, or when certain procedures
   * have systematic issues. Used for auditing and process improvement.
   *
   * @param results — Reconciliation results to analyze
   * @returns Array of detected patterns sorted by severity
   *
   * @example
   * const patterns = engine.detectVariancePatterns(results);
   * patterns.forEach(p => {
   *   console.log(`${p.pattern} (severity: ${p.severity})`);
   *   console.log(`Impact: $${(p.totalImpact / 100).toFixed(2)}`);
   * });
   */
  detectVariancePatterns(
    results: ReconciliationResult[]
  ): VariancePattern[] {
    const patterns: VariancePattern[] = [];

    // Pattern 1: Carrier underpaying consistently
    const byCarrier: Record<
      string,
      { results: ReconciliationResult[]; totalVariance: number }
    > = {};

    for (const result of results) {
      if (!byCarrier[result.carrierCode]) {
        byCarrier[result.carrierCode] = { results: [], totalVariance: 0 };
      }
      byCarrier[result.carrierCode].results.push(result);
      byCarrier[result.carrierCode].totalVariance += result.variance.amount;
    }

    for (const [carrier, data] of Object.entries(byCarrier)) {
      if (data.results.length < 3) continue; // Need at least 3 claims to detect pattern

      const avgVariance = data.totalVariance / data.results.length;
      const variancePercent =
        data.results[0].estimated.insurancePortion > 0
          ? (avgVariance / data.results[0].estimated.insurancePortion) * 100
          : 0;

      if (avgVariance < -500) {
        // Consistent underpayment > $5
        let severity: 'low' | 'medium' | 'high' = 'low';
        if (Math.abs(avgVariance) > 2000) severity = 'high';
        else if (Math.abs(avgVariance) > 1000) severity = 'medium';

        patterns.push({
          pattern: `${carrier} consistently underpaying by $${(Math.abs(avgVariance) / 100).toFixed(2)} per claim (${Math.abs(variancePercent).toFixed(1)}%)`,
          affectedClaims: data.results.length,
          totalImpact: Math.abs(data.totalVariance),
          severity,
          recommendation: `Review ${carrier} fee schedule and coverage rules. Consider renegotiating rates or updating plan configurations.`,
        });
      }
    }

    // Pattern 2: Specific CDT codes with high variance
    const byCdtCode: Record<string, ReconciliationResult[]> = {};
    for (const result of results) {
      const cdtCode = result.claimId; // Proxy; real implementation would track CDT
      if (!byCdtCode[cdtCode]) {
        byCdtCode[cdtCode] = [];
      }
      byCdtCode[cdtCode].push(result);
    }

    // Pattern 3: Frequency limit violations
    const freqLimitViolations = results.filter((r) =>
      r.variance.reasons.includes('frequency_limit')
    );
    if (freqLimitViolations.length > 3) {
      const totalImpact = freqLimitViolations.reduce(
        (sum, r) => sum + Math.abs(r.variance.amount),
        0
      );
      patterns.push({
        pattern: `Frequency limit violations in ${freqLimitViolations.length} claims`,
        affectedClaims: freqLimitViolations.length,
        totalImpact,
        severity: 'medium',
        recommendation:
          'Review treatment plan procedures. Ensure cleanings, exams, and X-rays comply with carrier frequency rules.',
      });
    }

    // Pattern 4: Annual maximum exceeded pattern
    const annualMaxViolations = results.filter((r) =>
      r.variance.reasons.includes('annual_max_exceeded')
    );
    if (annualMaxViolations.length > 2) {
      const totalImpact = annualMaxViolations.reduce(
        (sum, r) => sum + Math.abs(r.variance.amount),
        0
      );
      patterns.push({
        pattern: `Annual maximum exceeded in ${annualMaxViolations.length} claims`,
        affectedClaims: annualMaxViolations.length,
        totalImpact,
        severity: 'medium',
        recommendation:
          'Track annual max usage per patient. Consider splitting treatment across plan years when near limits.',
      });
    }

    // Sort by severity
    patterns.sort((a, b) => {
      const severityOrder: Record<string, number> = {
        high: 3,
        medium: 2,
        low: 1,
      };
      return (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
    });

    return patterns;
  }

  /**
   * Generate a patient-facing statement showing charges, payments, and balance due.
   *
   * Creates a clear line-item breakdown suitable for mailing to patient or
   * displaying in patient portal. Includes prior balance, new charges,
   * adjustments, and amount due.
   *
   * @param reconciliations — Reconciliation results for this patient
   * @param patient — Patient object with name and ID
   * @param previousBalance — Patient's prior account balance (in cents)
   * @param daysUntilDue — Days from today until payment is due (default: 30)
   * @returns Patient statement ready for display or printing
   *
   * @example
   * const statement = engine.generatePatientStatement(
   *   results,
   *   patient,
   *   5000,  // $50 prior balance
   *   30     // Due in 30 days
   * );
   *
   * console.log(statement.totalDue); // Amount patient owes in cents
   */
  generatePatientStatement(
    reconciliations: ReconciliationResult[],
    patient: Patient,
    previousBalance: number = 0,
    daysUntilDue: number = 30
  ): PatientStatement {
    let totalNewCharges = 0;
    let totalAdjustments = 0;

    const lineItems = reconciliations.map((recon) => {
      // Reconstruct procedure info from reconciliation
      // Note: In production, would reference full procedure details
      const providerFee = recon.estimated.insurancePortion + recon.estimated.patientPortion;
      const adjustment = recon.adjustment.amount;
      const patientOwes =
        recon.estimated.patientPortion + recon.adjustment.amount;

      totalNewCharges += providerFee;
      totalAdjustments += adjustment;

      return {
        dateOfService: recon.claimId.split('_')[3] || '2026-01-01', // Simplified
        procedure: `CDT Code (see detail)`,
        providerFee,
        insurancePaid: recon.actual.insurancePaid,
        priorEstimate: recon.estimated.insurancePortion,
        adjustment,
        patientOwes,
      };
    });

    const totalDue = previousBalance + totalNewCharges + totalAdjustments;
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + daysUntilDue);

    return {
      patientId: patient.id,
      patientName: `${patient.firstName} ${patient.lastName}`,
      statementDate: new Date().toISOString().split('T')[0],
      lineItems,
      previousBalance,
      newCharges: totalNewCharges,
      adjustments: totalAdjustments,
      totalDue,
      dueDate: dueDate.toISOString().split('T')[0],
    };
  }
}

// ============================================================================
// === EXPORTS ===
// ============================================================================

export {
  EstimateResult,
  ActualClaimPayment,
  ReconciliationResult,
  VarianceReason,
  Patient,
  CarrierCode,
};
