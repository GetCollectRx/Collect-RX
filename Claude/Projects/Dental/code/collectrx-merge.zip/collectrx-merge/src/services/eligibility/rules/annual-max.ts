/**
 * Annual Maximum Tracking Module for CollectRx Eligibility Engine
 *
 * Handles annual maximum benefit tracking and application across individual and family plans.
 * Annual maximums represent the maximum total amount insurance will pay in a calendar year
 * for covered services.
 *
 * Key features:
 * - Individual annual maximum enforcement
 * - Family aggregate annual maximum (when applicable)
 * - Preventive inclusion/exclusion logic per carrier
 * - Partial coverage when max is nearly exhausted
 * - Per-tier annual maximums (for carriers with separate caps)
 * - Mid-year tracking and remaining balance calculations
 */

import { CarrierConfig, CoverageTier, EligibilitySnapshot } from '../types';

/**
 * Result of applying annual maximum to an insurance payment
 *
 * @interface AnnualMaxResult
 */
export interface AnnualMaxResult {
  /** Adjusted insurance payment after annual max is applied */
  adjustedPayment: number;

  /** Portion of the insurance payment applied toward annual maximum */
  annualMaxApplied: number;

  /** Remaining annual maximum available after this payment */
  remainingMax: number;

  /** Whether the annual maximum was exceeded (before adjustment) */
  exceeded: boolean;

  /** Explanation of what happened during annual max application */
  explanation: string;
}

/**
 * AnnualMaxTracker — maintains running total of annual maximum usage
 *
 * Tracks how much of the annual maximum has been used and applies limits
 * to insurance payments. Handles both individual and family aggregate maximums.
 *
 * @class
 */
export class AnnualMaxTracker {
  private config: CarrierConfig;
  private snapshot: EligibilitySnapshot;
  private runningTotal: number = 0;
  private byMember: Record<string, number> = {};
  private byTier: Record<CoverageTier, number> = {};

  /**
   * Initialize annual max tracker
   *
   * @param config - Carrier configuration with annual max rules
   * @param snapshot - Current eligibility snapshot with YTD usage
   */
  constructor(config: CarrierConfig, snapshot: EligibilitySnapshot) {
    this.config = config;
    this.snapshot = snapshot;

    // Initialize running total from snapshot
    this.runningTotal = snapshot.annualMaxUsed.individual;

    // Initialize per-member usage if family plan
    if (snapshot.annualMaxUsed.byMember) {
      this.byMember = { ...snapshot.annualMaxUsed.byMember };
    }

    // Initialize per-tier usage if present
    if (snapshot.annualMaxUsed.byTier) {
      this.byTier = { ...snapshot.annualMaxUsed.byTier };
    }
  }

  /**
   * Apply annual maximum to an insurance payment for a single procedure
   *
   * Checks if the tier counts toward annual max based on carrier config,
   * reduces payment if remaining max would be exceeded, and updates running total.
   *
   * @param insurancePayment - Amount insurance plans to pay
   * @param tier - Coverage tier of the procedure
   * @returns Result of applying annual max constraints
   *
   * @example
   * const tracker = new AnnualMaxTracker(config, snapshot);
   * const result = tracker.applyAnnualMax(150, 'basic');
   * console.log(`Insurance adjusted from $${insurancePayment} to $${result.adjustedPayment}`);
   */
  public applyAnnualMax(
    insurancePayment: number,
    tier: CoverageTier
  ): AnnualMaxResult {
    // Check if this tier counts toward annual maximum
    const countsTowardMax =
      tier !== 'preventive' ||
      this.config.annualMax.includesPreventive;

    // If this tier doesn't count toward annual max, no adjustment needed
    if (!countsTowardMax) {
      return {
        adjustedPayment: insurancePayment,
        annualMaxApplied: 0,
        remainingMax: this.getRemainingMax(),
        exceeded: false,
        explanation: `Preventive services do not count toward annual maximum for ${this.config.name}`,
      };
    }

    const remaining = this.getRemainingMax();
    const maxCapacityExceeded = this.runningTotal + insurancePayment > this.config.annualMax.individual;

    // Determine adjusted payment
    const adjustedPayment = Math.max(0, Math.min(insurancePayment, remaining));
    const appliedToMax = adjustedPayment;

    // Update running total
    this.runningTotal += appliedToMax;

    // Update per-tier tracking if configured
    if (this.config.annualMax.byTier) {
      const currentTierUsage = this.byTier[tier] || 0;
      this.byTier[tier] = currentTierUsage + appliedToMax;
    }

    // Build explanation
    let explanation = '';
    if (!maxCapacityExceeded) {
      explanation = `Annual max applied: $${appliedToMax.toFixed(2)} applied (${remaining > adjustedPayment ? 'full payment' : 'partial'})`;
    } else {
      const reductionAmount = insurancePayment - adjustedPayment;
      explanation =
        `Annual maximum exceeded: Insurance reduced by $${reductionAmount.toFixed(2)} ` +
        `(from $${insurancePayment.toFixed(2)} to $${adjustedPayment.toFixed(2)}). ` +
        `Remaining annual max: $${Math.max(0, remaining - appliedToMax).toFixed(2)}`;
    }

    return {
      adjustedPayment,
      annualMaxApplied: appliedToMax,
      remainingMax: this.getRemainingMax(),
      exceeded: maxCapacityExceeded,
      explanation,
    };
  }

  /**
   * Apply annual maximum for a family plan member
   *
   * When a family maximum is set, tracks both individual member usage and
   * aggregate family usage. Will not allow additional insurance payments
   * if family aggregate is exhausted.
   *
   * @param memberId - Unique identifier for the family member
   * @param insurancePayment - Amount insurance plans to pay
   * @param tier - Coverage tier of the procedure
   * @returns Result of applying annual max constraints (individual + family)
   *
   * @example
   * const tracker = new AnnualMaxTracker(manulifeConfig, familySnapshot);
   * const result = tracker.applyFamilyMax('child-123', 200, 'basic');
   * if (result.exceeded) {
   *   console.log('Family max exceeded, patient pays full amount');
   * }
   */
  public applyFamilyMax(
    memberId: string,
    insurancePayment: number,
    tier: CoverageTier
  ): AnnualMaxResult {
    // Check if preventive counts toward max
    const countsTowardMax =
      tier !== 'preventive' ||
      this.config.annualMax.includesPreventive;

    // If this tier doesn't count, return payment unchanged
    if (!countsTowardMax) {
      return {
        adjustedPayment: insurancePayment,
        annualMaxApplied: 0,
        remainingMax: this.getRemainingMax(),
        exceeded: false,
        explanation: `Preventive services do not count toward annual maximum for ${this.config.name}`,
      };
    }

    // If no family max is configured, treat as individual
    if (!this.config.annualMax.familyMax) {
      return this.applyAnnualMax(insurancePayment, tier);
    }

    // Track individual member usage
    const memberUsage = this.byMember[memberId] || 0;
    const individualRemaining =
      this.config.annualMax.individual - memberUsage;

    // Check aggregate family remaining
    const familyRemaining = this.getRemainingFamilyMax();

    // Determine adjusted payment (limited by both individual and family caps)
    const adjustedPayment = Math.max(
      0,
      Math.min(
        insurancePayment,
        individualRemaining,
        familyRemaining
      )
    );

    const appliedToMax = adjustedPayment;

    // Update tracking
    this.byMember[memberId] = memberUsage + appliedToMax;
    this.runningTotal += appliedToMax;

    // Update per-tier tracking if configured
    if (this.config.annualMax.byTier) {
      const currentTierUsage = this.byTier[tier] || 0;
      this.byTier[tier] = currentTierUsage + appliedToMax;
    }

    // Determine why payment was reduced
    const exceeded =
      insurancePayment > adjustedPayment;
    let limitReason = '';

    if (familyRemaining <= 0) {
      limitReason = 'Family aggregate maximum exhausted';
    } else if (individualRemaining <= adjustedPayment) {
      limitReason = `Individual member limit approaching (${memberId})`;
    }

    const explanation =
      !exceeded
        ? `Annual max applied: $${appliedToMax.toFixed(2)} to member ${memberId}`
        : `Payment limited: $${adjustedPayment.toFixed(2)} (member: $${individualRemaining.toFixed(2)} remaining, family: $${familyRemaining.toFixed(2)} remaining). ${limitReason}`;

    return {
      adjustedPayment,
      annualMaxApplied: appliedToMax,
      remainingMax: this.getRemainingMax(),
      exceeded,
      explanation,
    };
  }

  /**
   * Get the remaining annual maximum available
   *
   * @returns Remaining benefit amount in dollars
   */
  public getRemainingMax(): number {
    return Math.max(0, this.config.annualMax.individual - this.runningTotal);
  }

  /**
   * Get the remaining family aggregate maximum
   *
   * Only relevant for plans with family max (e.g., Manulife).
   *
   * @returns Remaining family benefit amount, or individual remaining if no family max
   */
  public getRemainingFamilyMax(): number {
    if (!this.config.annualMax.familyMax) {
      return this.getRemainingMax();
    }

    return Math.max(0, this.config.annualMax.familyMax - this.runningTotal);
  }

  /**
   * Get total annual maximum used to date
   *
   * @returns Total amount applied toward annual maximum
   */
  public getTotalUsed(): number {
    return this.runningTotal;
  }

  /**
   * Check if annual maximum is completely exhausted
   *
   * @returns True if remaining max is zero or less
   */
  public isExhausted(): boolean {
    return this.getRemainingMax() <= 0;
  }

  /**
   * Check if family aggregate maximum is exhausted
   *
   * @returns True if remaining family max is zero or less
   */
  public isFamilyExhausted(): boolean {
    return this.getRemainingFamilyMax() <= 0;
  }

  /**
   * Get percentage of annual maximum used
   *
   * @returns Percentage from 0–100
   *
   * @example
   * const tracker = new AnnualMaxTracker(config, snapshot);
   * console.log(`${tracker.getUsagePercentage().toFixed(1)}% of annual max used`);
   */
  public getUsagePercentage(): number {
    if (this.config.annualMax.individual === 0) {
      return 0; // Unlimited coverage
    }
    return (this.runningTotal / this.config.annualMax.individual) * 100;
  }

  /**
   * Get per-member usage for family plans
   *
   * @returns Map of member IDs to their usage amounts
   */
  public getMemberUsage(): Record<string, number> {
    return { ...this.byMember };
  }

  /**
   * Get per-tier usage breakdown
   *
   * @returns Map of coverage tiers to amounts used
   */
  public getTierUsage(): Record<CoverageTier, number> {
    return { ...this.byTier };
  }
}

/**
 * Calculate annual max constraints for a batch of procedures
 *
 * Applies annual maximum limits to a list of insurance payments in sequence,
 * accounting for carrier-specific rules about preventive inclusion and family
 * aggregate caps.
 *
 * @param config - Carrier configuration
 * @param snapshot - Current eligibility snapshot
 * @param payments - List of insurance payments to process
 * @returns Array of results, one per payment
 *
 * @example
 * const payments = [
 *   { insurancePayment: 100, tier: 'preventive' },
 *   { insurancePayment: 80, tier: 'basic' },
 *   { insurancePayment: 200, tier: 'major' },
 * ];
 * const results = calculateAnnualMaxForBatch(config, snapshot, payments);
 * console.log(`Total insurance coverage: $${results.reduce((sum, r) => sum + r.adjustedPayment, 0)}`);
 */
export function calculateAnnualMaxForBatch(
  config: CarrierConfig,
  snapshot: EligibilitySnapshot,
  payments: Array<{ insurancePayment: number; tier: CoverageTier }>
): AnnualMaxResult[] {
  const tracker = new AnnualMaxTracker(config, snapshot);
  return payments.map((payment) =>
    tracker.applyAnnualMax(payment.insurancePayment, payment.tier)
  );
}

/**
 * Calculate annual max for a batch in a family plan context
 *
 * Applies family aggregate maximum constraints in addition to individual limits.
 * Used for Manulife and other carriers with family aggregate caps.
 *
 * @param config - Carrier configuration
 * @param snapshot - Current eligibility snapshot
 * @param payments - List of payments with member IDs
 * @returns Array of results, one per payment
 *
 * @example
 * const familyPayments = [
 *   { memberId: 'patient-1', insurancePayment: 150, tier: 'basic' },
 *   { memberId: 'patient-2', insurancePayment: 200, tier: 'major' },
 * ];
 * const results = calculateFamilyMaxForBatch(config, snapshot, familyPayments);
 */
export function calculateFamilyMaxForBatch(
  config: CarrierConfig,
  snapshot: EligibilitySnapshot,
  payments: Array<{
    memberId: string;
    insurancePayment: number;
    tier: CoverageTier;
  }>
): AnnualMaxResult[] {
  const tracker = new AnnualMaxTracker(config, snapshot);
  return payments.map((payment) =>
    tracker.applyFamilyMax(payment.memberId, payment.insurancePayment, payment.tier)
  );
}

/**
 * Check if a given insurance payment would exceed annual maximum
 *
 * Used for validation and warnings before processing procedures.
 *
 * @param config - Carrier configuration
 * @param snapshot - Current eligibility snapshot
 * @param insurancePayment - Proposed insurance payment
 * @param tier - Coverage tier of the procedure
 * @returns True if payment would exceed remaining annual max
 *
 * @example
 * if (wouldExceedAnnualMax(config, snapshot, 500, 'major')) {
 *   warnings.push('This procedure would exceed the annual maximum');
 * }
 */
export function wouldExceedAnnualMax(
  config: CarrierConfig,
  snapshot: EligibilitySnapshot,
  insurancePayment: number,
  tier: CoverageTier
): boolean {
  // Preventive may not count toward max for some carriers
  if (tier === 'preventive' && !config.annualMax.includesPreventive) {
    return false;
  }

  const currentUsed = snapshot.annualMaxUsed.individual;
  return currentUsed + insurancePayment > config.annualMax.individual;
}

/**
 * Calculate remaining annual maximum for a patient
 *
 * Considers individual and family maximums. Returns the minimum of the two
 * when both apply.
 *
 * @param config - Carrier configuration
 * @param snapshot - Current eligibility snapshot
 * @returns Remaining annual max in dollars
 *
 * @example
 * const remaining = getRemainingAnnualMax(config, snapshot);
 * console.log(`$${remaining} remaining of annual max`);
 */
export function getRemainingAnnualMax(
  config: CarrierConfig,
  snapshot: EligibilitySnapshot
): number {
  const individualRemaining =
    Math.max(0, config.annualMax.individual - snapshot.annualMaxUsed.individual);

  // If no family max, return individual remaining
  if (!config.annualMax.familyMax) {
    return individualRemaining;
  }

  // With family max, return the minimum (more restrictive)
  const familyRemaining = Math.max(0, config.annualMax.familyMax - snapshot.annualMaxUsed.individual);
  return Math.min(individualRemaining, familyRemaining);
}
