/**
 * CollectRx Eligibility Engine — Core Orchestrator
 *
 * The central engine that combines all rule modules (carrier configs, CDT codes,
 * deductible tracking, annual max tracking, and COB) to produce comprehensive
 * pre-treatment estimates for dental procedures.
 *
 * This is a STATELESS, DETERMINISTIC calculator:
 * - All state comes from the request and snapshot (no database calls)
 * - Same inputs always produce same outputs
 * - Transparent assumption tracking and confidence scoring
 * - Suitable for both sync calls and async queueing
 *
 * Algorithm Overview:
 * 1. Validate inputs and load carrier config
 * 2. Check plan eligibility and waiting periods
 * 3. Check frequency limits against claims history
 * 4. Map CDT codes to coverage tiers
 * 5. Initialize deductible and annual max trackers
 * 6. Process each procedure through coverage calculation
 * 7. Apply deductible, coverage percentage, and annual max
 * 8. Handle COB if secondary plan exists
 * 9. Calculate confidence score and generate assumptions/warnings
 * 10. Return comprehensive EstimateResult
 */

import { v4 as uuidv4 } from 'uuid';
import {
  CarrierConfig,
  CoverageTier,
  EligibilitySnapshot,
  EstimateRequest,
  EstimateResult,
  ProcedureEstimate,
  ProcedureInput,
  Patient,
  Plan,
  ConfidenceFactor,
  ConfidenceLevel,
  EligibilityStatusResponse,
  ClaimHistoryEntry,
} from './types';
import { CARRIER_CONFIGS } from './rules/carriers';
import { CDT_CODES, getCDTTier, isValidCDTCode } from './rules/cdt-codes';
import { DeductibleTracker } from './rules/deductible';
import { AnnualMaxTracker } from './rules/annual-max';
import { COBCalculator, determinePrimaryPlan } from './rules/cob';

/**
 * EligibilityEngine — Main orchestrator class for eligibility calculations
 *
 * Public API:
 * - calculateEstimate(request): EstimateResult — Generate full estimate for a patient
 * - getEligibilityStatus(patient, plan, snapshot): EligibilityStatusResponse — Quick status check
 * - validateProcedures(procedures): { valid, errors } — Input validation
 */
export class EligibilityEngine {
  private carrierConfigs: Record<string, CarrierConfig>;

  /**
   * Initialize the engine with optional custom carrier configs.
   * Defaults to the standard 6 Canadian carriers if not provided.
   *
   * @param carrierConfigs - Optional: Override default carrier configurations
   */
  constructor(carrierConfigs?: Record<string, CarrierConfig>) {
    this.carrierConfigs = carrierConfigs || CARRIER_CONFIGS;
  }

  /**
   * Main entry point: Calculate a comprehensive estimate for a treatment plan
   *
   * @param request - EstimateRequest with patient, plan, procedures, and optional snapshot
   * @returns EstimateResult with line-item estimates, totals, confidence, and warnings
   *
   * @throws Error if carrier code is unsupported or critical data is missing
   */
  public calculateEstimate(request: EstimateRequest): EstimateResult {
    const estimateId = this._generateId();
    const createdAt = new Date().toISOString();

    // ========================================================================
    // 1. VALIDATE INPUTS
    // ========================================================================

    const validationResult = this.validateProcedures(request.procedures);
    if (!validationResult.valid) {
      throw new Error(`Invalid procedures: ${validationResult.errors.join('; ')}`);
    }

    // ========================================================================
    // 2. LOAD CARRIER CONFIG
    // ========================================================================

    const carrierCode = request.plan.carrierCode;
    if (!this.carrierConfigs[carrierCode]) {
      throw new Error(
        `Unsupported carrier: ${carrierCode}. Supported: ${Object.keys(this.carrierConfigs).join(', ')}`
      );
    }
    const config = this.carrierConfigs[carrierCode];

    // ========================================================================
    // 3. CHECK PLAN ELIGIBILITY
    // ========================================================================

    const assumptions: string[] = [];
    const warnings: string[] = [];
    let hasSnapshot = !!request.eligibility;

    // If no snapshot provided, flag low confidence
    if (!request.eligibility) {
      assumptions.push('No eligibility snapshot provided; using plan defaults');
      warnings.push(
        'Estimate confidence is LOW: No verification with carrier. Recommend direct eligibility call before treatment.'
      );
    } else {
      // Verify plan is active
      if (!request.eligibility.isActive) {
        warnings.push(`Plan is NOT active as of snapshot (${request.eligibility.capturedAt})`);
      }

      // Check if snapshot is stale (>30 days old)
      const snapshotDate = new Date(request.eligibility.capturedAt);
      const daysSince = (Date.now() - snapshotDate.getTime()) / (1000 * 60 * 60 * 24);
      if (daysSince > 30) {
        assumptions.push(`Eligibility snapshot is ${Math.floor(daysSince)} days old`);
        warnings.push('Recommend refreshing eligibility with carrier before final treatment plan');
      }
    }

    // Create default snapshot if not provided
    const snapshot = request.eligibility || this._createDefaultSnapshot(request);

    // ========================================================================
    // 4. INITIALIZE TRACKERS
    // ========================================================================

    const deductibleTracker = new DeductibleTracker(config, snapshot);
    const annualMaxTracker = new AnnualMaxTracker(config, snapshot);

    assumptions.push(
      `Using carrier configuration: ${config.name} (updated ${config.lastUpdated || 'unknown'})`
    );

    // ========================================================================
    // 5. PROCESS EACH PROCEDURE
    // ========================================================================

    const procedures: ProcedureEstimate[] = [];
    let totalProviderFees = 0;
    let totalInsurancePortion = 0;
    let totalPatientPortion = 0;
    let totalDeductibleApplied = 0;

    for (const input of request.procedures) {
      const procEstimate = this._buildProcedureEstimate(
        input,
        config,
        snapshot,
        deductibleTracker,
        annualMaxTracker,
        assumptions,
        warnings
      );

      procedures.push(procEstimate);

      totalProviderFees += procEstimate.providerFee * procEstimate.quantity;
      totalInsurancePortion += procEstimate.insurancePortion;
      totalPatientPortion += procEstimate.patientPortion;
      totalDeductibleApplied += procEstimate.deductibleApplied;
    }

    // ========================================================================
    // 6. HANDLE SECONDARY PLAN (COB)
    // ========================================================================

    if (request.secondaryPlan && request.secondaryEligibility) {
      this._applyCOBToEstimate(
        procedures,
        request.plan,
        request.secondaryPlan,
        request.eligibility,
        request.secondaryEligibility,
        assumptions,
        warnings
      );

      // Recalculate totals after COB
      totalInsurancePortion = 0;
      totalPatientPortion = 0;
      for (const proc of procedures) {
        totalInsurancePortion += proc.insurancePortion;
        totalPatientPortion += proc.patientPortion;
      }
    }

    // ========================================================================
    // 7. CALCULATE CONFIDENCE SCORE
    // ========================================================================

    const confidenceFactors = this._calculateConfidenceFactors(
      hasSnapshot,
      request.eligibility,
      procedures,
      assumptions,
      !!request.secondaryPlan
    );

    const confidenceScore = Math.min(
      100,
      Math.max(0, confidenceFactors.reduce((sum, f) => sum + f.impact, 0))
    );

    let confidenceLevel: ConfidenceLevel = 'low';
    if (confidenceScore >= 80) {
      confidenceLevel = 'high';
    } else if (confidenceScore >= 50) {
      confidenceLevel = 'medium';
    }

    // ========================================================================
    // 8. BUILD AND RETURN ESTIMATE RESULT
    // ========================================================================

    const remainingDeductible = deductibleTracker.getRemainingDeductible();
    const remainingAnnualMax = annualMaxTracker.getRemainingMax();

    return {
      id: estimateId,
      patientId: request.patient.id,
      planId: request.plan.id,
      carrierCode: carrierCode,
      createdAt,
      procedures,
      summary: {
        totalProviderFees,
        totalInsurancePortion,
        totalPatientPortion,
        totalDeductibleApplied,
        annualMaxRemaining: remainingAnnualMax,
        deductibleRemaining: remainingDeductible,
      },
      confidence: {
        score: confidenceScore,
        level: confidenceLevel,
        factors: confidenceFactors,
      },
      assumptions,
      warnings,
      expiresAt: this._getEstimateExpiryDate(createdAt),
    };
  }

  /**
   * Quick eligibility status check — used by Vapi agent for real-time queries
   *
   * @param patient - Patient to check
   * @param plan - Plan to check
   * @param snapshot - Optional: Current eligibility snapshot
   * @returns EligibilityStatusResponse with current coverage details
   */
  public getEligibilityStatus(
    patient: Patient,
    plan: Plan,
    snapshot?: EligibilitySnapshot
  ): EligibilityStatusResponse {
    const config = this.carrierConfigs[plan.carrierCode];
    if (!config) {
      throw new Error(`Unsupported carrier: ${plan.carrierCode}`);
    }

    const effectiveSnapshot = snapshot || this._createDefaultSnapshot({ patient, plan, procedures: [] });

    const remainingDeductible = {
      individual: Math.max(0, config.deductible.individual - effectiveSnapshot.deductibleUsed.individual),
      family: Math.max(0, config.deductible.family - effectiveSnapshot.deductibleUsed.family),
    };

    const remainingAnnualMax = Math.max(
      0,
      config.annualMax.individual - effectiveSnapshot.annualMaxUsed.individual
    );

    return {
      isActive: effectiveSnapshot.isActive,
      effectiveDate: effectiveSnapshot.effectiveDate,
      terminationDate: effectiveSnapshot.terminationDate,
      deductibleRemaining: remainingDeductible,
      annualMaxRemaining: remainingAnnualMax,
      carrierName: config.name,
      planName: plan.planName,
      lastVerified: effectiveSnapshot.lastVerifiedDate,
      usedThisYear: {
        deductible: effectiveSnapshot.deductibleUsed.individual,
        annualMax: effectiveSnapshot.annualMaxUsed.individual,
      },
      notes: effectiveSnapshot.notes,
    };
  }

  /**
   * Validate procedures input
   *
   * @param procedures - Array of procedures to validate
   * @returns { valid: boolean, errors: string[] }
   */
  public validateProcedures(procedures: ProcedureInput[]): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (!Array.isArray(procedures) || procedures.length === 0) {
      errors.push('At least one procedure is required');
      return { valid: false, errors };
    }

    for (let i = 0; i < procedures.length; i++) {
      const proc = procedures[i];

      // Check CDT code
      if (!proc.cdtCode) {
        errors.push(`Procedure ${i}: CDT code is required`);
      } else if (!isValidCDTCode(proc.cdtCode)) {
        errors.push(`Procedure ${i}: Unknown CDT code "${proc.cdtCode}"`);
      }

      // Check fee
      if (proc.providerFee < 0) {
        errors.push(`Procedure ${i}: Provider fee must be >= 0`);
      }

      // Check quantity
      if (!proc.quantity || proc.quantity <= 0) {
        errors.push(`Procedure ${i}: Quantity must be > 0`);
      }

      // Check date
      if (!proc.dateOfService) {
        errors.push(`Procedure ${i}: Date of service is required`);
      } else {
        try {
          new Date(proc.dateOfService);
        } catch {
          errors.push(`Procedure ${i}: Invalid date format for dateOfService`);
        }
      }
    }

    return { valid: errors.length === 0, errors };
  }

  /**
   * Check frequency limits for a procedure
   *
   * @param procedure - Procedure to check
   * @param config - Carrier configuration
   * @param history - Claims history from snapshot
   * @returns { limited: boolean, note: string }
   */
  private checkFrequencyLimits(
    procedure: ProcedureInput,
    config: CarrierConfig,
    history: ClaimHistoryEntry[]
  ): { limited: boolean; note: string } {
    // Find frequency rule for this CDT code
    const cdtEntry = CDT_CODES.find((c) => c.code === procedure.cdtCode);
    if (!cdtEntry) {
      return { limited: false, note: 'CDT code not found in database' };
    }

    // Check if this carrier has frequency rules for this code
    for (const frequencyRule of config.frequencyRules) {
      if (!frequencyRule.codes.includes(procedure.cdtCode)) {
        continue;
      }

      // Count claims matching this code in the lookback period
      const periodStart = new Date();
      periodStart.setMonth(periodStart.getMonth() - frequencyRule.months);

      let count = 0;

      for (const claim of history) {
        if (claim.cdtCode !== procedure.cdtCode) {
          continue;
        }

        const claimDate = new Date(claim.dateOfService);
        if (claimDate >= periodStart) {
          // If per-tooth rule, check if same tooth
          if (frequencyRule.perTooth && procedure.toothNumber) {
            if (claim.toothNumber === procedure.toothNumber) {
              count++;
            }
          } else {
            count++;
          }
        }
      }

      // Check if limit exceeded
      if (count >= frequencyRule.maxPerPeriod) {
        return {
          limited: true,
          note: `Frequency limit reached: ${count}/${frequencyRule.maxPerPeriod} ${frequencyRule.description}`,
        };
      }
    }

    return { limited: false, note: '' };
  }

  /**
   * Check if waiting period applies to a procedure
   *
   * @param tier - Coverage tier
   * @param config - Carrier configuration
   * @param planEffectiveDate - Plan effective date (ISO string)
   * @param dateOfService - Procedure date (ISO string)
   * @returns { applies: boolean, note: string }
   */
  private checkWaitingPeriod(
    tier: CoverageTier,
    config: CarrierConfig,
    planEffectiveDate: string,
    dateOfService: string
  ): { applies: boolean; note: string } {
    // Find waiting period rule for this tier
    const waitingRule = config.waitingPeriods.find((w) => w.tier === tier);
    if (!waitingRule) {
      return { applies: false, note: '' };
    }

    // Calculate when waiting period ends
    const effectiveDate = new Date(planEffectiveDate);
    const waitingEndDate = new Date(effectiveDate);
    waitingEndDate.setMonth(waitingEndDate.getMonth() + waitingRule.months);

    const dosDate = new Date(dateOfService);
    if (dosDate < waitingEndDate) {
      return {
        applies: true,
        note: `${waitingRule.months}-month waiting period applies to ${tier} coverage. Expires ${waitingEndDate.toISOString().split('T')[0]}.`,
      };
    }

    return { applies: false, note: '' };
  }

  /**
   * Apply COB to all procedures in estimate
   *
   * @private
   */
  private _applyCOBToEstimate(
    procedures: ProcedureEstimate[],
    primaryPlan: Plan,
    secondaryPlan: Plan,
    primarySnapshot: EligibilitySnapshot | undefined,
    secondarySnapshot: EligibilitySnapshot | undefined,
    assumptions: string[],
    warnings: string[]
  ): void {
    // Get configs for both plans
    const primaryConfig = this.carrierConfigs[primaryPlan.carrierCode];
    const secondaryConfig = this.carrierConfigs[secondaryPlan.carrierCode];

    if (!primaryConfig || !secondaryConfig) {
      warnings.push('Secondary plan config missing; skipping COB');
      return;
    }

    // Determine which is truly primary using COB rules
    const planDetermination = determinePrimaryPlan(primaryPlan, secondaryPlan, {} as any);
    const actualPrimary = planDetermination.primary;
    const actualSecondary = planDetermination.secondary;

    const actualPrimaryConfig =
      actualPrimary.id === primaryPlan.id ? primaryConfig : secondaryConfig;
    const actualSecondaryConfig =
      actualSecondary.id === secondaryPlan.id ? secondaryConfig : primaryConfig;

    assumptions.push(`COB applied: ${actualPrimary.planName} is primary, ${actualSecondary.planName} is secondary`);
    assumptions.push(`COB method: ${actualSecondaryConfig.cobMethod}`);

    // Apply COB calculation to each procedure
    const cobCalculator = new COBCalculator();

    for (const proc of procedures) {
      const primaryCoveragePercent = actualPrimaryConfig.coveragePercentages[proc.tier] || 0;
      const secondaryCoveragePercent = actualSecondaryConfig.coveragePercentages[proc.tier] || 0;

      const cobResult = cobCalculator.calculateCOB({
        providerFee: proc.providerFee * proc.quantity,
        primaryCoveragePercent,
        secondaryCoveragePercent,
        primaryDeductibleApplied: proc.deductibleApplied,
        secondaryDeductibleApplied: 0, // Simplified for now
        cobMethod: actualSecondaryConfig.cobMethod as any,
      });

      // Adjust insurance and patient portions based on COB
      const originalInsurance = proc.insurancePortion;
      proc.insurancePortion = cobResult.totalCovered;
      proc.patientPortion = cobResult.patientResponsibility;
      proc.notes.push(`COB adjustment: Insurance portion adjusted by $${(cobResult.totalCovered - originalInsurance).toFixed(2)}`);
    }
  }

  /**
   * Build a ProcedureEstimate for a single procedure
   *
   * @private
   */
  private _buildProcedureEstimate(
    input: ProcedureInput,
    config: CarrierConfig,
    snapshot: EligibilitySnapshot,
    deductibleTracker: DeductibleTracker,
    annualMaxTracker: AnnualMaxTracker,
    assumptions: string[],
    warnings: string[]
  ): ProcedureEstimate {
    const notes: string[] = [];

    // Get CDT entry for description
    const cdtEntry = CDT_CODES.find((c) => c.code === input.cdtCode);
    const description = input.description || cdtEntry?.description || input.cdtCode;

    // Get coverage tier
    const tier = getCDTTier(input.cdtCode);

    // Check waiting period
    const waitingPeriodCheck = this.checkWaitingPeriod(
      tier,
      config,
      snapshot.effectiveDate,
      input.dateOfService
    );

    // Check frequency limit
    const frequencyCheck = this.checkFrequencyLimits(
      input,
      config,
      snapshot.claimsHistory
    );

    const excluded = frequencyCheck.limited || waitingPeriodCheck.applies;

    // Get coverage percentage
    const coveragePercentage = config.coveragePercentages[tier] || 0;

    // Calculate total provider fee
    const totalProviderFee = input.providerFee * input.quantity;

    // Apply deductible (if not excluded)
    let deductibleApplied = 0;
    if (!excluded) {
      const deductibleResult = deductibleTracker.applyDeductible(input, tier);
      deductibleApplied = deductibleResult.deductibleApplied;
      if (deductibleResult.waived) {
        notes.push(`Deductible waived: ${deductibleResult.reason}`);
      } else {
        notes.push(`Deductible applied: $${deductibleResult.deductibleApplied.toFixed(2)}`);
      }
    }

    // Calculate covered amount
    const coveredAmount = Math.max(0, (totalProviderFee - deductibleApplied) * (coveragePercentage / 100));

    // Apply annual maximum
    let annualMaxApplied = 0;
    let insurancePortion = coveredAmount;
    if (!excluded) {
      const annualMaxResult = annualMaxTracker.applyAnnualMax(coveredAmount, tier);
      insurancePortion = annualMaxResult.adjustedPayment;
      annualMaxApplied = annualMaxResult.annualMaxApplied;
      if (annualMaxResult.exceeded) {
        notes.push(`Annual maximum limit applied: $${annualMaxResult.adjustedPayment.toFixed(2)}`);
        warnings.push(
          `Procedure ${input.cdtCode} limited by annual maximum. Remaining: $${annualMaxResult.remainingMax.toFixed(2)}`
        );
      }
    }

    // If excluded, insurance pays nothing
    if (excluded) {
      insurancePortion = 0;
    }

    // Calculate patient responsibility
    const patientPortion = totalProviderFee - insurancePortion;

    // Add notes for exclusions
    if (frequencyCheck.limited) {
      notes.push(`Frequency limited: ${frequencyCheck.note}`);
      warnings.push(`Frequency limit exceeded for ${input.cdtCode}: ${frequencyCheck.note}`);
    }
    if (waitingPeriodCheck.applies) {
      notes.push(`Waiting period: ${waitingPeriodCheck.note}`);
      warnings.push(`Waiting period applies: ${waitingPeriodCheck.note}`);
    }

    return {
      cdtCode: input.cdtCode,
      description,
      tier,
      providerFee: input.providerFee,
      quantity: input.quantity,
      coveragePercentage,
      insurancePortion,
      patientPortion,
      deductibleApplied,
      annualMaxApplied,
      frequencyLimited: frequencyCheck.limited,
      frequencyNote: frequencyCheck.limited ? frequencyCheck.note : undefined,
      waitingPeriodApplies: waitingPeriodCheck.applies,
      waitingPeriodNote: waitingPeriodCheck.applies ? waitingPeriodCheck.note : undefined,
      excluded,
      exclusionReason: excluded
        ? `${frequencyCheck.limited ? 'Frequency limit' : ''} ${waitingPeriodCheck.applies ? 'Waiting period' : ''}`.trim()
        : undefined,
      notes,
      toothNumber: input.toothNumber,
    };
  }

  /**
   * Calculate confidence factors
   *
   * @private
   */
  private _calculateConfidenceFactors(
    hasSnapshot: boolean,
    snapshot: EligibilitySnapshot | undefined,
    procedures: ProcedureEstimate[],
    assumptions: string[],
    hasSecondaryPlan: boolean
  ): ConfidenceFactor[] {
    const factors: ConfidenceFactor[] = [];

    // Eligibility verification
    if (hasSnapshot) {
      const snapshotDate = new Date(snapshot!.capturedAt);
      const daysSince = (Date.now() - snapshotDate.getTime()) / (1000 * 60 * 60 * 24);

      if (daysSince <= 7) {
        factors.push({
          factor: 'eligibility_verified_recent',
          impact: 30,
          description: 'Eligibility verified with carrier within 7 days',
        });
      } else if (daysSince <= 30) {
        factors.push({
          factor: 'eligibility_verified_30days',
          impact: 20,
          description: 'Eligibility verified within last 30 days',
        });
      } else {
        factors.push({
          factor: 'eligibility_stale',
          impact: -15,
          description: `Eligibility snapshot is ${Math.floor(daysSince)} days old`,
        });
      }
    } else {
      factors.push({
        factor: 'no_eligibility_snapshot',
        impact: -30,
        description: 'No eligibility snapshot provided; using plan defaults',
      });
    }

    // CDT code validation
    const allValid = procedures.every((p) => p.notes.length === 0 || !p.notes.some((n) => n.includes('Unknown')));
    if (allValid) {
      factors.push({
        factor: 'all_cdt_codes_recognized',
        impact: 10,
        description: 'All CDT codes recognized in database',
      });
    }

    // Frequency assumptions
    const hasFrequencyAssumptions = procedures.some((p) => p.frequencyLimited);
    if (!hasFrequencyAssumptions) {
      factors.push({
        factor: 'no_frequency_assumptions',
        impact: 10,
        description: 'No frequency limit assumptions needed',
      });
    } else {
      factors.push({
        factor: 'frequency_limited',
        impact: -15,
        description: 'Some procedures are frequency-limited',
      });
    }

    // Waiting period assumptions
    const hasWaitingAssumptions = procedures.some((p) => p.waitingPeriodApplies);
    if (!hasWaitingAssumptions) {
      factors.push({
        factor: 'no_waiting_period_assumptions',
        impact: 10,
        description: 'No waiting period assumptions needed',
      });
    } else {
      factors.push({
        factor: 'waiting_period_applies',
        impact: -20,
        description: 'Waiting period applies to some procedures',
      });
    }

    // COB complexity
    if (hasSecondaryPlan) {
      factors.push({
        factor: 'cob_coordination',
        impact: -10,
        description: 'Coordination of benefits adds complexity and uncertainty',
      });
    } else {
      factors.push({
        factor: 'single_plan',
        impact: 10,
        description: 'Single insurance plan (no COB coordination)',
      });
    }

    return factors;
  }

  /**
   * Create a default (empty) eligibility snapshot for a plan
   *
   * @private
   */
  private _createDefaultSnapshot(request: Partial<EstimateRequest>): EligibilitySnapshot {
    const plan = request.plan!;
    const currentDate = new Date();
    const planYearStart = new Date(currentDate.getFullYear(), 0, 1);

    return {
      id: this._generateId(),
      patientId: request.patient!.id,
      planId: plan.id,
      capturedAt: new Date().toISOString(),
      source: 'manual_entry',
      isActive: true,
      effectiveDate: plan.effectiveDate,
      deductibleUsed: {
        individual: 0,
        family: 0,
      },
      annualMaxUsed: {
        individual: 0,
      },
      claimsHistory: [],
      notes: 'Default snapshot created; no carrier verification',
    };
  }

  /**
   * Generate a UUID for estimates
   *
   * @private
   */
  private _generateId(): string {
    return uuidv4();
  }

  /**
   * Calculate estimate expiry date (30 days from creation)
   *
   * @private
   */
  private _getEstimateExpiryDate(createdAt: string): string {
    const date = new Date(createdAt);
    date.setDate(date.getDate() + 30);
    return date.toISOString().split('T')[0];
  }
}

/**
 * Convenience function to get a preconfigured engine instance
 *
 * @param carrierConfigs - Optional: Custom carrier configurations
 * @returns EligibilityEngine instance ready to use
 */
export function createEngine(carrierConfigs?: Record<string, CarrierConfig>): EligibilityEngine {
  return new EligibilityEngine(carrierConfigs);
}

/**
 * Convenience function for single-shot estimate calculation
 *
 * @param request - EstimateRequest
 * @returns EstimateResult
 */
export function estimateProcedures(request: EstimateRequest): EstimateResult {
  const engine = createEngine();
  return engine.calculateEstimate(request);
}

// Export main types and functions
export {
  EstimateRequest,
  EstimateResult,
  ProcedureEstimate,
  ProcedureInput,
  EligibilitySnapshot,
  ConfidenceLevel,
};
