import Stripe from 'stripe';
import {
  StripeConnectedAccount,
  PaymentLink,
  PaymentLineItem,
  PaymentTransaction,
  RefundRequest,
  CreatePaymentLinkRequest,
  CreatePaymentLinkResponse,
  TransactionStatus,
} from './types';

/**
 * StripeConnectService
 *
 * Handles all Stripe Connect operations for CollectRx platform.
 * Each dental practice is a connected account with direct fund transfer.
 * Platform operates in Canadian market (CAD currency, Interac support).
 *
 * Architecture:
 * - CollectRx is the platform (owns the Stripe account)
 * - Each practice is a Stripe Connect Express account
 * - Payments are processed on behalf of the practice
 * - Funds are automatically transferred to practice accounts
 */
export class StripeConnectService {
  private stripe: Stripe;
  private webhookSecret: string;

  /**
   * Initialize StripeConnectService
   * @param stripeSecretKey - Stripe API secret key (test or live)
   * @param webhookSecret - Webhook endpoint secret for signature verification
   */
  constructor(stripeSecretKey: string, webhookSecret: string) {
    this.stripe = new Stripe(stripeSecretKey, {
      apiVersion: '2023-10-16',
    });
    this.webhookSecret = webhookSecret;
  }

  // ==================== Connected Account Management ====================

  /**
   * Create a new Stripe Connect Express account for a dental practice
   *
   * @param practiceId - Internal CollectRx practice identifier
   * @param email - Practice email address
   * @param businessName - Legal business name
   * @returns StripeConnectedAccount with account ID and onboarding details
   * @throws Error if account creation fails
   *
   * @example
   * const account = await stripeService.createConnectedAccount(
   *   'practice_123',
   *   'hello@dentalpractice.ca',
   *   'Downtown Dental Clinic'
   * );
   */
  async createConnectedAccount(
    practiceId: string,
    email: string,
    businessName: string
  ): Promise<StripeConnectedAccount> {
    try {
      const account = await this.stripe.accounts.create({
        type: 'express',
        country: 'CA',
        email,
        business_profile: {
          name: businessName,
          support_email: email,
        },
        default_currency: 'cad',
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        metadata: {
          practiceId,
          platform: 'collectrx',
        },
      });

      return this.mapStripeAccountToConnectedAccount(account);
    } catch (error) {
      throw new Error(`Failed to create connected account: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Generate an onboarding link for a connected account
   *
   * Directs practice to Stripe's onboarding flow to complete KYC verification
   * and enable payouts. Link expires after 24 hours.
   *
   * @param stripeAccountId - Stripe Connect account ID (acct_*)
   * @param returnUrl - URL to redirect after onboarding completes
   * @param refreshUrl - URL to redirect if user clicks back
   * @returns Onboarding URL (valid for 24 hours)
   * @throws Error if link generation fails
   *
   * @example
   * const onboardingUrl = await stripeService.generateOnboardingLink(
   *   'acct_1234567890',
   *   'https://app.collectrx.ca/practices/123/dashboard',
   *   'https://app.collectrx.ca/practices/123/setup'
   * );
   */
  async generateOnboardingLink(
    stripeAccountId: string,
    returnUrl: string,
    refreshUrl: string
  ): Promise<string> {
    try {
      const link = await this.stripe.accountLinks.create({
        account: stripeAccountId,
        type: 'account_onboarding',
        return_url: returnUrl,
        refresh_url: refreshUrl,
      });

      return link.url;
    } catch (error) {
      throw new Error(`Failed to generate onboarding link: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Retrieve current status of a connected account
   *
   * Check if account has completed onboarding and enabled charges/payouts.
   * Use to gate payment functionality and alert practices to finish setup.
   *
   * @param stripeAccountId - Stripe Connect account ID
   * @returns Account status: chargesEnabled, payoutsEnabled, onboardingComplete
   * @throws Error if account cannot be retrieved
   *
   * @example
   * const status = await stripeService.getAccountStatus('acct_1234567890');
   * if (!status.onboardingComplete) {
   *   // Prompt practice to complete onboarding
   * }
   */
  async getAccountStatus(
    stripeAccountId: string
  ): Promise<Partial<StripeConnectedAccount>> {
    try {
      const account = await this.stripe.accounts.retrieve(stripeAccountId);

      return {
        stripeAccountId: account.id,
        chargesEnabled: account.charges_enabled,
        payoutsEnabled: account.payouts_enabled,
        onboardingComplete:
          account.charges_enabled &&
          account.payouts_enabled &&
          account.requirements?.currently_due?.length === 0,
      };
    } catch (error) {
      throw new Error(`Failed to retrieve account status: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // ==================== Payment Links ====================

  /**
   * Create a Stripe Checkout Session for patient payment
   *
   * Creates a secure payment link that accepts credit cards.
   * Future support for Interac transfers via payment method expansion.
   * Session is processed on behalf of the connected practice account.
   *
   * @param connectedAccountId - Stripe Connect account ID
   * @param request - Payment link configuration (items, URLs, patient info)
   * @param practiceInfo - Practice name and email for invoice
   * @returns Payment link details with URL and session info
   * @throws Error if session creation fails
   *
   * @example
   * const paymentLink = await stripeService.createPaymentLink(
   *   'acct_1234567890',
   *   {
   *     lineItems: [
   *       { description: 'Crown - Tooth #11', amount: 150000, quantity: 1 }
   *     ],
   *     successUrl: 'https://collectrx.ca/success',
   *     cancelUrl: 'https://collectrx.ca/cancel',
   *     expiresInDays: 14,
   *     patientEmail: 'patient@example.com',
   *     patientId: 'pat_123',
   *     paymentLinkId: 'link_123',
   *   },
   *   { name: 'Downtown Dental', email: 'billing@downtowndental.ca' }
   * );
   */
  async createPaymentLink(
    connectedAccountId: string,
    request: CreatePaymentLinkRequest,
    practiceInfo: { name: string; email: string }
  ): Promise<CreatePaymentLinkResponse> {
    try {
      const lineItems = request.lineItems.map((item) => ({
        price_data: {
          currency: 'cad' as const,
          product_data: {
            name: item.description,
            metadata: {
              itemType: 'treatment',
            },
          },
          unit_amount: this.formatAmountForStripe(item.amount),
        },
        quantity: item.quantity,
      }));

      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + (request.expiresInDays || 30));

      const session = await this.stripe.checkout.sessions.create(
        {
          mode: 'payment',
          line_items: lineItems as Stripe.Checkout.SessionCreateParams.LineItem[],
          currency: 'cad',
          payment_method_types: ['card'],
          success_url: request.successUrl,
          cancel_url: request.cancelUrl,
          customer_email: request.patientEmail,
          metadata: {
            patientId: request.patientId,
            practiceId: request.practiceId,
            paymentLinkId: request.paymentLinkId,
          },
          expires_at: Math.floor(expiresAt.getTime() / 1000),
        },
        {
          stripeAccount: connectedAccountId,
        }
      );

      return {
        paymentLink: {
          id: session.id,
          url: session.url || '',
          status: 'pending',
          amount: request.lineItems.reduce((sum, item) => sum + item.amount * item.quantity, 0),
          currency: 'cad',
          expiresAt: expiresAt.toISOString(),
          patientId: request.patientId,
          practiceId: request.practiceId,
        },
        url: session.url || '',
        communication: request.sendReminder
          ? `Payment reminder email will be sent to ${request.patientEmail}`
          : undefined,
      };
    } catch (error) {
      throw new Error(`Failed to create payment link: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Retrieve a checkout session by ID
   *
   * Get session details including payment status, customer info, and line items.
   *
   * @param sessionId - Stripe checkout session ID
   * @param connectedAccountId - Stripe Connect account ID
   * @returns Session details
   * @throws Error if session cannot be retrieved
   */
  async getPaymentSession(
    sessionId: string,
    connectedAccountId: string
  ): Promise<Stripe.Checkout.Session> {
    try {
      const session = await this.stripe.checkout.sessions.retrieve(sessionId, {}, {
        stripeAccount: connectedAccountId,
      });

      return session;
    } catch (error) {
      throw new Error(`Failed to retrieve payment session: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // ==================== Payment Processing ====================

  /**
   * Retrieve payment intent details
   *
   * Get full payment intent and associated charge details including receipt URL.
   * Use to retrieve transaction history and provide receipts to practices.
   *
   * @param paymentIntentId - Stripe payment intent ID
   * @param connectedAccountId - Stripe Connect account ID
   * @returns Payment transaction with charge details
   * @throws Error if intent cannot be retrieved
   */
  async getPaymentIntent(
    paymentIntentId: string,
    connectedAccountId: string
  ): Promise<PaymentTransaction> {
    try {
      const intent = await this.stripe.paymentIntents.retrieve(
        paymentIntentId,
        {},
        {
          stripeAccount: connectedAccountId,
        }
      );

      const chargeId = typeof intent.charges.data[0] === 'string'
        ? intent.charges.data[0]
        : intent.charges.data[0]?.id;

      let receiptUrl = '';
      if (chargeId) {
        const charge = await this.stripe.charges.retrieve(chargeId, {
          stripeAccount: connectedAccountId,
        });
        receiptUrl = charge.receipt_url || '';
      }

      return {
        id: intent.id,
        amount: this.formatAmountFromStripe(intent.amount),
        currency: intent.currency.toUpperCase(),
        status: intent.status as TransactionStatus,
        createdAt: new Date(intent.created * 1000),
        receiptUrl,
        metadata: intent.metadata,
      };
    } catch (error) {
      throw new Error(`Failed to retrieve payment intent: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Process a refund for a payment
   *
   * Create a full or partial refund for a charge.
   * Refunds typically process within 5-10 business days.
   *
   * @param connectedAccountId - Stripe Connect account ID
   * @param request - Refund details (chargeId, optional amount, reason)
   * @returns Refund confirmation with ID and amount
   * @throws Error if refund creation fails
   *
   * @example
   * const refund = await stripeService.processRefund(
   *   'acct_1234567890',
   *   {
   *     chargeId: 'ch_1234567890',
   *     amount: 5000, // Optional: partial refund of $50
   *     reason: 'requested_by_customer'
   *   }
   * );
   */
  async processRefund(
    connectedAccountId: string,
    request: RefundRequest
  ): Promise<{ success: boolean; refundId: string; amount: number }> {
    try {
      const refundParams: Stripe.RefundCreateParams = {
        charge: request.chargeId,
        reason: request.reason,
        metadata: {
          practiceId: request.practiceId,
          patientId: request.patientId,
        },
      };

      // Support partial refunds
      if (request.amount) {
        refundParams.amount = this.formatAmountForStripe(request.amount);
      }

      const refund = await this.stripe.refunds.create(refundParams, {
        stripeAccount: connectedAccountId,
      });

      return {
        success: refund.status === 'succeeded',
        refundId: refund.id,
        amount: this.formatAmountFromStripe(refund.amount),
      };
    } catch (error) {
      throw new Error(`Failed to process refund: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // ==================== Webhook Handling ====================

  /**
   * Verify webhook signature and extract event
   *
   * Validates webhook payload using HMAC-SHA256 signature.
   * Must be called for every webhook to prevent replay attacks.
   *
   * @param payload - Raw request body as string or buffer
   * @param signature - X-Stripe-Signature header value
   * @returns Verified event object
   * @throws Error if signature is invalid
   *
   * @example
   * const event = stripeService.verifyWebhookSignature(body, signature);
   * await stripeService.handleWebhookEvent(event);
   */
  verifyWebhookSignature(payload: string | Buffer, signature: string): any {
    try {
      const event = this.stripe.webhooks.constructEvent(payload, signature, this.webhookSecret);
      return event;
    } catch (error) {
      throw new Error(`Invalid webhook signature: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Handle Stripe webhook events
   *
   * Process payment lifecycle events and account updates.
   * Updates transaction status, handles refunds, flags disputes.
   * Returns action taken for logging and auditing.
   *
   * Supported events:
   * - checkout.session.completed: Payment succeeded
   * - payment_intent.succeeded: Payment confirmed
   * - payment_intent.payment_failed: Payment declined
   * - charge.refunded: Refund processed
   * - charge.dispute.created: Payment disputed
   * - account.updated: Account status changed
   *
   * @param event - Verified Stripe event
   * @returns Action taken and relevant data
   *
   * @example
   * const result = await stripeService.handleWebhookEvent(event);
   * console.log(`Action: ${result.action}`, result.data);
   */
  async handleWebhookEvent(
    event: any
  ): Promise<{ action: string; data: any }> {
    try {
      const eventType = event.type;
      const eventData = event.data.object;

      switch (eventType) {
        case 'checkout.session.completed': {
          // Payment link was completed and payment succeeded
          return {
            action: 'payment_completed',
            data: {
              sessionId: eventData.id,
              amount: this.formatAmountFromStripe(eventData.amount_total),
              currency: eventData.currency,
              customerEmail: eventData.customer_email,
              metadata: eventData.metadata,
            },
          };
        }

        case 'payment_intent.succeeded': {
          // Payment intent confirmed
          return {
            action: 'payment_succeeded',
            data: {
              paymentIntentId: eventData.id,
              amount: this.formatAmountFromStripe(eventData.amount),
              chargeId: eventData.charges.data[0]?.id,
              metadata: eventData.metadata,
            },
          };
        }

        case 'payment_intent.payment_failed': {
          // Payment declined or failed
          return {
            action: 'payment_failed',
            data: {
              paymentIntentId: eventData.id,
              reason: eventData.last_payment_error?.message,
              metadata: eventData.metadata,
            },
          };
        }

        case 'charge.refunded': {
          // Refund was processed
          return {
            action: 'refund_processed',
            data: {
              chargeId: eventData.id,
              refundId: eventData.refunds?.data[0]?.id,
              amount: this.formatAmountFromStripe(eventData.refunded),
              status: eventData.refunds?.data[0]?.status,
            },
          };
        }

        case 'charge.dispute.created': {
          // Chargeback or dispute initiated
          return {
            action: 'dispute_created',
            data: {
              chargeId: eventData.id,
              amount: this.formatAmountFromStripe(eventData.amount),
              reason: eventData.dispute,
              status: 'needs_investigation',
            },
          };
        }

        case 'account.updated': {
          // Connected account status changed
          return {
            action: 'account_updated',
            data: {
              accountId: eventData.id,
              chargesEnabled: eventData.charges_enabled,
              payoutsEnabled: eventData.payouts_enabled,
              requirementsDue: eventData.requirements?.currently_due,
            },
          };
        }

        default: {
          return {
            action: 'event_received',
            data: {
              eventType,
              timestamp: event.created,
            },
          };
        }
      }
    } catch (error) {
      throw new Error(`Failed to handle webhook event: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // ==================== Fee Calculation ====================

  /**
   * Calculate CollectRx application fee for a transaction
   *
   * Fee structure:
   * - Stripe processing fee: 2.9% + $0.30 (charged by Stripe)
   * - CollectRx platform fee: 1.0% (CollectRx revenue)
   *
   * Note: Stripe processes the percentage-based fee.
   * CollectRx retains the 1% platform fee.
   * Both are deducted before funds reach practice.
   *
   * @param amount - Transaction amount in dollars
   * @returns Application fee in cents (for Stripe API)
   *
   * @example
   * const fee = stripeService.calculateApplicationFee(1000); // $1000
   * // Returns fee in cents: (1000 * 0.01 * 100) = 1000 cents = $10
   */
  calculateApplicationFee(amount: number): number {
    // Convert to cents
    const amountInCents = this.formatAmountForStripe(amount);

    // CollectRx platform fee: 1% of transaction
    const platformFeePercentage = 0.01;
    const platformFeeAmount = Math.round(amountInCents * platformFeePercentage);

    return platformFeeAmount;
  }

  // ==================== Helper Methods ====================

  /**
   * Convert dollar amount to cents (integer)
   *
   * Stripe API expects amounts in cents as integers.
   * Handles rounding to nearest cent.
   *
   * @param dollarAmount - Amount in dollars (e.g., 150.50)
   * @returns Amount in cents as integer (e.g., 15050)
   */
  formatAmountForStripe(dollarAmount: number): number {
    return Math.round(dollarAmount * 100);
  }

  /**
   * Convert cents to dollars (with precision)
   *
   * Stripe API returns amounts in cents.
   * Convert back to dollars for display and storage.
   *
   * @param centAmount - Amount in cents (e.g., 15050)
   * @returns Amount in dollars as number (e.g., 150.50)
   */
  formatAmountFromStripe(centAmount: number): number {
    return Math.round((centAmount / 100) * 100) / 100;
  }

  /**
   * Map Stripe account object to CollectRx StripeConnectedAccount
   *
   * @param account - Stripe account object
   * @returns Mapped connected account
   */
  private mapStripeAccountToConnectedAccount(
    account: Stripe.Account
  ): StripeConnectedAccount {
    return {
      stripeAccountId: account.id,
      email: account.email || '',
      businessName: account.business_profile?.name || '',
      country: account.country || 'CA',
      currency: account.default_currency || 'cad',
      chargesEnabled: account.charges_enabled,
      payoutsEnabled: account.payouts_enabled,
      onboardingComplete:
        account.charges_enabled &&
        account.payouts_enabled &&
        account.requirements?.currently_due?.length === 0,
      createdAt: new Date(account.created * 1000),
    };
  }
}
