/**
 * Deductible Tracking Module for CollectRx Eligibility Engine
 *
 * Handles deductible application and tracking across dental procedures.
 * Implements rules for:
 * - Individual vs. family deductible tracking
 * - Preventive waiver logic
 * - Deductible application per procedure (applied to provider fee)
 * - Running totals across procedure batches
 * - Edge cases: zero-deductible plans, family caps, etc.
 *
 * Key principle: Deductible is applied to the PROVIDER FEE, not the covered amount.
 * Deductible is satisfied once per calendar year and applies in order to procedures.
 */

import { CarrierConfig, CoverageTier, EligibilitySnapshot, ProcedureInput } from '../types';

/**
 * Result of applying deductible to a single procedure
 * @interface
 */
export interface DeductibleResult {
  /** Amount of deductible applied to this procedure */
  deductibleApplied: number;

  /** Remaining individual deductible after this procedure */
  remainingIndividual: number;

  /** Remaining family deductible after this procedure */
  remainingFamily: number;

  /** Was the deductible waived for this procedure? */
  waived: boolean;

  /** Human-readable reason for waiver or application */
  reason: string;
}

/**
 * DeductibleTracker — maintains running deductible usage across a batch of procedures
 *
 * Tracks individual and family deductible consumption. Respects:
 * - Tier-based applicability (e.g., deductible only on basic, major, etc.)
 * - Preventive waiver (deductible waived for preventive if configured)
 * - Family deductible cap (once family max reached, no more deductible applies)
 * - Zero-deductible plans (gracefully handled)
 *
 * @class
 */
export class DeductibleTracker {
  private carrierConfig: CarrierConfig;
  private eligibilitySnapshot: EligibilitySnapshot;
  private usedIndividual: number;
  private usedFamily: number;

  /**
   * Initialize the deductible tracker
   *
   * @param config - Carrier configuration with deductible rules
   * @param snapshot - Current eligibility snapshot with existing deductible usage
   */
  constructor(config: CarrierConfig, snapshot: EligibilitySnapshot) {
    this.carrierConfig = config;
    this.eligibilitySnapshot = snapshot;
    // Start with existing usage from the snapshot
    this.usedIndividual = snapshot.deductibleUsed.individual;
    this.usedFamily = snapshot.deductibleUsed.family;
  }

  /**
   * Get remaining deductible amounts
   *
   * Returns the unused portions of individual and family deductibles.
   *
   * @returns Object with individual and family remaining amounts
   */
  public getRemainingDeductible(): { individual: number; family: number } {
    const remaining = {
      individual: Math.max(0, this.carrierConfig.deductible.individual - this.usedIndividual),
      family: Math.max(0, this.carrierConfig.deductible.family - this.usedFamily),
    };
    return remaining;
  }

  /**
   * Get total deductible applied so far in this batch
   *
   * This tracks cumulative deductible applied during the current batch processing,
   * not including pre-existing usage from the snapshot.
   *
   * @returns Total deductible applied in this batch
   */
  public getTotalApplied(): number {
    const initialIndividual = this.eligibilitySnapshot.deductibleUsed.individual;
    const initialFamily = this.eligibilitySnapshot.deductibleUsed.family;
    const batchIndividual = this.usedIndividual - initialIndividual;
    const batchFamily = this.usedFamily - initialFamily;
    return batchIndividual + batchFamily;
  }

  /**
   * Apply deductible to a single procedure
   *
   * Determines if deductible applies, calculates the amount, and updates running totals.
   * Respects the order of procedures in a batch (deductible applies in sequence).
   *
   * Logic:
   * 1. Check if deductible is $0 → skip entirely
   * 2. Check if tier requires deductible (from carrier config appliesToTiers)
   * 3. Check if preventive is waived (waiveForPreventive flag)
   * 4. Check if individual deductible already met → no more applied
   * 5. Check if family deductible already met → no more applied
   * 6. Apply min(remaining individual deductible, remaining family deductible, provider fee)
   *
   * @param procedure - The procedure to apply deductible to
   * @param tier - The coverage tier (determines if deductible applies)
   * @returns DeductibleResult with applied amount and remaining totals
   */
  public applyDeductible(procedure: ProcedureInput, tier: CoverageTier): DeductibleResult {
    // Calculate the total provider fee for this procedure (quantity × unit fee)
    const totalProviderFee = procedure.providerFee * procedure.quantity;

    // If provider fee is zero, no deductible applies
    if (totalProviderFee <= 0) {
      return {
        deductibleApplied: 0,
        remainingIndividual: this.getRemainingDeductible().individual,
        remainingFamily: this.getRemainingDeductible().family,
        waived: true,
        reason: 'Provider fee is $0 — no deductible applies',
      };
    }

    // Check if carrier has zero deductible (e.g., Manulife)
    if (this.carrierConfig.deductible.individual === 0 && this.carrierConfig.deductible.family === 0) {
      return {
        deductibleApplied: 0,
        remainingIndividual: 0,
        remainingFamily: 0,
        waived: true,
        reason: 'Carrier has $0 deductible — no deductible applies to any procedure',
      };
    }

    // Check if this tier requires deductible (e.g., preventive may be excluded)
    const deductibleAppliesToTier = this.carrierConfig.deductible.appliesTo.includes(tier);
    if (!deductibleAppliesToTier) {
      return {
        deductibleApplied: 0,
        remainingIndividual: this.getRemainingDeductible().individual,
        remainingFamily: this.getRemainingDeductible().family,
        waived: true,
        reason: `Deductible does not apply to ${tier} tier for this carrier`,
      };
    }

    // Check if preventive deductible is waived
    if (tier === 'preventive' && this.carrierConfig.deductible.waiveForPreventive) {
      return {
        deductibleApplied: 0,
        remainingIndividual: this.getRemainingDeductible().individual,
        remainingFamily: this.getRemainingDeductible().family,
        waived: true,
        reason: 'Preventive deductible is waived per carrier configuration',
      };
    }

    // Calculate remaining deductible amounts
    const remainingIndividual = this.getRemainingDeductible().individual;
    const remainingFamily = this.getRemainingDeductible().family;

    // If both individual and family deductibles are already met, no more deductible applies
    if (remainingIndividual <= 0 && remainingFamily <= 0) {
      return {
        deductibleApplied: 0,
        remainingIndividual: 0,
        remainingFamily: 0,
        waived: true,
        reason: 'Both individual and family deductibles have been met for the plan year',
      };
    }

    // Determine how much deductible to apply to this procedure
    // Apply the lesser of: (a) remaining individual deductible, (b) remaining family deductible, (c) provider fee
    const deductibleToApply = Math.min(remainingIndividual, remainingFamily, totalProviderFee);

    // Update running totals
    this.usedIndividual += deductibleToApply;
    this.usedFamily += deductibleToApply;

    // Recalculate remaining amounts after applying deductible
    const newRemaining = this.getRemainingDeductible();

    return {
      deductibleApplied: deductibleToApply,
      remainingIndividual: newRemaining.individual,
      remainingFamily: newRemaining.family,
      waived: false,
      reason: `Deductible applied to ${tier} procedure: $${deductibleToApply.toFixed(2)} of provider fee`,
    };
  }

  /**
   * Reset the tracker to initial state
   *
   * Used when starting a new plan year or resetting deductible tracking.
   * Clears running totals and restarts from zero.
   */
  public reset(): void {
    this.usedIndividual = 0;
    this.usedFamily = 0;
  }
}

/**
 * Convenience function to process a batch of procedures with deductible applied
 *
 * Creates a DeductibleTracker, applies deductible to each procedure in order,
 * and returns results for all procedures in the batch.
 *
 * @param config - Carrier configuration
 * @param snapshot - Current eligibility snapshot
 * @param procedures - Array of {procedure, tier} objects to process
 * @returns Array of DeductibleResult, one per input procedure, in the same order
 *
 * @example
 * const results = calculateDeductibleForBatch(
 *   carrierConfig,
 *   eligibilitySnapshot,
 *   [
 *     { procedure: { cdtCode: 'D1110', providerFee: 150, quantity: 1, ... }, tier: 'preventive' },
 *     { procedure: { cdtCode: 'D2160', providerFee: 300, quantity: 1, ... }, tier: 'basic' },
 *   ]
 * );
 * // results[0] => waived: true (preventive waived)
 * // results[1] => deductibleApplied: 50 (assuming $50 remaining individual deductible)
 */
export function calculateDeductibleForBatch(
  config: CarrierConfig,
  snapshot: EligibilitySnapshot,
  procedures: Array<{ procedure: ProcedureInput; tier: CoverageTier }>
): DeductibleResult[] {
  const tracker = new DeductibleTracker(config, snapshot);
  const results: DeductibleResult[] = [];

  for (const { procedure, tier } of procedures) {
    const result = tracker.applyDeductible(procedure, tier);
    results.push(result);
  }

  return results;
}
