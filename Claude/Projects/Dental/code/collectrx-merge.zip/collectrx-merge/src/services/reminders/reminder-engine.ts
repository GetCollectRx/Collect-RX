/**
 * CollectRx Reminder Engine
 *
 * Automates multi-step payment reminder sequences for patients with outstanding balances.
 * When a patient has a balance after insurance reconciliation, a reminder sequence is started
 * that sends escalating communications over time.
 *
 * The engine manages:
 * - Creating reminder sequences from templates
 * - Processing scheduled reminder steps
 * - Handling communication delivery (email/SMS)
 * - Managing sequence lifecycle (active, paused, completed, cancelled)
 * - Automatic balance reconciliation and sequence cancellation
 */

import {
  ReminderSequence,
  ReminderStep,
  ReminderSequenceTemplate,
  ReminderSequenceStatus,
  CommunicationType,
  CommunicationPurpose,
  PatientBalance,
} from '../payments/types'

/**
 * Result of processing multiple reminder sequences
 */
export interface ProcessingResult {
  /** Total sequences processed */
  processed: number
  /** Total communications sent */
  sent: number
  /** Total steps skipped due to missing contact info */
  skipped: number
  /** Total sequences cancelled due to payment */
  cancelled: number
  /** Array of error messages */
  errors: string[]
  /** Detailed results for each sequence/step */
  details: Array<{
    sequenceId: string
    patientId: string
    action: 'sent' | 'skipped' | 'cancelled' | 'error'
    stepNumber?: number
    communicationType?: string
    reason?: string
  }>
}

/**
 * Service for sending communications (dependency injection)
 * Type reference only - actual implementation in communications/communication-service
 */
interface CommunicationService {
  sendFromTemplate(params: {
    patientId: string
    practiceId: string
    type: CommunicationType
    purpose: CommunicationPurpose
    templateId: string
    recipient: string
    variables?: Record<string, string | number>
    paymentLinkId?: string
  }): Promise<any>
}

/**
 * ReminderEngine class manages automated payment reminder workflows
 * Handles sequence creation, step processing, and communication dispatch
 */
export class ReminderEngine {
  /**
   * Initialize the reminder engine with a communication service
   * @param communicationService - Service for sending email/SMS communications
   */
  constructor(private communicationService: CommunicationService) {}

  /**
   * Create a new reminder sequence from a template
   *
   * Initializes a reminder sequence with pre-calculated step schedules based on the
   * selected template. If no template is specified, selects an appropriate default
   * based on balance amount and age. All step dates are calculated relative to the
   * current time.
   *
   * @param params - Parameters for creating the sequence
   * @param params.patientId - Patient ID for the reminder
   * @param params.practiceId - Practice ID initiating reminders
   * @param params.paymentLinkId - Payment link ID for the balance
   * @param params.balanceAmount - Outstanding balance in cents (CAD)
   * @param params.templateId - Optional template ID; auto-selects if omitted
   * @param params.patientContact - Patient contact info (email/phone)
   * @param params.patientName - Patient full name for personalization
   * @param params.practiceName - Practice name for personalization
   * @returns Newly created reminder sequence with all steps scheduled
   */
  async createSequence(params: {
    patientId: string
    practiceId: string
    paymentLinkId: string
    balanceAmount: number
    templateId?: string
    patientContact: { email?: string; phone?: string }
    patientName: string
    practiceName: string
  }): Promise<ReminderSequence> {
    const now = new Date()

    // Select appropriate template
    let template: ReminderSequenceTemplate
    if (params.templateId) {
      // In production, would look up template by ID
      template = DEFAULT_REMINDER_TEMPLATES[0]
    } else {
      // Auto-select template based on balance characteristics
      template = this.selectTemplateForBalance(params.balanceAmount, 0)
    }

    // Convert template steps to sequence steps with calculated dates
    const steps = this.calculateStepSchedule(
      template.steps.map((step, index) => ({
        stepNumber: index + 1,
        type: step.type,
        purpose: step.purpose,
        delayDays: step.delayDays,
        templateId: step.templateId,
        status: 'scheduled' as const,
      })),
      now
    )

    // Create the reminder sequence
    const sequence: ReminderSequence = {
      id: `seq_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      patientId: params.patientId,
      practiceId: params.practiceId,
      paymentLinkId: params.paymentLinkId,
      balanceAmount: params.balanceAmount,
      status: 'active',
      currentStep: 0,
      steps,
      startedAt: now.toISOString(),
      createdAt: now.toISOString(),
    }

    return sequence
  }

  /**
   * Process the next due step in a reminder sequence
   *
   * Checks if the sequence is still active and if the current step is due.
   * Validates patient contact information, sends the communication via the
   * communication service, and updates the sequence state. Handles early
   * termination if patient has already paid the balance.
   *
   * @param sequence - The reminder sequence to process
   * @returns Object containing updated sequence, optional communication sent, and skip reason
   * @returns .sequence - Updated sequence with step state changes
   * @returns .communication - The communication sent (if any)
   * @returns .skipped - Whether the step was skipped
   * @returns .reason - Reason for skipping (if applicable)
   */
  async processNextStep(
    sequence: ReminderSequence
  ): Promise<{
    sequence: ReminderSequence
    communication?: any
    skipped: boolean
    reason?: string
  }> {
    // Check if sequence is still active
    if (sequence.status !== 'active') {
      return {
        sequence,
        skipped: true,
        reason: `Sequence status is ${sequence.status}`,
      }
    }

    // Check if all steps are complete
    if (sequence.currentStep >= sequence.steps.length) {
      sequence.status = 'completed'
      sequence.completedAt = new Date().toISOString()
      return {
        sequence,
        skipped: true,
        reason: 'All steps completed',
      }
    }

    const step = sequence.steps[sequence.currentStep]
    const now = new Date()

    // Check if step is scheduled and due
    if (!step.scheduledAt || new Date(step.scheduledAt) > now) {
      return {
        sequence,
        skipped: true,
        reason: 'Step not yet due',
      }
    }

    // Validate contact information for the communication type
    if (step.type === 'sms') {
      // In production, would retrieve patient contact info from database
      if (!sequence.patientId) {
        step.status = 'skipped'
        step.skipReason = 'No phone number on file'
        sequence.currentStep++
        return {
          sequence,
          skipped: true,
          reason: 'No phone number available',
        }
      }
    } else if (step.type === 'email') {
      // In production, would retrieve patient contact info from database
      if (!sequence.patientId) {
        step.status = 'skipped'
        step.skipReason = 'No email on file'
        sequence.currentStep++
        return {
          sequence,
          skipped: true,
          reason: 'No email available',
        }
      }
    }

    // Send the communication
    try {
      const communication = await this.communicationService.sendFromTemplate({
        patientId: sequence.patientId,
        practiceId: sequence.practiceId,
        type: step.type,
        purpose: step.purpose,
        templateId: step.templateId,
        recipient: '', // In production, populated with actual contact info
        paymentLinkId: sequence.paymentLinkId,
        variables: {
          patientName: sequence.patientId,
          practiceName: sequence.practiceId,
          amount: sequence.balanceAmount / 100,
        },
      })

      // Update step status
      step.status = 'sent'
      step.sentAt = now.toISOString()
      step.communicationId = communication.id

      // Move to next step
      sequence.currentStep++

      // Check if all steps are now complete
      if (sequence.currentStep >= sequence.steps.length) {
        sequence.status = 'completed'
        sequence.completedAt = now.toISOString()
      }

      sequence.updatedAt = now.toISOString()

      return {
        sequence,
        communication,
        skipped: false,
      }
    } catch (error) {
      step.status = 'failed'
      step.skipReason = error instanceof Error ? error.message : 'Unknown error'
      sequence.currentStep++
      sequence.updatedAt = new Date().toISOString()

      return {
        sequence,
        skipped: true,
        reason: `Failed to send: ${step.skipReason}`,
      }
    }
  }

  /**
   * Process all due reminders from multiple sequences
   *
   * Iterates through provided sequences, checks current patient balances,
   * processes any due steps, and handles auto-cancellation for paid balances.
   * This is the primary batch processing method for reminder workflows.
   *
   * @param sequences - Array of reminder sequences to process
   * @param balanceLookup - Async function to get current patient balance
   * @returns Aggregated processing results with detailed action log
   */
  async processAllDueReminders(
    sequences: ReminderSequence[],
    balanceLookup: (patientId: string) => Promise<number>
  ): Promise<ProcessingResult> {
    const result: ProcessingResult = {
      processed: 0,
      sent: 0,
      skipped: 0,
      cancelled: 0,
      errors: [],
      details: [],
    }

    for (const sequence of sequences) {
      // Check if this sequence has a due step
      const dueSteps = this.getNextDueSequences([sequence])
      if (dueSteps.length === 0) {
        continue
      }

      try {
        // Check current patient balance
        const currentBalance = await balanceLookup(sequence.patientId)

        // If balance is fully paid, auto-cancel the sequence
        if (currentBalance === 0) {
          sequence.status = 'cancelled'
          sequence.cancelledAt = new Date().toISOString()
          sequence.cancelReason = 'Balance paid in full'
          result.cancelled++
          result.details.push({
            sequenceId: sequence.id,
            patientId: sequence.patientId,
            action: 'cancelled',
            reason: 'Balance paid in full',
          })
          continue
        }

        // Process the next step
        const { skipped, communication } = await this.processNextStep(sequence)
        result.processed++

        if (skipped) {
          result.skipped++
          result.details.push({
            sequenceId: sequence.id,
            patientId: sequence.patientId,
            action: 'skipped',
            stepNumber: sequence.currentStep,
          })
        } else {
          result.sent++
          const step = sequence.steps[sequence.currentStep - 1]
          result.details.push({
            sequenceId: sequence.id,
            patientId: sequence.patientId,
            action: 'sent',
            stepNumber: sequence.currentStep - 1,
            communicationType: step.type,
          })
        }
      } catch (error) {
        result.processed++
        result.errors.push(
          `Error processing sequence ${sequence.id}: ${
            error instanceof Error ? error.message : 'Unknown error'
          }`
        )
        result.details.push({
          sequenceId: sequence.id,
          patientId: sequence.patientId,
          action: 'error',
          reason: error instanceof Error ? error.message : 'Unknown error',
        })
      }
    }

    return result
  }

  /**
   * Cancel a reminder sequence
   *
   * Stops all pending reminders and marks the sequence as cancelled.
   * All pending and scheduled steps are marked as skipped.
   *
   * @param sequence - The sequence to cancel
   * @param reason - Reason for cancellation
   * @returns Updated sequence with cancelled status
   */
  cancelSequence(sequence: ReminderSequence, reason: string): ReminderSequence {
    sequence.status = 'cancelled'
    sequence.cancelledAt = new Date().toISOString()
    sequence.cancelReason = reason

    // Mark all pending steps as skipped
    for (let i = sequence.currentStep; i < sequence.steps.length; i++) {
      sequence.steps[i].status = 'skipped'
      sequence.steps[i].skipReason = reason
    }

    sequence.updatedAt = new Date().toISOString()
    return sequence
  }

  /**
   * Pause a reminder sequence temporarily
   *
   * Pauses the sequence without cancelling it. Can be resumed later
   * to continue from the current step.
   *
   * @param sequence - The sequence to pause
   * @returns Updated sequence with paused status
   */
  pauseSequence(sequence: ReminderSequence): ReminderSequence {
    sequence.status = 'paused'
    sequence.updatedAt = new Date().toISOString()
    return sequence
  }

  /**
   * Resume a paused reminder sequence
   *
   * Resumes a paused sequence and recalculates scheduled dates for
   * remaining steps starting from the current time.
   *
   * @param sequence - The paused sequence to resume
   * @returns Updated sequence with active status and recalculated dates
   */
  resumeSequence(sequence: ReminderSequence): ReminderSequence {
    if (sequence.status !== 'paused') {
      return sequence
    }

    sequence.status = 'active'

    // Recalculate scheduled dates for remaining steps from now
    const now = new Date()
    const remainingSteps = sequence.steps.slice(sequence.currentStep)

    for (let i = 0; i < remainingSteps.length; i++) {
      const step = remainingSteps[i]
      const delayMs = step.delayDays * 24 * 60 * 60 * 1000
      step.scheduledAt = new Date(now.getTime() + delayMs).toISOString()
    }

    sequence.updatedAt = new Date().toISOString()
    return sequence
  }

  /**
   * Get sequences with steps due before a given date
   *
   * Filters active sequences that have pending steps scheduled
   * before the specified time (or now if not specified).
   *
   * @param sequences - Sequences to filter
   * @param asOf - Optional cutoff date (default: now)
   * @returns Filtered sequences with due steps
   */
  getNextDueSequences(
    sequences: ReminderSequence[],
    asOf?: Date
  ): ReminderSequence[] {
    const cutoff = asOf || new Date()

    return sequences.filter((seq) => {
      if (seq.status !== 'active') return false
      if (seq.currentStep >= seq.steps.length) return false

      const currentStep = seq.steps[seq.currentStep]
      if (!currentStep.scheduledAt) return false

      return new Date(currentStep.scheduledAt) <= cutoff
    })
  }

  /**
   * Calculate scheduled dates for reminder steps
   *
   * Calculates the scheduledAt timestamp for each step based on its
   * delayDays offset from the start date. Used during sequence creation
   * and when resuming paused sequences.
   *
   * @param steps - Steps to schedule
   * @param startDate - Base date for calculations
   * @returns Steps with calculated scheduledAt timestamps
   */
  calculateStepSchedule(
    steps: ReminderStep[],
    startDate: Date
  ): ReminderStep[] {
    return steps.map((step) => {
      const delayMs = step.delayDays * 24 * 60 * 60 * 1000
      return {
        ...step,
        scheduledAt: new Date(startDate.getTime() + delayMs).toISOString(),
      }
    })
  }

  /**
   * Select appropriate reminder template based on balance characteristics
   *
   * Auto-selects a template based on balance amount and age:
   * - Under $100: Gentle Reminder (minimal escalation)
   * - $100-$500 or under 60 days old: Standard 30-Day Collection
   * - Over $500 or 90+ days old: Urgent Collection (more aggressive)
   *
   * @param balance - Outstanding balance in cents (CAD)
   * @param balanceAge - Age of the balance in days
   * @returns Selected reminder sequence template
   */
  selectTemplateForBalance(
    balance: number,
    balanceAge: number
  ): ReminderSequenceTemplate {
    // Convert balance from cents to dollars for easier comparison
    const balanceInDollars = balance / 100

    if (balanceInDollars < 100) {
      return DEFAULT_REMINDER_TEMPLATES[1] // Gentle Reminder
    } else if (balanceInDollars <= 500 && balanceAge < 60) {
      return DEFAULT_REMINDER_TEMPLATES[0] // Standard 30-Day Collection
    } else {
      return DEFAULT_REMINDER_TEMPLATES[2] // Urgent Collection
    }
  }
}

/**
 * Default reminder sequence templates
 *
 * Pre-configured templates for common collection scenarios.
 * These can be customized per practice but provide sensible defaults.
 */
export const DEFAULT_REMINDER_TEMPLATES: ReminderSequenceTemplate[] = [
  {
    id: 'template_standard_30day',
    practiceId: 'default',
    name: 'Standard 30-Day Collection',
    isDefault: true,
    steps: [
      {
        stepNumber: 1,
        type: 'sms' as CommunicationType,
        purpose: 'payment_link' as CommunicationPurpose,
        delayDays: 0,
        templateId: 'sms_payment_link_001',
      },
      {
        stepNumber: 2,
        type: 'email' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 3,
        templateId: 'email_payment_reminder_001',
      },
      {
        stepNumber: 3,
        type: 'sms' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 10,
        templateId: 'sms_payment_reminder_002',
      },
      {
        stepNumber: 4,
        type: 'email' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 20,
        templateId: 'email_payment_reminder_002',
      },
      {
        stepNumber: 5,
        type: 'email' as CommunicationType,
        purpose: 'collection_notice' as CommunicationPurpose,
        delayDays: 30,
        templateId: 'email_collection_notice_001',
      },
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'template_gentle_reminder',
    practiceId: 'default',
    name: 'Gentle Reminder',
    isDefault: false,
    steps: [
      {
        stepNumber: 1,
        type: 'email' as CommunicationType,
        purpose: 'payment_link' as CommunicationPurpose,
        delayDays: 0,
        templateId: 'email_payment_link_001',
      },
      {
        stepNumber: 2,
        type: 'sms' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 14,
        templateId: 'sms_payment_reminder_001',
      },
      {
        stepNumber: 3,
        type: 'email' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 30,
        templateId: 'email_payment_reminder_003',
      },
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'template_urgent_collection',
    practiceId: 'default',
    name: 'Urgent Collection',
    isDefault: false,
    steps: [
      {
        stepNumber: 1,
        type: 'sms' as CommunicationType,
        purpose: 'payment_link' as CommunicationPurpose,
        delayDays: 0,
        templateId: 'sms_payment_link_002',
      },
      {
        stepNumber: 2,
        type: 'email' as CommunicationType,
        purpose: 'payment_link' as CommunicationPurpose,
        delayDays: 0,
        templateId: 'email_payment_link_002',
      },
      {
        stepNumber: 3,
        type: 'sms' as CommunicationType,
        purpose: 'payment_reminder' as CommunicationPurpose,
        delayDays: 5,
        templateId: 'sms_payment_reminder_003',
      },
      {
        stepNumber: 4,
        type: 'email' as CommunicationType,
        purpose: 'collection_notice' as CommunicationPurpose,
        delayDays: 10,
        templateId: 'email_collection_notice_002',
      },
      {
        stepNumber: 5,
        type: 'sms' as CommunicationType,
        purpose: 'collection_notice' as CommunicationPurpose,
        delayDays: 15,
        templateId: 'sms_collection_notice_001',
      },
    ],
    createdAt: new Date().toISOString(),
  },
]
