/**
 * CollectRx Patient Payment System - Express Routes
 *
 * Comprehensive Express router for all payment collection endpoints.
 * Implements Stripe Connect integration for dental practice payments,
 * reminder sequences, write-off management, and communication tracking.
 *
 * All amounts are in cents (CAD) for precision in accounting.
 * Bearer token auth required on all routes except webhooks.
 */

import { Router, Request, Response, NextFunction } from 'express'
import { Pool } from 'pg'
import { body, query, param, validationResult } from 'express-validator'
import { z } from 'zod'

import {
  StripeConnectedAccount,
  PaymentLink,
  PaymentLineItem,
  CreatePaymentLinkRequest,
  CreatePaymentLinkResponse,
  PaymentTransaction,
  RefundRequest,
  ReminderSequence,
  ReminderSequenceTemplate,
  WriteOff,
  WriteOffSummary,
  Communication,
  PatientBalance,
  PatientLedgerEntry,
  PatientPaymentSummary,
} from '../services/payments/types'

// Service interfaces (stubs - these would be injected)
interface StripeConnectService {
  createConnectedAccount(practiceId: string, email: string, businessName: string): Promise<StripeConnectedAccount>
  getOnboardingLink(practiceId: string, returnUrl: string, refreshUrl: string): Promise<{ url: string }>
  getAccountStatus(practiceId: string): Promise<StripeConnectedAccount>
  createPaymentCheckout(practiceId: string, lineItems: PaymentLineItem[], metadata: Record<string, string>): Promise<{ sessionId: string; url: string }>
  processRefund(transactionId: string, amount?: number): Promise<any>
  verifyWebhookSignature(body: string, signature: string): boolean
  parseWebhookEvent(body: string, signature: string): Promise<any>
}

interface CommunicationService {
  sendPaymentLink(patientId: string, practiceId: string, linkId: string, contactInfo: { email?: string; phone?: string }): Promise<Communication>
  sendReminder(patientId: string, practiceId: string, templateId: string, variables: Record<string, string>): Promise<Communication>
  getPatientCommunications(patientId: string, type?: string, purpose?: string, limit?: number, offset?: number): Promise<Communication[]>
  getDeliveryStats(practiceId: string, from?: string, to?: string): Promise<any>
}

interface ReminderEngine {
  startSequence(
    patientId: string,
    practiceId: string,
    paymentLinkId: string,
    balanceAmount: number,
    templateId?: string,
    contact?: { email?: string; phone?: string }
  ): Promise<ReminderSequence>
  getSequence(sequenceId: string): Promise<ReminderSequence>
  cancelSequence(sequenceId: string, reason: string): Promise<ReminderSequence>
  pauseSequence(sequenceId: string): Promise<ReminderSequence>
  resumeSequence(sequenceId: string): Promise<ReminderSequence>
  processReminders(): Promise<{ processed: number; failed: number; nextRun: string }>
  getTemplates(practiceId?: string): Promise<ReminderSequenceTemplate[]>
}

interface WriteOffService {
  createWriteOff(
    patientId: string,
    practiceId: string,
    amount: number,
    reason: string,
    notes: string,
    requestedBy: string,
    claimId?: string
  ): Promise<WriteOff>
  getWriteOff(writeOffId: string): Promise<WriteOff>
  approveWriteOff(writeOffId: string, approvedBy: string): Promise<WriteOff>
  rejectWriteOff(writeOffId: string, rejectedBy: string, rejectionReason: string): Promise<WriteOff>
  reverseWriteOff(writeOffId: string, reversalReason: string): Promise<WriteOff>
  batchWriteOffSmallBalances(threshold: number, practiceId: string): Promise<{ count: number; totalAmount: number; writeOffs: WriteOff[] }>
  getSummary(practiceId: string, from?: string, to?: string): Promise<WriteOffSummary>
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

/**
 * Bearer token authentication middleware.
 * Validates Authorization header format and token presence.
 */
function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Missing or invalid Bearer token',
      code: 'AUTH_MISSING',
    })
  }

  const token = authHeader.substring(7)

  if (!token || token.length === 0) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Empty Bearer token',
      code: 'AUTH_EMPTY',
    })
  }

  // TODO: Validate token against session/JWT store
  // For now, just ensure it's present
  next()
}

/**
 * Validation error handler middleware.
 * Consolidates express-validator errors into a single response.
 */
function handleValidationErrors(req: Request, res: Response, next: NextFunction) {
  const errors = validationResult(req)

  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      code: 'VALIDATION_ERROR',
      details: errors.array().map((err: any) => ({
        field: err.param,
        message: err.msg,
        value: err.value,
      })),
    })
  }

  next()
}

/**
 * Error handling wrapper for async route handlers.
 */
function asyncHandler(fn: Function) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next)
  }
}

/**
 * Global error handler middleware.
 * Logs errors and returns standardized error responses.
 */
function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  console.error('[PaymentRoutes] Error:', {
    message: err.message,
    code: err.code,
    statusCode: err.statusCode || 500,
    path: req.path,
    method: req.method,
  })

  const statusCode = err.statusCode || 500
  const message = err.message || 'Internal server error'

  res.status(statusCode).json({
    error: err.code || 'INTERNAL_ERROR',
    message,
    details: process.env.NODE_ENV === 'development' ? err.stack : undefined,
  })
}

// ============================================================================
// ROUTER FACTORY
// ============================================================================

/**
 * Creates and returns the payment routes router.
 * Factory pattern allows dependency injection of services.
 *
 * @param pool - PostgreSQL connection pool
 * @param stripeConnect - Stripe Connect service
 * @param communicationService - Communication/SMS/Email service
 * @param reminderEngine - Reminder sequence automation engine
 * @param writeOffService - Write-off management service
 * @returns Configured Express router
 */
export function createPaymentRoutes(
  pool: Pool,
  stripeConnect: StripeConnectService,
  communicationService: CommunicationService,
  reminderEngine: ReminderEngine,
  writeOffService: WriteOffService
): Router {
  const router = Router()

  // Apply global middleware
  router.use(authMiddleware)

  // ========================================================================
  // STRIPE CONNECTED ACCOUNT ENDPOINTS
  // ========================================================================

  /**
   * POST /api/payments/connect/create
   * Create a new Stripe Connected Account for a dental practice.
   * The practice becomes the merchant of record.
   */
  router.post(
    '/connect/create',
    [
      body('practiceId')
        .trim()
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      body('email')
        .trim()
        .notEmpty()
        .withMessage('email is required')
        .isEmail()
        .withMessage('email must be a valid email address'),
      body('businessName')
        .trim()
        .notEmpty()
        .withMessage('businessName is required')
        .isLength({ min: 1, max: 255 })
        .withMessage('businessName must be between 1 and 255 characters'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { practiceId, email, businessName } = req.body

      console.log('[PaymentRoutes] Creating Stripe Connected Account', { practiceId, email, businessName })

      try {
        const account = await stripeConnect.createConnectedAccount(practiceId, email, businessName)

        res.status(201).json({
          success: true,
          data: account,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to create connected account:', error.message)
        throw {
          statusCode: 400,
          code: 'STRIPE_ACCOUNT_CREATE_FAILED',
          message: error.message || 'Failed to create Stripe connected account',
        }
      }
    })
  )

  /**
   * GET /api/payments/connect/:practiceId/onboarding
   * Get the Stripe Connect onboarding link for a practice.
   */
  router.get(
    '/connect/:practiceId/onboarding',
    [
      param('practiceId')
        .trim()
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      query('returnUrl')
        .notEmpty()
        .withMessage('returnUrl is required')
        .isURL()
        .withMessage('returnUrl must be a valid URL'),
      query('refreshUrl')
        .notEmpty()
        .withMessage('refreshUrl is required')
        .isURL()
        .withMessage('refreshUrl must be a valid URL'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { practiceId } = req.params
      const { returnUrl, refreshUrl } = req.query

      console.log('[PaymentRoutes] Getting onboarding link', { practiceId, returnUrl })

      try {
        const result = await stripeConnect.getOnboardingLink(
          practiceId,
          returnUrl as string,
          refreshUrl as string
        )

        res.json({
          success: true,
          data: result,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get onboarding link:', error.message)
        throw {
          statusCode: 400,
          code: 'ONBOARDING_LINK_FAILED',
          message: error.message || 'Failed to get onboarding link',
        }
      }
    })
  )

  /**
   * GET /api/payments/connect/:practiceId/status
   * Get the current status of a practice's Stripe Connected Account.
   */
  router.get(
    '/connect/:practiceId/status',
    [
      param('practiceId')
        .trim()
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { practiceId } = req.params

      console.log('[PaymentRoutes] Getting account status', { practiceId })

      try {
        const status = await stripeConnect.getAccountStatus(practiceId)

        res.json({
          success: true,
          data: status,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get account status:', error.message)
        throw {
          statusCode: 404,
          code: 'ACCOUNT_NOT_FOUND',
          message: 'Stripe account not found for this practice',
        }
      }
    })
  )

  // ========================================================================
  // PAYMENT LINK ENDPOINTS
  // ========================================================================

  /**
   * POST /api/payments/links
   * Create a new payment link for a patient.
   * Optionally starts a reminder sequence if sendReminder is true.
   */
  router.post(
    '/links',
    [
      body('patientId')
        .trim()
        .notEmpty()
        .withMessage('patientId is required')
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      body('lineItems')
        .isArray({ min: 1 })
        .withMessage('lineItems must be a non-empty array'),
      body('lineItems.*.description')
        .trim()
        .notEmpty()
        .withMessage('lineItem.description is required'),
      body('lineItems.*.amount')
        .isInt({ min: 1 })
        .withMessage('lineItem.amount must be a positive integer (in cents)'),
      body('lineItems.*.claimId')
        .optional()
        .isUUID()
        .withMessage('lineItem.claimId must be a valid UUID if provided'),
      body('lineItems.*.cdtCode')
        .optional()
        .matches(/^D\d{4}$/)
        .withMessage('lineItem.cdtCode must match CDT format (e.g., D2750)'),
      body('sendReminder')
        .isBoolean()
        .withMessage('sendReminder must be a boolean'),
      body('reminderType')
        .optional()
        .isIn(['sms', 'email'])
        .withMessage('reminderType must be "sms" or "email"'),
      body('expiresInDays')
        .optional()
        .isInt({ min: 1, max: 365 })
        .withMessage('expiresInDays must be between 1 and 365'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId, lineItems, sendReminder, reminderType, expiresInDays } = req.body

      // Extract practiceId from context (would come from JWT or session)
      const practiceId = req.headers['x-practice-id'] as string

      if (!practiceId) {
        return res.status(400).json({
          error: 'Missing practice context',
          code: 'PRACTICE_CONTEXT_MISSING',
          message: 'x-practice-id header is required',
        })
      }

      console.log('[PaymentRoutes] Creating payment link', { patientId, practiceId, amount: lineItems.reduce((sum: number, li: any) => sum + li.amount, 0) })

      try {
        // Calculate total amount
        const totalAmount = lineItems.reduce((sum: number, item: PaymentLineItem) => sum + item.amount, 0)

        // Create checkout session via Stripe Connect
        const { sessionId, url } = await stripeConnect.createPaymentCheckout(
          practiceId,
          lineItems,
          {
            patientId,
            practiceId,
          }
        )

        // Create payment link record in database
        const result = await pool.query(
          `INSERT INTO payment_links (patient_id, practice_id, stripe_session_id, amount, currency, description, status, line_items, metadata, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
           RETURNING *`,
          [
            patientId,
            practiceId,
            sessionId,
            totalAmount,
            'cad',
            `Payment for services rendered`,
            'active',
            JSON.stringify(lineItems),
            JSON.stringify({ source: 'api' }),
          ]
        )

        const paymentLink = result.rows[0]

        // Optionally start reminder sequence
        let communication
        if (sendReminder) {
          communication = await communicationService.sendPaymentLink(
            patientId,
            practiceId,
            paymentLink.id,
            { email: undefined, phone: undefined } // Would come from patient record
          )
        }

        const response: CreatePaymentLinkResponse = {
          paymentLink: {
            id: paymentLink.id,
            patientId,
            practiceId,
            stripeSessionId: sessionId,
            amount: totalAmount,
            currency: 'cad',
            description: paymentLink.description,
            status: 'active',
            lineItems,
            createdAt: paymentLink.created_at,
            metadata: JSON.parse(paymentLink.metadata),
          },
          url,
          communication,
        }

        res.status(201).json({
          success: true,
          data: response,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to create payment link:', error.message)
        throw {
          statusCode: 400,
          code: 'PAYMENT_LINK_CREATE_FAILED',
          message: error.message || 'Failed to create payment link',
        }
      }
    })
  )

  /**
   * GET /api/payments/links/:linkId
   * Get details of a specific payment link.
   */
  router.get(
    '/links/:linkId',
    [
      param('linkId')
        .trim()
        .isUUID()
        .withMessage('linkId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { linkId } = req.params

      console.log('[PaymentRoutes] Getting payment link', { linkId })

      try {
        const result = await pool.query(
          `SELECT * FROM payment_links WHERE id = $1`,
          [linkId]
        )

        if (result.rowCount === 0) {
          return res.status(404).json({
            error: 'Not found',
            code: 'PAYMENT_LINK_NOT_FOUND',
            message: 'Payment link not found',
          })
        }

        const link = result.rows[0]

        res.json({
          success: true,
          data: {
            id: link.id,
            patientId: link.patient_id,
            practiceId: link.practice_id,
            stripeSessionId: link.stripe_session_id,
            amount: link.amount,
            currency: link.currency,
            description: link.description,
            status: link.status,
            lineItems: JSON.parse(link.line_items),
            createdAt: link.created_at,
            paidAt: link.paid_at,
            expiresAt: link.expires_at,
            metadata: JSON.parse(link.metadata),
          },
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get payment link:', error.message)
        throw {
          statusCode: 500,
          code: 'PAYMENT_LINK_FETCH_FAILED',
          message: 'Failed to fetch payment link',
        }
      }
    })
  )

  // ========================================================================
  // PATIENT PAYMENT ENDPOINTS
  // ========================================================================

  /**
   * GET /api/payments/patient/:patientId
   * Get comprehensive payment summary for a patient.
   */
  router.get(
    '/patient/:patientId',
    [
      param('patientId')
        .trim()
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId } = req.params
      const practiceId = req.headers['x-practice-id'] as string

      if (!practiceId) {
        return res.status(400).json({
          error: 'Missing practice context',
          code: 'PRACTICE_CONTEXT_MISSING',
        })
      }

      console.log('[PaymentRoutes] Getting patient payment summary', { patientId, practiceId })

      try {
        // Get patient balance
        const balanceResult = await pool.query(
          `SELECT * FROM patient_balances WHERE patient_id = $1 AND practice_id = $2`,
          [patientId, practiceId]
        )

        const balance = balanceResult.rows[0] || null

        // Get recent payments
        const paymentsResult = await pool.query(
          `SELECT * FROM payment_transactions
           WHERE patient_id = $1 AND practice_id = $2 AND status = 'succeeded'
           ORDER BY created_at DESC LIMIT 10`,
          [patientId, practiceId]
        )

        // Get active reminders
        const remindersResult = await pool.query(
          `SELECT * FROM reminder_sequences
           WHERE patient_id = $1 AND practice_id = $2 AND status IN ('active', 'paused')`,
          [patientId, practiceId]
        )

        // Get pending write-offs
        const writeOffsResult = await pool.query(
          `SELECT * FROM write_offs
           WHERE patient_id = $1 AND practice_id = $2 AND status = 'pending_approval'`,
          [patientId, practiceId]
        )

        // Get patient info
        const patientResult = await pool.query(
          `SELECT id, name FROM patients WHERE id = $1`,
          [patientId]
        )

        const patient = patientResult.rows[0]

        const summary: PatientPaymentSummary = {
          patient: {
            id: patient?.id || patientId,
            name: patient?.name || 'Unknown',
          },
          balance: balance || {
            patientId,
            practiceId,
            totalOutstanding: 0,
            insurancePending: 0,
            patientResponsibility: 0,
            totalPaid: 0,
            totalWrittenOff: 0,
            netBalance: 0,
            isInCollections: false,
            balanceAge: 0,
          },
          recentPayments: paymentsResult.rows.map((row: any) => ({
            id: row.id,
            paymentLinkId: row.payment_link_id,
            patientId: row.patient_id,
            practiceId: row.practice_id,
            stripePaymentIntentId: row.stripe_payment_intent_id,
            stripeChargeId: row.stripe_charge_id,
            amount: row.amount,
            currency: row.currency,
            status: row.status,
            paymentMethod: row.payment_method,
            receiptUrl: row.receipt_url,
            refundedAmount: row.refunded_amount,
            refundReason: row.refund_reason,
            processedAt: row.processed_at,
            createdAt: row.created_at,
          })),
          activeReminders: remindersResult.rows.map((row: any) => ({
            id: row.id,
            patientId: row.patient_id,
            practiceId: row.practice_id,
            paymentLinkId: row.payment_link_id,
            balanceAmount: row.balance_amount,
            status: row.status,
            currentStep: row.current_step,
            steps: JSON.parse(row.steps),
            startedAt: row.started_at,
            completedAt: row.completed_at,
            createdAt: row.created_at,
          })),
          pendingWriteOffs: writeOffsResult.rows.map((row: any) => ({
            id: row.id,
            patientId: row.patient_id,
            practiceId: row.practice_id,
            claimId: row.claim_id,
            amount: row.amount,
            reason: row.reason,
            status: row.status,
            notes: row.notes,
            requestedBy: row.requested_by,
            requestedAt: row.requested_at,
            createdAt: row.created_at,
          })),
          generatedAt: new Date().toISOString(),
        }

        res.json({
          success: true,
          data: summary,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get payment summary:', error.message)
        throw {
          statusCode: 500,
          code: 'PAYMENT_SUMMARY_FAILED',
          message: 'Failed to fetch payment summary',
        }
      }
    })
  )

  /**
   * GET /api/payments/patient/:patientId/transactions
   * Get paginated list of payment transactions for a patient.
   */
  router.get(
    '/patient/:patientId/transactions',
    [
      param('patientId')
        .trim()
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('limit must be between 1 and 100'),
      query('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('offset must be a non-negative integer'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId } = req.params
      const practiceId = req.headers['x-practice-id'] as string
      const limit = Math.min(parseInt(req.query.limit as string) || 20, 100)
      const offset = parseInt(req.query.offset as string) || 0

      if (!practiceId) {
        return res.status(400).json({
          error: 'Missing practice context',
          code: 'PRACTICE_CONTEXT_MISSING',
        })
      }

      console.log('[PaymentRoutes] Getting patient transactions', { patientId, practiceId, limit, offset })

      try {
        const countResult = await pool.query(
          `SELECT COUNT(*) FROM payment_transactions WHERE patient_id = $1 AND practice_id = $2`,
          [patientId, practiceId]
        )

        const transactionsResult = await pool.query(
          `SELECT * FROM payment_transactions
           WHERE patient_id = $1 AND practice_id = $2
           ORDER BY created_at DESC
           LIMIT $3 OFFSET $4`,
          [patientId, practiceId, limit, offset]
        )

        const transactions = transactionsResult.rows.map((row: any) => ({
          id: row.id,
          paymentLinkId: row.payment_link_id,
          patientId: row.patient_id,
          practiceId: row.practice_id,
          stripePaymentIntentId: row.stripe_payment_intent_id,
          stripeChargeId: row.stripe_charge_id,
          amount: row.amount,
          currency: row.currency,
          status: row.status,
          paymentMethod: row.payment_method,
          receiptUrl: row.receipt_url,
          refundedAmount: row.refunded_amount,
          refundReason: row.refund_reason,
          failureCode: row.failure_code,
          failureMessage: row.failure_message,
          processedAt: row.processed_at,
          createdAt: row.created_at,
        }))

        res.json({
          success: true,
          data: {
            transactions,
            pagination: {
              limit,
              offset,
              total: parseInt(countResult.rows[0].count),
              hasMore: offset + limit < parseInt(countResult.rows[0].count),
            },
          },
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get transactions:', error.message)
        throw {
          statusCode: 500,
          code: 'TRANSACTIONS_FETCH_FAILED',
          message: 'Failed to fetch transactions',
        }
      }
    })
  )

  // ========================================================================
  // REFUND ENDPOINTS
  // ========================================================================

  /**
   * POST /api/payments/refund
   * Process a refund for a payment transaction.
   */
  router.post(
    '/refund',
    [
      body('transactionId')
        .trim()
        .notEmpty()
        .withMessage('transactionId is required')
        .isUUID()
        .withMessage('transactionId must be a valid UUID'),
      body('amount')
        .optional()
        .isInt({ min: 1 })
        .withMessage('amount must be a positive integer (in cents)'),
      body('reason')
        .isIn(['duplicate', 'requested_by_patient', 'billing_error', 'other'])
        .withMessage('reason must be a valid refund reason'),
      body('notes')
        .trim()
        .notEmpty()
        .withMessage('notes are required'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { transactionId, amount, reason, notes } = req.body

      console.log('[PaymentRoutes] Processing refund', { transactionId, amount, reason })

      try {
        // Get the transaction
        const txResult = await pool.query(
          `SELECT * FROM payment_transactions WHERE id = $1`,
          [transactionId]
        )

        if (txResult.rowCount === 0) {
          return res.status(404).json({
            error: 'Not found',
            code: 'TRANSACTION_NOT_FOUND',
            message: 'Payment transaction not found',
          })
        }

        const transaction = txResult.rows[0]

        if (transaction.status !== 'succeeded') {
          return res.status(400).json({
            error: 'Invalid state',
            code: 'CANNOT_REFUND',
            message: 'Only succeeded transactions can be refunded',
          })
        }

        // Process refund via Stripe
        const refundResult = await stripeConnect.processRefund(
          transactionId,
          amount || transaction.amount
        )

        // Update transaction record
        const refundAmount = amount || transaction.amount
        const newRefundedAmount = (transaction.refunded_amount || 0) + refundAmount
        const newStatus = newRefundedAmount >= transaction.amount ? 'refunded' : 'partially_refunded'

        await pool.query(
          `UPDATE payment_transactions
           SET status = $1, refunded_amount = $2, refund_reason = $3, updated_at = NOW()
           WHERE id = $4`,
          [newStatus, newRefundedAmount, reason, transactionId]
        )

        // Record refund in ledger
        await pool.query(
          `INSERT INTO refund_records (transaction_id, amount, reason, notes, status, created_at)
           VALUES ($1, $2, $3, $4, $5, NOW())`,
          [transactionId, refundAmount, reason, notes, 'succeeded']
        )

        res.json({
          success: true,
          data: {
            transactionId,
            refundAmount,
            newStatus,
            refundId: refundResult.id,
          },
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to process refund:', error.message)
        throw {
          statusCode: 400,
          code: 'REFUND_FAILED',
          message: error.message || 'Failed to process refund',
        }
      }
    })
  )

  // ========================================================================
  // REMINDER SEQUENCE ENDPOINTS
  // ========================================================================

  /**
   * POST /api/reminders/sequences
   * Start a new reminder sequence for a patient.
   */
  router.post(
    '/reminders/sequences',
    [
      body('patientId')
        .trim()
        .notEmpty()
        .withMessage('patientId is required')
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      body('practiceId')
        .trim()
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      body('paymentLinkId')
        .trim()
        .notEmpty()
        .withMessage('paymentLinkId is required')
        .isUUID()
        .withMessage('paymentLinkId must be a valid UUID'),
      body('balanceAmount')
        .isInt({ min: 1 })
        .withMessage('balanceAmount must be a positive integer (in cents)'),
      body('templateId')
        .optional()
        .isUUID()
        .withMessage('templateId must be a valid UUID if provided'),
      body('contact.email')
        .optional()
        .isEmail()
        .withMessage('contact.email must be a valid email address if provided'),
      body('contact.phone')
        .optional()
        .matches(/^\+?1?\d{10,}$/)
        .withMessage('contact.phone must be a valid phone number if provided'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId, practiceId, paymentLinkId, balanceAmount, templateId, contact } = req.body

      console.log('[PaymentRoutes] Starting reminder sequence', {
        patientId,
        practiceId,
        balanceAmount,
      })

      try {
        const sequence = await reminderEngine.startSequence(
          patientId,
          practiceId,
          paymentLinkId,
          balanceAmount,
          templateId,
          contact
        )

        res.status(201).json({
          success: true,
          data: sequence,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to start sequence:', error.message)
        throw {
          statusCode: 400,
          code: 'SEQUENCE_START_FAILED',
          message: error.message || 'Failed to start reminder sequence',
        }
      }
    })
  )

  /**
   * GET /api/reminders/sequences/:sequenceId
   * Get details of a specific reminder sequence.
   */
  router.get(
    '/reminders/sequences/:sequenceId',
    [
      param('sequenceId')
        .trim()
        .isUUID()
        .withMessage('sequenceId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { sequenceId } = req.params

      console.log('[PaymentRoutes] Getting reminder sequence', { sequenceId })

      try {
        const sequence = await reminderEngine.getSequence(sequenceId)

        res.json({
          success: true,
          data: sequence,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get sequence:', error.message)
        throw {
          statusCode: 404,
          code: 'SEQUENCE_NOT_FOUND',
          message: 'Reminder sequence not found',
        }
      }
    })
  )

  /**
   * POST /api/reminders/sequences/:sequenceId/cancel
   * Cancel a reminder sequence.
   */
  router.post(
    '/reminders/sequences/:sequenceId/cancel',
    [
      param('sequenceId')
        .trim()
        .isUUID()
        .withMessage('sequenceId must be a valid UUID'),
      body('reason')
        .trim()
        .notEmpty()
        .withMessage('reason is required'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { sequenceId } = req.params
      const { reason } = req.body

      console.log('[PaymentRoutes] Cancelling reminder sequence', { sequenceId, reason })

      try {
        const sequence = await reminderEngine.cancelSequence(sequenceId, reason)

        res.json({
          success: true,
          data: sequence,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to cancel sequence:', error.message)
        throw {
          statusCode: 400,
          code: 'SEQUENCE_CANCEL_FAILED',
          message: error.message || 'Failed to cancel reminder sequence',
        }
      }
    })
  )

  /**
   * POST /api/reminders/sequences/:sequenceId/pause
   * Pause a reminder sequence.
   */
  router.post(
    '/reminders/sequences/:sequenceId/pause',
    [
      param('sequenceId')
        .trim()
        .isUUID()
        .withMessage('sequenceId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { sequenceId } = req.params

      console.log('[PaymentRoutes] Pausing reminder sequence', { sequenceId })

      try {
        const sequence = await reminderEngine.pauseSequence(sequenceId)

        res.json({
          success: true,
          data: sequence,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to pause sequence:', error.message)
        throw {
          statusCode: 400,
          code: 'SEQUENCE_PAUSE_FAILED',
          message: error.message || 'Failed to pause reminder sequence',
        }
      }
    })
  )

  /**
   * POST /api/reminders/sequences/:sequenceId/resume
   * Resume a paused reminder sequence.
   */
  router.post(
    '/reminders/sequences/:sequenceId/resume',
    [
      param('sequenceId')
        .trim()
        .isUUID()
        .withMessage('sequenceId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { sequenceId } = req.params

      console.log('[PaymentRoutes] Resuming reminder sequence', { sequenceId })

      try {
        const sequence = await reminderEngine.resumeSequence(sequenceId)

        res.json({
          success: true,
          data: sequence,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to resume sequence:', error.message)
        throw {
          statusCode: 400,
          code: 'SEQUENCE_RESUME_FAILED',
          message: error.message || 'Failed to resume reminder sequence',
        }
      }
    })
  )

  /**
   * POST /api/reminders/process
   * Process all due reminders (called by cron or manually).
   */
  router.post(
    '/reminders/process',
    asyncHandler(async (req: Request, res: Response) => {
      console.log('[PaymentRoutes] Processing due reminders')

      try {
        const result = await reminderEngine.processReminders()

        res.json({
          success: true,
          data: result,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to process reminders:', error.message)
        throw {
          statusCode: 500,
          code: 'REMINDER_PROCESSING_FAILED',
          message: error.message || 'Failed to process reminders',
        }
      }
    })
  )

  /**
   * GET /api/reminders/templates
   * Get available reminder sequence templates.
   */
  router.get(
    '/reminders/templates',
    asyncHandler(async (req: Request, res: Response) => {
      const practiceId = req.headers['x-practice-id'] as string

      console.log('[PaymentRoutes] Getting reminder templates', { practiceId })

      try {
        const templates = await reminderEngine.getTemplates(practiceId)

        res.json({
          success: true,
          data: templates,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get templates:', error.message)
        throw {
          statusCode: 500,
          code: 'TEMPLATES_FETCH_FAILED',
          message: 'Failed to fetch reminder templates',
        }
      }
    })
  )

  // ========================================================================
  // WRITE-OFF ENDPOINTS
  // ========================================================================

  /**
   * POST /api/writeoffs
   * Create a new write-off request.
   */
  router.post(
    '/writeoffs',
    [
      body('patientId')
        .trim()
        .notEmpty()
        .withMessage('patientId is required')
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      body('practiceId')
        .trim()
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      body('amount')
        .isInt({ min: 1 })
        .withMessage('amount must be a positive integer (in cents)'),
      body('reason')
        .isIn(['uncollectible', 'insurance_denial', 'billing_error', 'courtesy_adjustment', 'small_balance', 'hardship', 'other'])
        .withMessage('reason must be a valid write-off reason'),
      body('notes')
        .trim()
        .notEmpty()
        .withMessage('notes are required'),
      body('claimId')
        .optional()
        .isUUID()
        .withMessage('claimId must be a valid UUID if provided'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId, practiceId, amount, reason, notes, claimId } = req.body
      const requestedBy = req.headers['x-user-id'] as string

      if (!requestedBy) {
        return res.status(400).json({
          error: 'Missing user context',
          code: 'USER_CONTEXT_MISSING',
          message: 'x-user-id header is required',
        })
      }

      console.log('[PaymentRoutes] Creating write-off', { patientId, practiceId, amount, reason })

      try {
        const writeOff = await writeOffService.createWriteOff(
          patientId,
          practiceId,
          amount,
          reason,
          notes,
          requestedBy,
          claimId
        )

        res.status(201).json({
          success: true,
          data: writeOff,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to create write-off:', error.message)
        throw {
          statusCode: 400,
          code: 'WRITEOFF_CREATE_FAILED',
          message: error.message || 'Failed to create write-off',
        }
      }
    })
  )

  /**
   * GET /api/writeoffs/:writeoffId
   * Get details of a specific write-off.
   */
  router.get(
    '/writeoffs/:writeoffId',
    [
      param('writeoffId')
        .trim()
        .isUUID()
        .withMessage('writeoffId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { writeoffId } = req.params

      console.log('[PaymentRoutes] Getting write-off', { writeoffId })

      try {
        const writeOff = await writeOffService.getWriteOff(writeoffId)

        res.json({
          success: true,
          data: writeOff,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get write-off:', error.message)
        throw {
          statusCode: 404,
          code: 'WRITEOFF_NOT_FOUND',
          message: 'Write-off not found',
        }
      }
    })
  )

  /**
   * POST /api/writeoffs/:writeoffId/approve
   * Approve a pending write-off.
   */
  router.post(
    '/writeoffs/:writeoffId/approve',
    [
      param('writeoffId')
        .trim()
        .isUUID()
        .withMessage('writeoffId must be a valid UUID'),
      body('approvedBy')
        .trim()
        .notEmpty()
        .withMessage('approvedBy is required'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { writeoffId } = req.params
      const { approvedBy } = req.body

      console.log('[PaymentRoutes] Approving write-off', { writeoffId, approvedBy })

      try {
        const writeOff = await writeOffService.approveWriteOff(writeoffId, approvedBy)

        res.json({
          success: true,
          data: writeOff,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to approve write-off:', error.message)
        throw {
          statusCode: 400,
          code: 'WRITEOFF_APPROVE_FAILED',
          message: error.message || 'Failed to approve write-off',
        }
      }
    })
  )

  /**
   * POST /api/writeoffs/:writeoffId/reject
   * Reject a pending write-off.
   */
  router.post(
    '/writeoffs/:writeoffId/reject',
    [
      param('writeoffId')
        .trim()
        .isUUID()
        .withMessage('writeoffId must be a valid UUID'),
      body('rejectedBy')
        .trim()
        .notEmpty()
        .withMessage('rejectedBy is required'),
      body('rejectionReason')
        .trim()
        .notEmpty()
        .withMessage('rejectionReason is required'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { writeoffId } = req.params
      const { rejectedBy, rejectionReason } = req.body

      console.log('[PaymentRoutes] Rejecting write-off', { writeoffId, rejectedBy })

      try {
        const writeOff = await writeOffService.rejectWriteOff(writeoffId, rejectedBy, rejectionReason)

        res.json({
          success: true,
          data: writeOff,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to reject write-off:', error.message)
        throw {
          statusCode: 400,
          code: 'WRITEOFF_REJECT_FAILED',
          message: error.message || 'Failed to reject write-off',
        }
      }
    })
  )

  /**
   * POST /api/writeoffs/:writeoffId/reverse
   * Reverse a previously approved write-off.
   */
  router.post(
    '/writeoffs/:writeoffId/reverse',
    [
      param('writeoffId')
        .trim()
        .isUUID()
        .withMessage('writeoffId must be a valid UUID'),
      body('reversalReason')
        .trim()
        .notEmpty()
        .withMessage('reversalReason is required'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { writeoffId } = req.params
      const { reversalReason } = req.body

      console.log('[PaymentRoutes] Reversing write-off', { writeoffId, reversalReason })

      try {
        const writeOff = await writeOffService.reverseWriteOff(writeoffId, reversalReason)

        res.json({
          success: true,
          data: writeOff,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to reverse write-off:', error.message)
        throw {
          statusCode: 400,
          code: 'WRITEOFF_REVERSE_FAILED',
          message: error.message || 'Failed to reverse write-off',
        }
      }
    })
  )

  /**
   * POST /api/writeoffs/batch/small-balance
   * Batch write-off small balances below threshold.
   */
  router.post(
    '/writeoffs/batch/small-balance',
    [
      body('threshold')
        .isInt({ min: 1 })
        .withMessage('threshold must be a positive integer (in cents)'),
      body('practiceId')
        .trim()
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { threshold, practiceId } = req.body

      console.log('[PaymentRoutes] Batch write-off small balances', { threshold, practiceId })

      try {
        const result = await writeOffService.batchWriteOffSmallBalances(threshold, practiceId)

        res.json({
          success: true,
          data: result,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to batch write-off:', error.message)
        throw {
          statusCode: 500,
          code: 'BATCH_WRITEOFF_FAILED',
          message: error.message || 'Failed to batch write-off small balances',
        }
      }
    })
  )

  /**
   * GET /api/writeoffs/summary
   * Get write-off summary report.
   */
  router.get(
    '/writeoffs/summary',
    [
      query('practiceId')
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      query('from')
        .optional()
        .isISO8601()
        .withMessage('from must be a valid ISO 8601 date'),
      query('to')
        .optional()
        .isISO8601()
        .withMessage('to must be a valid ISO 8601 date'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { practiceId, from, to } = req.query

      console.log('[PaymentRoutes] Getting write-off summary', { practiceId, from, to })

      try {
        const summary = await writeOffService.getSummary(
          practiceId as string,
          from as string | undefined,
          to as string | undefined
        )

        res.json({
          success: true,
          data: summary,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get summary:', error.message)
        throw {
          statusCode: 500,
          code: 'SUMMARY_FETCH_FAILED',
          message: 'Failed to fetch write-off summary',
        }
      }
    })
  )

  // ========================================================================
  // COMMUNICATION ENDPOINTS
  // ========================================================================

  /**
   * GET /api/communications/patient/:patientId
   * Get all communications for a patient.
   */
  router.get(
    '/communications/patient/:patientId',
    [
      param('patientId')
        .trim()
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      query('type')
        .optional()
        .isIn(['sms', 'email'])
        .withMessage('type must be "sms" or "email"'),
      query('purpose')
        .optional()
        .isIn(['payment_reminder', 'payment_receipt', 'payment_link', 'statement', 'collection_notice'])
        .withMessage('purpose must be a valid communication purpose'),
      query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('limit must be between 1 and 100'),
      query('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('offset must be a non-negative integer'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId } = req.params
      const { type, purpose, limit: limitParam, offset: offsetParam } = req.query
      const limit = Math.min(parseInt(limitParam as string) || 20, 100)
      const offset = parseInt(offsetParam as string) || 0

      console.log('[PaymentRoutes] Getting communications', { patientId, type, purpose })

      try {
        const communications = await communicationService.getPatientCommunications(
          patientId,
          type as string | undefined,
          purpose as string | undefined,
          limit,
          offset
        )

        res.json({
          success: true,
          data: {
            communications,
            pagination: {
              limit,
              offset,
              count: communications.length,
            },
          },
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get communications:', error.message)
        throw {
          statusCode: 500,
          code: 'COMMUNICATIONS_FETCH_FAILED',
          message: 'Failed to fetch communications',
        }
      }
    })
  )

  /**
   * GET /api/communications/stats
   * Get delivery statistics.
   */
  router.get(
    '/communications/stats',
    [
      query('practiceId')
        .notEmpty()
        .withMessage('practiceId is required')
        .isUUID()
        .withMessage('practiceId must be a valid UUID'),
      query('from')
        .optional()
        .isISO8601()
        .withMessage('from must be a valid ISO 8601 date'),
      query('to')
        .optional()
        .isISO8601()
        .withMessage('to must be a valid ISO 8601 date'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { practiceId, from, to } = req.query

      console.log('[PaymentRoutes] Getting communication stats', { practiceId, from, to })

      try {
        const stats = await communicationService.getDeliveryStats(
          practiceId as string,
          from as string | undefined,
          to as string | undefined
        )

        res.json({
          success: true,
          data: stats,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get stats:', error.message)
        throw {
          statusCode: 500,
          code: 'STATS_FETCH_FAILED',
          message: 'Failed to fetch delivery statistics',
        }
      }
    })
  )

  // ========================================================================
  // WEBHOOK ENDPOINTS (NO AUTH)
  // ========================================================================

  /**
   * POST /api/payments/webhook
   * Stripe webhook endpoint for payment events.
   * Does NOT use auth middleware - signature verification instead.
   */
  router.post(
    '/webhook',
    asyncHandler(async (req: Request, res: Response) => {
      const signature = req.headers['stripe-signature'] as string

      if (!signature) {
        console.error('[PaymentRoutes] Webhook missing signature')
        return res.status(401).json({
          error: 'Unauthorized',
          code: 'WEBHOOK_SIGNATURE_MISSING',
        })
      }

      console.log('[PaymentRoutes] Processing Stripe webhook')

      try {
        // Verify signature and parse event
        const event = await stripeConnect.parseWebhookEvent(
          JSON.stringify(req.body),
          signature
        )

        // Handle different event types
        switch (event.type) {
          case 'charge.succeeded':
            console.log('[PaymentRoutes] Processing charge.succeeded event', { chargeId: event.data.object.id })
            // Update payment transaction status to succeeded
            // Trigger payment receipt communication
            // Update patient balance
            break

          case 'charge.failed':
            console.log('[PaymentRoutes] Processing charge.failed event', { chargeId: event.data.object.id })
            // Update payment transaction status to failed
            // Store failure reason
            break

          case 'charge.refunded':
            console.log('[PaymentRoutes] Processing charge.refunded event', { chargeId: event.data.object.id })
            // Update transaction refund status
            break

          case 'charge.dispute.created':
            console.log('[PaymentRoutes] Processing charge.dispute.created event')
            // Mark transaction as disputed
            // Trigger escalation
            break

          default:
            console.log('[PaymentRoutes] Webhook event not handled', { type: event.type })
        }

        // Acknowledge receipt
        res.status(200).json({ received: true })
      } catch (error: any) {
        console.error('[PaymentRoutes] Webhook processing failed:', error.message)
        // Still return 200 to prevent Stripe retry
        res.status(200).json({ error: error.message })
      }
    })
  )

  /**
   * POST /api/communications/webhook/twilio
   * Twilio SMS delivery status callback.
   * No auth - Twilio signature verification instead.
   */
  router.post(
    '/communications/webhook/twilio',
    asyncHandler(async (req: Request, res: Response) => {
      console.log('[PaymentRoutes] Processing Twilio webhook', { messageId: req.body.MessageSid })

      try {
        // Update communication status in database
        // Map Twilio status codes to our status enum
        const statusMap: Record<string, string> = {
          'queued': 'queued',
          'sending': 'queued',
          'sent': 'sent',
          'delivered': 'delivered',
          'failed': 'failed',
          'undelivered': 'failed',
        }

        const status = statusMap[req.body.MessageStatus] || 'queued'

        // TODO: Update communication record with externalId and status
        // const result = await pool.query(
        //   `UPDATE communications SET status = $1, external_id = $2, updated_at = NOW()
        //    WHERE external_id = $3`,
        //   [status, req.body.MessageSid, req.body.MessageSid]
        // )

        res.status(200).send('OK')
      } catch (error: any) {
        console.error('[PaymentRoutes] Twilio webhook failed:', error.message)
        res.status(200).send('OK')
      }
    })
  )

  /**
   * POST /api/communications/webhook/sendgrid
   * SendGrid email delivery status callback.
   * No auth - SendGrid signature verification instead.
   */
  router.post(
    '/communications/webhook/sendgrid',
    asyncHandler(async (req: Request, res: Response) => {
      console.log('[PaymentRoutes] Processing SendGrid webhook batch')

      try {
        // SendGrid sends array of events
        const events = Array.isArray(req.body) ? req.body : [req.body]

        for (const event of events) {
          console.log('[PaymentRoutes] SendGrid event', { type: event.event, messageId: event.message_id })

          const statusMap: Record<string, string> = {
            'bounce': 'bounced',
            'click': 'clicked',
            'open': 'opened',
            'delivered': 'delivered',
            'dropped': 'failed',
          }

          const status = statusMap[event.event] || undefined

          if (status) {
            // TODO: Update communication record
            // await pool.query(
            //   `UPDATE communications SET status = $1, external_id = $2, updated_at = NOW()
            //    WHERE external_id = $3`,
            //   [status, event.message_id, event.message_id]
            // )
          }
        }

        res.status(200).send('OK')
      } catch (error: any) {
        console.error('[PaymentRoutes] SendGrid webhook failed:', error.message)
        res.status(200).send('OK')
      }
    })
  )

  // ========================================================================
  // PATIENT BALANCE ENDPOINTS
  // ========================================================================

  /**
   * GET /api/balances/patient/:patientId
   * Get patient's current balance breakdown.
   */
  router.get(
    '/balances/patient/:patientId',
    [
      param('patientId')
        .trim()
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId } = req.params
      const practiceId = req.headers['x-practice-id'] as string

      if (!practiceId) {
        return res.status(400).json({
          error: 'Missing practice context',
          code: 'PRACTICE_CONTEXT_MISSING',
        })
      }

      console.log('[PaymentRoutes] Getting patient balance', { patientId, practiceId })

      try {
        const result = await pool.query(
          `SELECT * FROM patient_balances WHERE patient_id = $1 AND practice_id = $2`,
          [patientId, practiceId]
        )

        const balance = result.rows[0] || {
          patientId,
          practiceId,
          totalOutstanding: 0,
          insurancePending: 0,
          patientResponsibility: 0,
          totalPaid: 0,
          totalWrittenOff: 0,
          netBalance: 0,
          isInCollections: false,
          balanceAge: 0,
        }

        res.json({
          success: true,
          data: balance,
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get balance:', error.message)
        throw {
          statusCode: 500,
          code: 'BALANCE_FETCH_FAILED',
          message: 'Failed to fetch patient balance',
        }
      }
    })
  )

  /**
   * GET /api/balances/patient/:patientId/ledger
   * Get patient's account ledger with transaction history.
   */
  router.get(
    '/balances/patient/:patientId/ledger',
    [
      param('patientId')
        .trim()
        .isUUID()
        .withMessage('patientId must be a valid UUID'),
      query('limit')
        .optional()
        .isInt({ min: 1, max: 100 })
        .withMessage('limit must be between 1 and 100'),
      query('offset')
        .optional()
        .isInt({ min: 0 })
        .withMessage('offset must be a non-negative integer'),
    ],
    handleValidationErrors,
    asyncHandler(async (req: Request, res: Response) => {
      const { patientId } = req.params
      const practiceId = req.headers['x-practice-id'] as string
      const limit = Math.min(parseInt(req.query.limit as string) || 20, 100)
      const offset = parseInt(req.query.offset as string) || 0

      if (!practiceId) {
        return res.status(400).json({
          error: 'Missing practice context',
          code: 'PRACTICE_CONTEXT_MISSING',
        })
      }

      console.log('[PaymentRoutes] Getting patient ledger', { patientId, practiceId })

      try {
        const countResult = await pool.query(
          `SELECT COUNT(*) FROM patient_ledger WHERE patient_id = $1 AND practice_id = $2`,
          [patientId, practiceId]
        )

        const ledgerResult = await pool.query(
          `SELECT * FROM patient_ledger
           WHERE patient_id = $1 AND practice_id = $2
           ORDER BY created_at DESC
           LIMIT $3 OFFSET $4`,
          [patientId, practiceId, limit, offset]
        )

        const entries = ledgerResult.rows.map((row: any) => ({
          id: row.id,
          patientId: row.patient_id,
          practiceId: row.practice_id,
          type: row.type,
          amount: row.amount,
          description: row.description,
          referenceId: row.reference_id,
          balanceAfter: row.balance_after,
          createdAt: row.created_at,
          createdBy: row.created_by,
        }))

        res.json({
          success: true,
          data: {
            entries,
            pagination: {
              limit,
              offset,
              total: parseInt(countResult.rows[0].count),
              hasMore: offset + limit < parseInt(countResult.rows[0].count),
            },
          },
        })
      } catch (error: any) {
        console.error('[PaymentRoutes] Failed to get ledger:', error.message)
        throw {
          statusCode: 500,
          code: 'LEDGER_FETCH_FAILED',
          message: 'Failed to fetch patient ledger',
        }
      }
    })
  )

  // ========================================================================
  // ERROR HANDLER (MUST BE LAST)
  // ========================================================================
  router.use(errorHandler)

  return router
}

/**
 * Export types for consumers of this module
 */
export type {
  StripeConnectService,
  CommunicationService,
  ReminderEngine,
  WriteOffService,
}
