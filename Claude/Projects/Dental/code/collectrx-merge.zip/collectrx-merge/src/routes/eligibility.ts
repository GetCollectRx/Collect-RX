/**
 * CollectRx Eligibility API Routes
 *
 * Express router providing REST endpoints for:
 * - Patient eligibility estimation (GET/POST)
 * - Eligibility status checks
 * - Claim reconciliation
 * - Estimate history and lookup
 *
 * All endpoints include bearer token auth and input validation.
 * Database operations use parameterized queries to prevent SQL injection.
 */

import { Router, Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';
import {
  EstimateRequest,
  EstimateResult,
  EligibilityStatusResponse,
  ActualClaimPayment,
  ReconcileRequest,
  CarrierCode,
  Patient,
  Plan,
  EligibilitySnapshot,
  ProcedureInput,
} from '../services/eligibility/types';
import { EligibilityEngine } from '../services/eligibility/engine';
import { ReconciliationEngine, ReconciliationSummary, generateReconciliationSummary } from '../services/eligibility/reconciliation';

// ============================================================================
// === TYPES ===
// ============================================================================

interface AuthRequest extends Request {
  userId?: string;
  practiceId?: string;
}

interface PaginationQuery {
  limit?: string;
  offset?: string;
}

interface EstimateQueryParams extends PaginationQuery {
  carrier?: string;
}

interface StatusQueryParams {
  planId?: string;
}

interface EstimateRequestBody {
  patient: Patient;
  plan: Plan;
  procedures: ProcedureInput[];
  secondaryPlan?: Plan;
  eligibility?: EligibilitySnapshot;
  secondaryEligibility?: EligibilitySnapshot;
  notes?: string;
}

interface ReconcileRequestBody {
  estimateId: string;
  actualPayments: ActualClaimPayment[];
  notes?: string;
}

// ============================================================================
// === MIDDLEWARE ===
// ============================================================================

/**
 * Bearer token authentication middleware.
 * Extracts and validates bearer token from Authorization header.
 * Sets userId and practiceId on request for downstream handlers.
 */
function authMiddleware(req: AuthRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing or invalid Authorization header' });
    return;
  }

  const token = authHeader.slice(7);

  // TODO: Implement actual JWT verification
  // For now, validate token format (placeholder)
  if (!token || token.length < 10) {
    res.status(401).json({ error: 'Invalid token format' });
    return;
  }

  // TODO: Extract userId and practiceId from JWT claims
  req.userId = 'user_placeholder';
  req.practiceId = 'practice_placeholder';

  next();
}

/**
 * Input validation middleware for estimate requests.
 * Validates required fields and data types.
 */
function validateEstimateRequest(req: AuthRequest, res: Response, next: NextFunction): void {
  const body = req.body as EstimateRequestBody;

  // Validate patient
  if (!body.patient || !body.patient.id || !body.patient.firstName || !body.patient.lastName) {
    res.status(400).json({ error: 'Invalid patient: missing required fields (id, firstName, lastName)' });
    return;
  }

  // Validate plan
  if (!body.plan || !body.plan.id || !body.plan.carrierCode) {
    res.status(400).json({ error: 'Invalid plan: missing required fields (id, carrierCode)' });
    return;
  }

  // Validate carrier code
  const validCarriers: CarrierCode[] = [
    'sunlife_private',
    'great_west',
    'manulife',
    'green_shield',
    'rbc_insurance',
    'telus_adjudicare',
  ];
  if (!validCarriers.includes(body.plan.carrierCode as CarrierCode)) {
    res.status(400).json({
      error: `Invalid carrier code: ${body.plan.carrierCode}. Valid carriers: ${validCarriers.join(', ')}`,
    });
    return;
  }

  // Validate procedures
  if (!body.procedures || !Array.isArray(body.procedures) || body.procedures.length === 0) {
    res.status(400).json({ error: 'Invalid procedures: array must contain at least one procedure' });
    return;
  }

  for (const proc of body.procedures) {
    if (!proc.cdtCode || !proc.providerFee || !proc.quantity || !proc.dateOfService) {
      res.status(400).json({
        error: 'Invalid procedure: missing required fields (cdtCode, providerFee, quantity, dateOfService)',
      });
      return;
    }

    // Validate CDT code format (should be D followed by 4 digits)
    if (!/^D\d{4}$/.test(proc.cdtCode)) {
      res.status(400).json({ error: `Invalid CDT code format: ${proc.cdtCode}. Expected D followed by 4 digits.` });
      return;
    }

    if (proc.providerFee <= 0 || proc.quantity <= 0) {
      res.status(400).json({ error: 'Provider fee and quantity must be positive numbers' });
      return;
    }
  }

  next();
}

/**
 * Request logging middleware.
 */
function logRequest(req: AuthRequest, res: Response, next: NextFunction): void {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path} - User: ${req.userId}`);
  next();
}

/**
 * Error handling middleware.
 */
function errorHandler(err: Error, req: AuthRequest, res: Response, next: NextFunction): void {
  const timestamp = new Date().toISOString();
  console.error(`[${timestamp}] Error: ${err.message}`);

  if (res.headersSent) {
    return next(err);
  }

  res.status(500).json({
    error: 'Internal server error',
    message: err.message,
  });
}

// ============================================================================
// === FACTORY FUNCTION ===
// ============================================================================

/**
 * Create eligibility router with injected database pool.
 *
 * @param pool - PostgreSQL connection pool
 * @returns Express Router with all eligibility endpoints
 */
export function createEligibilityRouter(pool: Pool): Router {
  const router = Router();
  const engine = new EligibilityEngine();

  // Apply middleware
  router.use(logRequest);
  router.use(authMiddleware);

  // ========================================================================
  // === POST /api/eligibility/estimate ===
  // ========================================================================
  // Generate and persist an estimate for a patient's treatment plan.
  //
  // @request EstimateRequest with patient, plan, procedures
  // @response EstimateResult with 200
  // @error 400 validation error, 500 engine error
  router.post('/estimate', validateEstimateRequest, async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const body = req.body as EstimateRequestBody;

      // Create EstimateRequest object
      const estimateRequest: EstimateRequest = {
        patient: body.patient,
        plan: body.plan,
        procedures: body.procedures,
        secondaryPlan: body.secondaryPlan,
        eligibility: body.eligibility,
        secondaryEligibility: body.secondaryEligibility,
        notes: body.notes,
      };

      // Calculate estimate using engine
      const result = engine.calculateEstimate(estimateRequest);

      // Persist to database
      const query = `
        INSERT INTO estimates (
          id, patient_id, plan_id, carrier_code, request_data, result_data,
          confidence_score, confidence_level, total_provider_fees,
          total_insurance_portion, total_patient_portion, created_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *;
      `;

      const values = [
        result.id,
        result.patientId,
        result.planId,
        result.carrierCode,
        JSON.stringify(estimateRequest),
        JSON.stringify(result),
        result.confidence.score,
        result.confidence.level,
        result.summary.totalProviderFees,
        result.summary.totalInsurancePortion,
        result.summary.totalPatientPortion,
        req.userId,
      ];

      await pool.query(query, values);

      res.status(200).json(result);
    } catch (error) {
      const err = error as Error;
      console.error('Error calculating estimate:', err.message);
      res.status(500).json({ error: 'Failed to calculate estimate', message: err.message });
    }
  });

  // ========================================================================
  // === GET /api/eligibility/estimate/:estimateId ===
  // ========================================================================
  // Retrieve a specific estimate from database.
  //
  // @param estimateId - UUID of the estimate
  // @response EstimateResult with 200
  // @error 404 estimate not found
  router.get('/estimate/:estimateId', async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const { estimateId } = req.params;

      const query = 'SELECT result_data FROM estimates WHERE id = $1;';
      const result = await pool.query(query, [estimateId]);

      if (result.rows.length === 0) {
        res.status(404).json({ error: 'Estimate not found' });
        return;
      }

      const estimate = result.rows[0].result_data as EstimateResult;
      res.status(200).json(estimate);
    } catch (error) {
      const err = error as Error;
      console.error('Error retrieving estimate:', err.message);
      res.status(500).json({ error: 'Failed to retrieve estimate', message: err.message });
    }
  });

  // ========================================================================
  // === GET /api/eligibility/status/:patientId ===
  // ========================================================================
  // Check a patient's current eligibility status for a plan.
  //
  // @param patientId - Patient UUID
  // @query planId (optional) - Specific plan UUID
  // @response EligibilityStatusResponse with 200
  // @error 404 patient or plan not found
  router.get('/status/:patientId', async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const { patientId } = req.params;
      const { planId } = req.query as StatusQueryParams;

      // Load eligibility snapshot (latest active one)
      let query = `
        SELECT es.*, p.carrier_code, p.plan_name
        FROM eligibility_snapshots es
        JOIN plans p ON es.plan_id = p.id
        WHERE es.patient_id = $1 AND es.is_active = true
      `;

      const params: any[] = [patientId];

      if (planId) {
        query += ' AND es.plan_id = $2';
        params.push(planId);
      }

      query += ' ORDER BY es.captured_at DESC LIMIT 1;';

      const result = await pool.query(query, params);

      if (result.rows.length === 0) {
        res.status(404).json({ error: 'No active eligibility found for patient' });
        return;
      }

      const snapshot = result.rows[0];

      // Load carrier config to get plan name
      const configQuery = 'SELECT config_data FROM carrier_plan_configs WHERE carrier_code = $1;';
      const configResult = await pool.query(configQuery, [snapshot.carrier_code]);

      const carrierName = configResult.rows.length > 0 ? configResult.rows[0].config_data.name : snapshot.carrier_code;

      // Build response
      const response: EligibilityStatusResponse = {
        isActive: snapshot.is_active,
        effectiveDate: snapshot.effective_date,
        terminationDate: snapshot.termination_date,
        deductibleRemaining: {
          individual: 500 - (snapshot.deductible_used_individual || 0),
          family: 1000 - (snapshot.deductible_used_family || 0),
        },
        annualMaxRemaining: 1500 - (snapshot.annual_max_used_individual || 0),
        carrierName,
        planName: snapshot.plan_name,
        lastVerified: snapshot.last_verified_date,
        usedThisYear: {
          deductible: snapshot.deductible_used_individual || 0,
          annualMax: snapshot.annual_max_used_individual || 0,
        },
        notes: snapshot.claims_history?.length > 0 ? `${snapshot.claims_history.length} claims this year` : undefined,
      };

      res.status(200).json(response);
    } catch (error) {
      const err = error as Error;
      console.error('Error retrieving eligibility status:', err.message);
      res.status(500).json({ error: 'Failed to retrieve eligibility status', message: err.message });
    }
  });

  // ========================================================================
  // === POST /api/eligibility/reconcile ===
  // ========================================================================
  // Reconcile actual insurance payments against estimate.
  //
  // @body { estimateId, actualPayments }
  // @response { results: ReconciliationResult[], summary: ReconciliationSummary }
  router.post('/reconcile', async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const body = req.body as ReconcileRequestBody;

      if (!body.estimateId || !body.actualPayments || !Array.isArray(body.actualPayments)) {
        res.status(400).json({ error: 'Invalid request: estimateId and actualPayments array required' });
        return;
      }

      // Load original estimate
      const estimateQuery = 'SELECT result_data FROM estimates WHERE id = $1;';
      const estimateResult = await pool.query(estimateQuery, [body.estimateId]);

      if (estimateResult.rows.length === 0) {
        res.status(404).json({ error: 'Estimate not found' });
        return;
      }

      const estimate = estimateResult.rows[0].result_data as EstimateResult;

      // Perform reconciliation
      const reconciliationEngine = new ReconciliationEngine();
      const results = reconciliationEngine.reconcile(estimate, body.actualPayments);

      // Generate summary
      const summary = generateReconciliationSummary(results);

      // Persist reconciliation results
      const insertQuery = `
        INSERT INTO reconciliations (
          id, estimate_id, patient_id, carrier_code, results_data, summary_data,
          total_estimated, total_actual_paid, total_variance, variance_percentage,
          total_patient_balance_change, total_write_offs, reconciled_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        RETURNING *;
      `;

      const reconciliationId = uuidv4();
      const insertValues = [
        reconciliationId,
        body.estimateId,
        estimate.patientId,
        estimate.carrierCode,
        JSON.stringify(results),
        JSON.stringify(summary),
        summary.totalEstimated,
        summary.totalActualPaid,
        summary.totalVariance,
        summary.variancePercentage,
        summary.totalPatientBalanceChange,
        summary.totalWriteOffs,
        req.userId,
      ];

      await pool.query(insertQuery, insertValues);

      res.status(200).json({
        results,
        summary,
      });
    } catch (error) {
      const err = error as Error;
      console.error('Error reconciling estimate:', err.message);
      res.status(500).json({ error: 'Failed to reconcile estimate', message: err.message });
    }
  });

  // ========================================================================
  // === GET /api/eligibility/reconciliation/:estimateId ===
  // ========================================================================
  // Retrieve reconciliation results for a specific estimate.
  //
  // @param estimateId - UUID of the estimate
  // @response { results: ReconciliationResult[], summary: ReconciliationSummary }
  router.get('/reconciliation/:estimateId', async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const { estimateId } = req.params;

      const query = 'SELECT results_data, summary_data FROM reconciliations WHERE estimate_id = $1;';
      const result = await pool.query(query, [estimateId]);

      if (result.rows.length === 0) {
        res.status(404).json({ error: 'Reconciliation not found for estimate' });
        return;
      }

      const reconciliation = result.rows[0];
      res.status(200).json({
        results: reconciliation.results_data,
        summary: reconciliation.summary_data,
      });
    } catch (error) {
      const err = error as Error;
      console.error('Error retrieving reconciliation:', err.message);
      res.status(500).json({ error: 'Failed to retrieve reconciliation', message: err.message });
    }
  });

  // ========================================================================
  // === GET /api/eligibility/patient/:patientId/estimates ===
  // ========================================================================
  // Get paginated list of all estimates for a patient.
  //
  // @param patientId - Patient UUID
  // @query limit - Results per page (default 20, max 100)
  // @query offset - Pagination offset (default 0)
  // @query carrier - Filter by carrier code (optional)
  // @response EstimateResult[] with pagination metadata
  router.get('/patient/:patientId/estimates', async (req: AuthRequest, res: Response, next: NextFunction) => {
    try {
      const { patientId } = req.params;
      const { limit = '20', offset = '0', carrier } = req.query as EstimateQueryParams;

      const pageLimit = Math.min(Math.max(1, parseInt(limit, 10) || 20), 100);
      const pageOffset = Math.max(0, parseInt(offset, 10) || 0);

      // Build query with optional carrier filter
      let query = 'SELECT result_data FROM estimates WHERE patient_id = $1';
      const params: any[] = [patientId];

      if (carrier) {
        query += ' AND carrier_code = $2';
        params.push(carrier);
        query += ` ORDER BY created_at DESC LIMIT $3 OFFSET $4;`;
        params.push(pageLimit, pageOffset);
      } else {
        query += ` ORDER BY created_at DESC LIMIT $2 OFFSET $3;`;
        params.push(pageLimit, pageOffset);
      }

      const result = await pool.query(query, params);

      // Get total count for pagination
      let countQuery = 'SELECT COUNT(*) as total FROM estimates WHERE patient_id = $1';
      const countParams: any[] = [patientId];

      if (carrier) {
        countQuery += ' AND carrier_code = $2;';
        countParams.push(carrier);
      } else {
        countQuery += ';';
      }

      const countResult = await pool.query(countQuery, countParams);
      const total = parseInt(countResult.rows[0].total, 10);

      const estimates = result.rows.map((row) => row.result_data);

      res.status(200).json({
        data: estimates,
        pagination: {
          total,
          limit: pageLimit,
          offset: pageOffset,
          hasMore: pageOffset + pageLimit < total,
        },
      });
    } catch (error) {
      const err = error as Error;
      console.error('Error retrieving estimates:', err.message);
      res.status(500).json({ error: 'Failed to retrieve estimates', message: err.message });
    }
  });

  // Apply error handler
  router.use(errorHandler);

  return router;
}

export default createEligibilityRouter;
