import express from 'express';
import priorityRouter, { setPgPool } from './priority.js';
import logger from '../utils/logger.js';

const router = express.Router();

/**
 * API Route Index for CollectRx Backend
 *
 * This file mounts all API route handlers and documents the complete
 * API surface for the CollectRx desktop application running on Railway.
 *
 * Base URL: /api
 */

/**
 * Initialize routes with database connection
 * Call this function before mounting routes
 */
export function initializeRoutes(pgPool) {
  setPgPool(pgPool);
  logger.info('Routes initialized with database pool');
}

/**
 * Health check endpoint
 * GET /api/health
 * Returns: { status: "ok", timestamp: ISO8601 }
 */
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

/**
 * CARRIER QUEUE PRIORITY ROUTES
 * Prefix: /api/queue/priority
 *
 * POST /api/queue/priority
 *   Update carrier call priority order
 *   Auth: Bearer token
 *   Body: { priorities: [{ carrier_code, priority, enabled, carrier_name? }] }
 *   Returns: { success: true, priorities: [...] }
 *
 * GET /api/queue/priority
 *   Get current priority order
 *   Auth: Bearer token
 *   Returns: { priorities: [{ id, carrier_code, carrier_name, priority, enabled, updated_at }] }
 *
 * GET /api/queue/priority/:carrier_code
 *   Get priority for specific carrier
 *   Auth: Bearer token
 *   Returns: { priority: { id, carrier_code, carrier_name, priority, enabled, updated_at } }
 */
router.use('/queue/priority', priorityRouter);

/**
 * QUEUE MANAGEMENT ROUTES (Future)
 * Prefix: /api/queue
 * - GET /api/queue/stats — queue statistics
 * - POST /api/queue/run — trigger claim calls
 * - POST /api/queue/pause/:claim_id — pause a claim
 * - POST /api/queue/unpause/:claim_id — resume a claim
 */

/**
 * CLAIMS ROUTES (Future)
 * Prefix: /api/claims
 * - GET /api/claims — list claims with filters
 * - GET /api/claims/:claim_id — get claim details
 * - POST /api/claims/:claim_id/notes — add claim notes
 * - GET /api/claims/aging-report — aging bucket report
 */

/**
 * PRACTICE ROUTES (Future)
 * Prefix: /api/practices
 * - GET /api/practices — list connected practices
 * - GET /api/practices/:practice_id — get practice details
 * - PATCH /api/practices/:practice_id — update practice settings
 * - GET /api/practices/:practice_id/queue — practice queue stats
 */

/**
 * SYNC ROUTES (Future)
 * Prefix: /api/sync
 * - GET /api/sync/status — get current sync status
 * - POST /api/sync/trigger — manually trigger sync
 * - GET /api/sync/logs — get sync logs
 */

/**
 * ERROR HANDLING MIDDLEWARE
 */
router.use((err, req, res, next) => {
  logger.error('Unhandled route error', {
    method: req.method,
    path: req.path,
    error: err.message,
    stack: err.stack
  });

  // Don't expose internal error details in production
  const isDevelopment = process.env.NODE_ENV === 'development';

  res.status(err.status || 500).json({
    error: isDevelopment ? err.message : 'Internal server error'
  });
});

/**
 * 404 HANDLER
 */
router.use((req, res) => {
  logger.warn('Route not found', {
    method: req.method,
    path: req.path
  });

  res.status(404).json({
    error: `Route not found: ${req.method} ${req.path}`
  });
});

export default router;
