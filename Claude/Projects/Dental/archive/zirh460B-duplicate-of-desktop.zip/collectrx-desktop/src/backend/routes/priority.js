import express from 'express';
import { Pool } from 'pg';
import logger from '../utils/logger.js';

const router = express.Router();

// PostgreSQL pool should be injected from main server
let pool = null;

export function setPgPool(pgPool) {
  pool = pgPool;
}

/**
 * PostgreSQL Migration: carrier_priorities table schema
 *
 * CREATE TABLE IF NOT EXISTS carrier_priorities (
 *   id SERIAL PRIMARY KEY,
 *   carrier_code VARCHAR(50) UNIQUE NOT NULL,
 *   carrier_name VARCHAR(255) NOT NULL,
 *   priority INTEGER NOT NULL DEFAULT 999,
 *   enabled BOOLEAN NOT NULL DEFAULT true,
 *   created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 *   updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
 * );
 *
 * CREATE INDEX idx_carrier_priority ON carrier_priorities(priority, enabled);
 */

// Valid carrier codes (from CollectRx supported carriers)
const VALID_CARRIERS = [
  'sunlife_private',
  'sunlife_group',
  'manulife',
  'great_west',
  'iapd',
  'blue_cross',
  'canada_life',
  'other'
];

/**
 * Middleware: Authentication check (Bearer token)
 */
function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    logger.warn('Missing or invalid Authorization header');
    return res.status(401).json({ error: 'Unauthorized - missing Bearer token' });
  }

  // TODO: Validate token against your auth system
  // For now, just check if token exists
  const token = authHeader.slice(7);
  if (!token) {
    return res.status(401).json({ error: 'Unauthorized - invalid token' });
  }

  next();
}

/**
 * POST /api/queue/priority
 * Update carrier call priority order
 *
 * Body: {
 *   priorities: [
 *     { carrier_code: string, priority: number, enabled: boolean },
 *     ...
 *   ]
 * }
 */
router.post('/', authMiddleware, async (req, res) => {
  try {
    if (!pool) {
      logger.error('PostgreSQL pool not initialized');
      return res.status(500).json({ error: 'Database connection not ready' });
    }

    const { priorities } = req.body;

    // Validate input
    if (!Array.isArray(priorities)) {
      return res.status(400).json({ error: 'priorities must be an array' });
    }

    if (priorities.length === 0) {
      return res.status(400).json({ error: 'priorities array cannot be empty' });
    }

    // Validate each priority entry
    for (const item of priorities) {
      if (!item.carrier_code || typeof item.carrier_code !== 'string') {
        return res.status(400).json({ error: 'Each priority must have a valid carrier_code' });
      }

      if (!VALID_CARRIERS.includes(item.carrier_code)) {
        return res.status(400).json({
          error: `Invalid carrier_code: ${item.carrier_code}. Valid codes: ${VALID_CARRIERS.join(', ')}`
        });
      }

      if (typeof item.priority !== 'number' || item.priority < 0 || item.priority > 999) {
        return res.status(400).json({ error: 'priority must be a number between 0 and 999' });
      }

      if (typeof item.enabled !== 'boolean') {
        return res.status(400).json({ error: 'enabled must be a boolean' });
      }
    }

    // Upsert each priority into the database
    const upsertedPriorities = [];

    for (const item of priorities) {
      const query = `
        INSERT INTO carrier_priorities (carrier_code, carrier_name, priority, enabled, updated_at)
        VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
        ON CONFLICT (carrier_code) DO UPDATE SET
          priority = $3,
          enabled = $4,
          updated_at = CURRENT_TIMESTAMP
        RETURNING id, carrier_code, carrier_name, priority, enabled, updated_at;
      `;

      const result = await pool.query(query, [
        item.carrier_code,
        item.carrier_name || item.carrier_code, // Use provided name or default to code
        item.priority,
        item.enabled
      ]);

      upsertedPriorities.push(result.rows[0]);
    }

    logger.info('Carrier priorities updated', { count: upsertedPriorities.length });

    res.status(200).json({
      success: true,
      priorities: upsertedPriorities
    });
  } catch (error) {
    logger.error('Error updating carrier priorities', {
      error: error.message,
      stack: error.stack
    });

    if (error.code === '23505') {
      // Unique constraint violation
      return res.status(409).json({ error: 'Duplicate carrier_code in request' });
    }

    res.status(500).json({ error: 'Failed to update carrier priorities' });
  }
});

/**
 * GET /api/queue/priority
 * Get current priority order
 *
 * Response: {
 *   priorities: [
 *     { id, carrier_code, carrier_name, priority, enabled, updated_at },
 *     ...
 *   ]
 * }
 */
router.get('/', authMiddleware, async (req, res) => {
  try {
    if (!pool) {
      logger.error('PostgreSQL pool not initialized');
      return res.status(500).json({ error: 'Database connection not ready' });
    }

    const query = `
      SELECT id, carrier_code, carrier_name, priority, enabled, updated_at
      FROM carrier_priorities
      WHERE enabled = true
      ORDER BY priority ASC, carrier_code ASC;
    `;

    const result = await pool.query(query);

    logger.info('Fetched carrier priorities', { count: result.rows.length });

    res.status(200).json({
      priorities: result.rows
    });
  } catch (error) {
    logger.error('Error fetching carrier priorities', {
      error: error.message,
      stack: error.stack
    });

    res.status(500).json({ error: 'Failed to fetch carrier priorities' });
  }
});

/**
 * GET /api/queue/priority/:carrier_code
 * Get priority for a specific carrier
 */
router.get('/:carrier_code', authMiddleware, async (req, res) => {
  try {
    if (!pool) {
      logger.error('PostgreSQL pool not initialized');
      return res.status(500).json({ error: 'Database connection not ready' });
    }

    const { carrier_code } = req.params;

    if (!VALID_CARRIERS.includes(carrier_code)) {
      return res.status(400).json({ error: `Invalid carrier_code: ${carrier_code}` });
    }

    const query = `
      SELECT id, carrier_code, carrier_name, priority, enabled, updated_at
      FROM carrier_priorities
      WHERE carrier_code = $1;
    `;

    const result = await pool.query(query, [carrier_code]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: `Carrier not found: ${carrier_code}` });
    }

    res.status(200).json({
      priority: result.rows[0]
    });
  } catch (error) {
    logger.error('Error fetching carrier priority', {
      error: error.message,
      carrier_code: req.params.carrier_code
    });

    res.status(500).json({ error: 'Failed to fetch carrier priority' });
  }
});

export default router;
