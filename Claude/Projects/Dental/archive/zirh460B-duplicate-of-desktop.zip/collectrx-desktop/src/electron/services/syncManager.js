const { ipcMain } = require('electron');
const log = require('electron-log');
const EventEmitter = require('events');

/**
 * SyncManager
 * Manages Abeldent sync lifecycle from within Electron main process
 * - Start/stop sync on demand
 * - Periodic sync with configurable interval
 * - Status tracking (idle, syncing, error, last_sync_time)
 * - IPC communication to renderer process
 * - Retry logic with exponential backoff
 */

class SyncManager extends EventEmitter {
  constructor(options = {}) {
    super();

    this.config = {
      syncInterval: options.syncInterval || 15 * 60 * 1000, // 15 minutes default
      maxRetries: options.maxRetries || 3,
      initialRetryDelay: options.initialRetryDelay || 5000, // 5 seconds
      maxRetryDelay: options.maxRetryDelay || 60000, // 60 seconds
      ...options
    };

    this.state = {
      status: 'idle', // idle, syncing, error
      isSyncing: false,
      lastSyncTime: null,
      lastSyncError: null,
      syncCount: 0,
      retryCount: 0
    };

    this.intervalId = null;
    this.syncTimeoutId = null;
  }

  /**
   * Get current sync state
   * @returns {object}
   */
  getState() {
    return { ...this.state };
  }

  /**
   * Initialize IPC handlers
   * Call from main process after creating SyncManager instance
   */
  initializeIPC() {
    ipcMain.handle('sync:get-state', () => {
      return this.getState();
    });

    ipcMain.handle('sync:start', async () => {
      return await this.performSync();
    });

    ipcMain.handle('sync:stop', async () => {
      return this.stop();
    });

    log.info('SyncManager IPC handlers registered');
  }

  /**
   * Start the sync manager
   * Begins periodic syncing based on configured interval
   */
  start() {
    if (this.intervalId) {
      log.warn('SyncManager already started');
      return;
    }

    log.info('SyncManager starting', { interval: this.config.syncInterval });

    // Perform initial sync immediately
    this.performSync().catch((err) => {
      log.error('Initial sync failed', { error: err.message });
    });

    // Schedule periodic syncs
    this.intervalId = setInterval(() => {
      if (!this.state.isSyncing) {
        this.performSync().catch((err) => {
          log.error('Periodic sync failed', { error: err.message });
        });
      }
    }, this.config.syncInterval);

    log.info('SyncManager periodic sync scheduled');
    this.emit('started');
  }

  /**
   * Stop the sync manager
   * Cancels periodic syncing and waits for any in-flight sync to complete
   */
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    if (this.syncTimeoutId) {
      clearTimeout(this.syncTimeoutId);
      this.syncTimeoutId = null;
    }

    log.info('SyncManager stopped');
    this.emit('stopped');

    return { stopped: true };
  }

  /**
   * Perform a sync operation
   * Handles retry logic with exponential backoff
   *
   * @returns {Promise<object>} - { success: boolean, message: string, timestamp: ISO8601 }
   */
  async performSync() {
    if (this.state.isSyncing) {
      log.warn('Sync already in progress');
      return {
        success: false,
        message: 'Sync already in progress',
        timestamp: new Date().toISOString()
      };
    }

    this.state.isSyncing = true;
    this.state.status = 'syncing';
    this.state.retryCount = 0;
    this.broadcastStatus();

    try {
      const result = await this._executeSync();

      this.state.isSyncing = false;
      this.state.status = 'idle';
      this.state.lastSyncTime = new Date().toISOString();
      this.state.lastSyncError = null;
      this.state.syncCount += 1;
      this.broadcastStatus();

      log.info('Sync completed successfully', {
        syncCount: this.state.syncCount,
        timestamp: this.state.lastSyncTime
      });

      this.emit('sync-success', result);

      return {
        success: true,
        message: result.message || 'Sync completed successfully',
        claimsProcessed: result.claimsProcessed || 0,
        timestamp: this.state.lastSyncTime
      };
    } catch (error) {
      log.error('Sync operation failed', {
        error: error.message,
        retryCount: this.state.retryCount
      });

      if (this.state.retryCount < this.config.maxRetries) {
        return this._retrySync(error);
      }

      this.state.isSyncing = false;
      this.state.status = 'error';
      this.state.lastSyncError = error.message;
      this.broadcastStatus();

      this.emit('sync-error', error);

      return {
        success: false,
        message: `Sync failed after ${this.config.maxRetries} retries: ${error.message}`,
        timestamp: new Date().toISOString()
      };
    }
  }

  /**
   * Retry sync with exponential backoff
   * @private
   *
   * @param {Error} error - The error that triggered the retry
   * @returns {Promise<object>}
   */
  async _retrySync(error) {
    this.state.retryCount += 1;
    const delayMs = Math.min(
      this.config.initialRetryDelay * Math.pow(2, this.state.retryCount - 1),
      this.config.maxRetryDelay
    );

    log.warn('Retrying sync', {
      attempt: this.state.retryCount,
      maxRetries: this.config.maxRetries,
      delayMs
    });

    this.emit('sync-retry', {
      attempt: this.state.retryCount,
      maxRetries: this.config.maxRetries,
      delayMs
    });

    // Wait before retrying
    await new Promise((resolve) => {
      this.syncTimeoutId = setTimeout(resolve, delayMs);
    });

    // Attempt sync again
    return this.performSync();
  }

  /**
   * Execute the actual sync operation
   * This calls the Abeldent sync service
   * @private
   *
   * @returns {Promise<object>} - { message: string, claimsProcessed: number }
   */
  async _executeSync() {
    // TODO: Replace with actual Abeldent sync service call
    // This would typically:
    // 1. Connect to Abeldent API/database
    // 2. Fetch new/updated claims
    // 3. Send to CollectRx cloud/local database
    // 4. Update local cache

    log.debug('Executing sync to Abeldent');

    // Simulate sync operation for now
    return new Promise((resolve, reject) => {
      // In production, this would call the actual sync service
      // For now, randomly simulate success/failure for testing

      // TODO: Remove randomization, implement real sync
      const shouldSucceed = Math.random() > 0.1; // 90% success rate

      if (shouldSucceed) {
        resolve({
          message: 'Claims synced from Abeldent successfully',
          claimsProcessed: Math.floor(Math.random() * 50)
        });
      } else {
        reject(new Error('Failed to connect to Abeldent service'));
      }
    });
  }

  /**
   * Broadcast status to renderer process via IPC
   * @private
   */
  broadcastStatus() {
    const { ipcMain } = require('electron');
    const windows = require('electron').BrowserWindow.getAllWindows();

    windows.forEach((window) => {
      if (window && !window.isDestroyed()) {
        window.webContents.send('sync:status-update', this.getState());
      }
    });

    this.emit('status-updated', this.getState());
  }

  /**
   * Graceful shutdown
   * Waits for any in-flight sync to complete before stopping
   *
   * @returns {Promise<void>}
   */
  async shutdown() {
    log.info('SyncManager shutting down');

    this.stop();

    // Wait for any in-flight sync to complete
    let attempts = 0;
    const maxAttempts = 60; // 30 seconds max wait (60 * 500ms)

    while (this.state.isSyncing && attempts < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 500));
      attempts += 1;
    }

    if (this.state.isSyncing) {
      log.warn('SyncManager shutdown timeout - sync still in progress');
    } else {
      log.info('SyncManager shutdown complete');
    }

    this.emit('shutdown');
  }
}

/**
 * Create and initialize a global SyncManager instance
 * Usage: const syncMgr = require('./syncManager').createSyncManager(options);
 *
 * @param {object} options - Configuration options
 * @param {number} options.syncInterval - Sync interval in ms (default: 15 min)
 * @param {number} options.maxRetries - Max retry attempts (default: 3)
 * @param {number} options.initialRetryDelay - Initial retry delay in ms (default: 5 sec)
 * @returns {SyncManager}
 */
function createSyncManager(options = {}) {
  const manager = new SyncManager(options);
  manager.initializeIPC();
  return manager;
}

module.exports = {
  SyncManager,
  createSyncManager
};
