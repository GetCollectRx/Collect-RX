const { contextBridge, ipcRenderer } = require('electron');

/**
 * Expose safe CollectRx API methods to renderer process
 * All methods communicate with backend through main process IPC handlers
 */
contextBridge.exposeInMainWorld('collectrx', {
  /**
   * Get current queue statistics
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  getQueueStats: () => ipcRenderer.invoke('get-queue-stats'),

  /**
   * Get aging report broken down by carrier
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  getAgingReport: () => ipcRenderer.invoke('get-aging-report'),

  /**
   * Get knowledge base health stats for all carriers
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  getCarrierStats: () => ipcRenderer.invoke('get-carrier-stats'),

  /**
   * Update carrier priority
   * @param {string} carrier - Carrier code (e.g., sunlife_private, manulife)
   * @param {number} priority - Priority level
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  updateCarrierPriority: (carrier, priority) =>
    ipcRenderer.invoke('update-carrier-priority', { carrier, priority }),

  /**
   * List claims with optional filters
   * @param {Object} filters - Optional filters
   * @param {string} filters.carrier - Filter by carrier code
   * @param {string} filters.bucket - Filter by aging bucket (0-29, 30-59, 60-89, 90-119, 120+)
   * @param {string} filters.queue_status - Filter by queue status (queued, in_progress, resolved, escalated, paused, excluded)
   * @param {number} filters.limit - Max results to return
   * @returns {Promise<{success: boolean, data?: object[], error?: string}>}
   */
  listClaims: (filters) => ipcRenderer.invoke('list-claims', filters),

  /**
   * Get full details of a single claim including call history
   * @param {number} claimId - The claim ID
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  getClaim: (claimId) => ipcRenderer.invoke('get-claim', claimId),

  /**
   * Get all open escalations that need human attention
   * @returns {Promise<{success: boolean, data?: object[], error?: string}>}
   */
  listEscalations: () => ipcRenderer.invoke('list-escalations'),

  /**
   * Dispatch queue to Vapi for all eligible claims
   * @param {number} practiceId - Optional practice ID, uses default if omitted
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  runQueue: (practiceId) => ipcRenderer.invoke('run-queue', practiceId),

  /**
   * Get practice details and queue stats
   * @param {number} practiceId - The practice ID
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  getPractice: (practiceId) => ipcRenderer.invoke('get-practice', practiceId),

  /**
   * Preview which claims would be called in the next run
   * @returns {Promise<{success: boolean, data?: object[], error?: string}>}
   */
  buildQueue: () => ipcRenderer.invoke('build-queue'),

  /**
   * Pause a claim so it won't be called in future queue runs
   * @param {number} claimId - The claim ID to pause
   * @param {string} reason - Why the claim is being paused
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  pauseClaim: (claimId, reason) =>
    ipcRenderer.invoke('pause-claim', { claimId, reason }),

  /**
   * Return a paused claim back to the active queue
   * @param {number} claimId - The claim ID to unpause
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  unpauseClaim: (claimId) => ipcRenderer.invoke('unpause-claim', claimId),

  /**
   * List all active dental practices
   * @returns {Promise<{success: boolean, data?: object[], error?: string}>}
   */
  listPractices: () => ipcRenderer.invoke('list-practices'),

  /**
   * Update practice settings
   * @param {number} practiceId - The practice ID
   * @param {Object} updates - Fields to update (max_call_attempts, min_claim_value, etc.)
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  updatePractice: (practiceId, updates) =>
    ipcRenderer.invoke('update-practice', { practiceId, updates }),

  /**
   * Mark an escalation as resolved
   * @param {number} escalationId - The escalation ID
   * @param {string} resolutionNotes - How the escalation was resolved
   * @returns {Promise<{success: boolean, data?: object, error?: string}>}
   */
  resolveEscalation: (escalationId, resolutionNotes) =>
    ipcRenderer.invoke('resolve-escalation', { escalationId, resolutionNotes }),
});
