const { app, BrowserWindow, ipcMain, Menu, Tray, dialog } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');
const log = require('electron-log');
const Store = require('electron-store');
const fetch = require('electron-fetch');

// Enable logging
log.transports.file.level = 'info';
log.transports.console.level = 'debug';

// Initialize settings store
const store = new Store({
  defaults: {
    windowBounds: { width: 1280, height: 800, x: undefined, y: undefined },
    autoStartEnabled: process.platform === 'win32',
    lastSyncStatus: 'idle',
    lastSyncTime: null,
  },
});

// Get backend API URL from environment or use default
const BACKEND_URL = process.env.COLLECTRX_API_URL || 'https://collectrx-api.railway.app';

log.info(`CollectRx Desktop starting in ${isDev ? 'development' : 'production'} mode`);
log.info(`Backend API URL: ${BACKEND_URL}`);

let mainWindow;
let tray;

// Single instance lock
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

/**
 * Helper function to fetch from backend API with error handling
 */
async function fetchFromBackend(endpoint, options = {}) {
  try {
    const url = `${BACKEND_URL}${endpoint}`;
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    return { success: true, data };
  } catch (error) {
    log.error(`Backend API error on ${endpoint}:`, error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Create main application window
 */
function createWindow() {
  const bounds = store.get('windowBounds');

  mainWindow = new BrowserWindow({
    width: bounds.width || 1280,
    height: bounds.height || 800,
    x: bounds.x,
    y: bounds.y,
    minWidth: 1024,
    minHeight: 700,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      enableRemoteModule: false,
      sandbox: true,
    },
    icon: path.join(__dirname, '../../assets/icons/icon.png'),
  });

  // Load app
  const startUrl = isDev
    ? 'http://localhost:5173'
    : `file://${path.join(__dirname, '../../dist/index.html')}`;

  mainWindow.loadURL(startUrl);

  // Open DevTools in development
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // Save window state before closing
  mainWindow.on('close', () => {
    const bounds = mainWindow.getBounds();
    store.set('windowBounds', bounds);
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  return mainWindow;
}

/**
 * Create system tray with context menu
 */
function createTray() {
  const iconPath = path.join(__dirname, '../../assets/icons/tray.png');
  tray = new Tray(iconPath);

  const contextMenu = Menu.buildFromTemplate([
    {
      label: 'Show Dashboard',
      click: () => {
        if (mainWindow) {
          mainWindow.show();
          mainWindow.focus();
        }
      },
    },
    {
      label: `Sync Status: ${store.get('lastSyncStatus')}`,
      enabled: false,
    },
    { type: 'separator' },
    {
      label: 'Quit',
      click: () => {
        app.quit();
      },
    },
  ]);

  tray.setContextMenu(contextMenu);
  tray.on('double-click', () => {
    if (mainWindow) {
      mainWindow.show();
      mainWindow.focus();
    }
  });
}

/**
 * Set up auto-start on Windows
 */
function setupAutoStart() {
  if (process.platform !== 'win32') return;

  const autoStartEnabled = store.get('autoStartEnabled');
  if (autoStartEnabled) {
    app.setLoginItemSettings({
      openAtLogin: true,
      path: app.getPath('exe'),
    });
  }
}

// ============================================================================
// IPC HANDLERS
// ============================================================================

/**
 * Get current queue statistics
 */
ipcMain.handle('get-queue-stats', async () => {
  log.info('IPC: get-queue-stats');
  return fetchFromBackend('/api/queue/stats');
});

/**
 * Get aging report by carrier
 */
ipcMain.handle('get-aging-report', async () => {
  log.info('IPC: get-aging-report');
  return fetchFromBackend('/api/reports/aging');
});

/**
 * Get carrier knowledge base stats
 */
ipcMain.handle('get-carrier-stats', async () => {
  log.info('IPC: get-carrier-stats');
  return fetchFromBackend('/api/carriers/stats');
});

/**
 * Update carrier priority
 */
ipcMain.handle('update-carrier-priority', async (event, { carrier, priority }) => {
  log.info(`IPC: update-carrier-priority - carrier: ${carrier}, priority: ${priority}`);
  return fetchFromBackend(`/api/carriers/${carrier}/priority`, {
    method: 'POST',
    body: JSON.stringify({ priority }),
  });
});

/**
 * List claims with optional filters
 */
ipcMain.handle('list-claims', async (event, filters) => {
  log.info('IPC: list-claims', { filters });
  const params = new URLSearchParams();
  if (filters) {
    if (filters.carrier) params.append('carrier', filters.carrier);
    if (filters.bucket) params.append('bucket', filters.bucket);
    if (filters.queue_status) params.append('queue_status', filters.queue_status);
    if (filters.limit) params.append('limit', filters.limit);
  }
  return fetchFromBackend(`/api/claims?${params.toString()}`);
});

/**
 * Get full details of a single claim
 */
ipcMain.handle('get-claim', async (event, claimId) => {
  log.info(`IPC: get-claim - claimId: ${claimId}`);
  return fetchFromBackend(`/api/claims/${claimId}`);
});

/**
 * List open escalations
 */
ipcMain.handle('list-escalations', async () => {
  log.info('IPC: list-escalations');
  return fetchFromBackend('/api/escalations');
});

/**
 * Dispatch queue to Vapi (run calls)
 */
ipcMain.handle('run-queue', async (event, practiceId) => {
  log.info(`IPC: run-queue - practiceId: ${practiceId}`);
  const endpoint = practiceId ? `/api/queue/run?practice_id=${practiceId}` : '/api/queue/run';
  return fetchFromBackend(endpoint, {
    method: 'POST',
    body: JSON.stringify({}),
  });
});

/**
 * Get practice details and queue stats
 */
ipcMain.handle('get-practice', async (event, practiceId) => {
  log.info(`IPC: get-practice - practiceId: ${practiceId}`);
  return fetchFromBackend(`/api/practices/${practiceId}`);
});

/**
 * Preview which claims would be called in next run
 */
ipcMain.handle('build-queue', async () => {
  log.info('IPC: build-queue');
  return fetchFromBackend('/api/queue/build');
});

/**
 * Pause a claim
 */
ipcMain.handle('pause-claim', async (event, { claimId, reason }) => {
  log.info(`IPC: pause-claim - claimId: ${claimId}`);
  return fetchFromBackend(`/api/claims/${claimId}/pause`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
});

/**
 * Unpause a claim
 */
ipcMain.handle('unpause-claim', async (event, claimId) => {
  log.info(`IPC: unpause-claim - claimId: ${claimId}`);
  return fetchFromBackend(`/api/claims/${claimId}/unpause`, {
    method: 'POST',
    body: JSON.stringify({}),
  });
});

/**
 * List all practices
 */
ipcMain.handle('list-practices', async () => {
  log.info('IPC: list-practices');
  return fetchFromBackend('/api/practices');
});

/**
 * Update practice settings
 */
ipcMain.handle('update-practice', async (event, { practiceId, updates }) => {
  log.info(`IPC: update-practice - practiceId: ${practiceId}`);
  return fetchFromBackend(`/api/practices/${practiceId}`, {
    method: 'POST',
    body: JSON.stringify(updates),
  });
});

/**
 * Resolve an escalation
 */
ipcMain.handle('resolve-escalation', async (event, { escalationId, resolutionNotes }) => {
  log.info(`IPC: resolve-escalation - escalationId: ${escalationId}`);
  return fetchFromBackend(`/api/escalations/${escalationId}/resolve`, {
    method: 'POST',
    body: JSON.stringify({ resolution_notes: resolutionNotes }),
  });
});

// ============================================================================
// APP LIFECYCLE
// ============================================================================

app.on('ready', () => {
  log.info('App ready');
  createWindow();
  createTray();
  setupAutoStart();
});

app.on('window-all-closed', () => {
  // On macOS, applications typically stay active until explicitly quit
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  // On macOS, re-create window when dock icon is clicked
  if (mainWindow === null) {
    createWindow();
  }
});

app.on('before-quit', () => {
  log.info('App quitting');
});

// Handle any uncaught exceptions
process.on('uncaughtException', (error) => {
  log.error('Uncaught Exception:', error);
  dialog.showErrorBox('CollectRx Error', 'An unexpected error occurred. Please contact support.');
});
