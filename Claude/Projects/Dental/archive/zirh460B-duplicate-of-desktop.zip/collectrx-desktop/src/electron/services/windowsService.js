const os = require('os');
const path = require('path');
const Service = require('node-windows').Service;
const logger = require('electron-log');

/**
 * Windows Service Management for CollectRx
 * Manages installation and lifecycle of the Abeldent Sync Service
 * Only operates on Windows platform
 */

const SERVICE_NAME = 'CollectRx Sync Service';
const SERVICE_DESCRIPTION = 'Syncs dental claims from Abeldent to CollectRx cloud';

// Script path for the service to run
let serviceScriptPath = null;

/**
 * Set the path to the sync service script
 * @param {string} scriptPath - Full path to the service script (e.g., src/services/sync-worker.js)
 */
function setServiceScriptPath(scriptPath) {
  serviceScriptPath = scriptPath;
  logger.info('Service script path set', { scriptPath });
}

/**
 * Check if running on Windows
 * @returns {boolean}
 */
function isWindows() {
  return os.platform() === 'win32';
}

/**
 * Create a Service instance
 * @returns {Service|null} - Service instance or null if not on Windows
 */
function createServiceInstance() {
  if (!isWindows()) {
    logger.warn('Windows Service operations not available on this platform', {
      platform: os.platform()
    });
    return null;
  }

  if (!serviceScriptPath) {
    throw new Error('Service script path not set. Call setServiceScriptPath() first.');
  }

  return new Service({
    name: SERVICE_NAME,
    description: SERVICE_DESCRIPTION,
    script: serviceScriptPath,
    nodeOptions: [
      '--harmony',
      '--max-old-space-size=4096'
    ],
    env: {
      name: 'NODE_ENV',
      value: process.env.NODE_ENV || 'production'
    },
    logpath: path.join(os.homedir(), 'AppData', 'Local', 'CollectRx', 'logs'),
    executable: process.execPath // Use current Node.js executable
  });
}

/**
 * Install the Windows Service
 * @returns {Promise<object>} - { success: boolean, message: string }
 */
async function installService() {
  return new Promise((resolve) => {
    if (!isWindows()) {
      const message = 'Cannot install service on non-Windows platform';
      logger.warn(message, { platform: os.platform() });
      return resolve({ success: false, message });
    }

    try {
      const svc = createServiceInstance();
      if (!svc) {
        return resolve({
          success: false,
          message: 'Failed to create service instance'
        });
      }

      svc.on('install', () => {
        logger.info('Service installed successfully', { service: SERVICE_NAME });
        resolve({
          success: true,
          message: `${SERVICE_NAME} installed successfully`
        });
      });

      svc.on('error', (err) => {
        logger.error('Service installation error', {
          service: SERVICE_NAME,
          error: err.message
        });
        resolve({
          success: false,
          message: `Installation failed: ${err.message}`
        });
      });

      svc.install();
    } catch (error) {
      logger.error('Service installation exception', {
        error: error.message,
        stack: error.stack
      });
      resolve({
        success: false,
        message: `Installation exception: ${error.message}`
      });
    }
  });
}

/**
 * Uninstall the Windows Service
 * @returns {Promise<object>} - { success: boolean, message: string }
 */
async function uninstallService() {
  return new Promise((resolve) => {
    if (!isWindows()) {
      const message = 'Cannot uninstall service on non-Windows platform';
      logger.warn(message, { platform: os.platform() });
      return resolve({ success: false, message });
    }

    try {
      const svc = createServiceInstance();
      if (!svc) {
        return resolve({
          success: false,
          message: 'Failed to create service instance'
        });
      }

      svc.on('uninstall', () => {
        logger.info('Service uninstalled successfully', { service: SERVICE_NAME });
        resolve({
          success: true,
          message: `${SERVICE_NAME} uninstalled successfully`
        });
      });

      svc.on('error', (err) => {
        logger.error('Service uninstallation error', {
          service: SERVICE_NAME,
          error: err.message
        });
        resolve({
          success: false,
          message: `Uninstallation failed: ${err.message}`
        });
      });

      svc.uninstall();
    } catch (error) {
      logger.error('Service uninstallation exception', {
        error: error.message,
        stack: error.stack
      });
      resolve({
        success: false,
        message: `Uninstallation exception: ${error.message}`
      });
    }
  });
}

/**
 * Start the Windows Service
 * @returns {Promise<object>} - { success: boolean, message: string }
 */
async function startService() {
  return new Promise((resolve) => {
    if (!isWindows()) {
      const message = 'Cannot start service on non-Windows platform';
      logger.warn(message, { platform: os.platform() });
      return resolve({ success: false, message });
    }

    try {
      const svc = createServiceInstance();
      if (!svc) {
        return resolve({
          success: false,
          message: 'Failed to create service instance'
        });
      }

      svc.on('start', () => {
        logger.info('Service started successfully', { service: SERVICE_NAME });
        resolve({
          success: true,
          message: `${SERVICE_NAME} started successfully`
        });
      });

      svc.on('error', (err) => {
        logger.error('Service start error', {
          service: SERVICE_NAME,
          error: err.message
        });
        resolve({
          success: false,
          message: `Start failed: ${err.message}`
        });
      });

      svc.start();
    } catch (error) {
      logger.error('Service start exception', {
        error: error.message,
        stack: error.stack
      });
      resolve({
        success: false,
        message: `Start exception: ${error.message}`
      });
    }
  });
}

/**
 * Stop the Windows Service
 * @returns {Promise<object>} - { success: boolean, message: string }
 */
async function stopService() {
  return new Promise((resolve) => {
    if (!isWindows()) {
      const message = 'Cannot stop service on non-Windows platform';
      logger.warn(message, { platform: os.platform() });
      return resolve({ success: false, message });
    }

    try {
      const svc = createServiceInstance();
      if (!svc) {
        return resolve({
          success: false,
          message: 'Failed to create service instance'
        });
      }

      svc.on('stop', () => {
        logger.info('Service stopped successfully', { service: SERVICE_NAME });
        resolve({
          success: true,
          message: `${SERVICE_NAME} stopped successfully`
        });
      });

      svc.on('error', (err) => {
        logger.error('Service stop error', {
          service: SERVICE_NAME,
          error: err.message
        });
        resolve({
          success: false,
          message: `Stop failed: ${err.message}`
        });
      });

      svc.stop();
    } catch (error) {
      logger.error('Service stop exception', {
        error: error.message,
        stack: error.stack
      });
      resolve({
        success: false,
        message: `Stop exception: ${error.message}`
      });
    }
  });
}

/**
 * Restart the Windows Service
 * @returns {Promise<object>} - { success: boolean, message: string }
 */
async function restartService() {
  return new Promise(async (resolve) => {
    if (!isWindows()) {
      const message = 'Cannot restart service on non-Windows platform';
      logger.warn(message, { platform: os.platform() });
      return resolve({ success: false, message });
    }

    try {
      const stopResult = await stopService();
      if (!stopResult.success) {
        logger.warn('Service stop failed during restart', stopResult);
      }

      // Wait a moment before restarting
      await new Promise((r) => setTimeout(r, 1000));

      const startResult = await startService();
      resolve(startResult);
    } catch (error) {
      logger.error('Service restart exception', {
        error: error.message,
        stack: error.stack
      });
      resolve({
        success: false,
        message: `Restart exception: ${error.message}`
      });
    }
  });
}

/**
 * Get the current status of the Windows Service
 * Note: node-windows doesn't provide direct status checking
 * This is a basic implementation that checks if the service is responsive
 *
 * @returns {Promise<object>} - { status: 'running'|'stopped'|'unknown', service: string }
 */
async function getServiceStatus() {
  if (!isWindows()) {
    logger.warn('Service status check not available on non-Windows platform', {
      platform: os.platform()
    });
    return { status: 'unknown', service: SERVICE_NAME };
  }

  try {
    // In production, use wmic or sc.exe commands to check actual status
    // This is a placeholder that would need implementation for Windows
    const { exec } = require('child_process');
    const { promisify } = require('util');
    const execAsync = promisify(exec);

    const command = `sc query "${SERVICE_NAME}"`;
    const { stdout } = await execAsync(command);

    if (stdout.includes('RUNNING')) {
      logger.info('Service is running', { service: SERVICE_NAME });
      return { status: 'running', service: SERVICE_NAME };
    } else if (stdout.includes('STOPPED')) {
      logger.info('Service is stopped', { service: SERVICE_NAME });
      return { status: 'stopped', service: SERVICE_NAME };
    }

    return { status: 'unknown', service: SERVICE_NAME };
  } catch (error) {
    logger.warn('Could not determine service status', {
      error: error.message,
      service: SERVICE_NAME
    });
    return { status: 'unknown', service: SERVICE_NAME };
  }
}

/**
 * Get the log file path for the service
 * @returns {string}
 */
function getLogPath() {
  return path.join(os.homedir(), 'AppData', 'Local', 'CollectRx', 'logs');
}

module.exports = {
  setServiceScriptPath,
  isWindows,
  installService,
  uninstallService,
  startService,
  stopService,
  restartService,
  getServiceStatus,
  getLogPath,
  SERVICE_NAME,
  SERVICE_DESCRIPTION
};
