const { autoUpdater } = require('electron-updater');
const { ipcMain, BrowserWindow } = require('electron');
const log = require('electron-log');
const EventEmitter = require('events');

/**
 * Auto-Updater Service for CollectRx Desktop
 * Manages application updates using electron-updater
 * - Check for updates on startup
 * - Periodic update checks (every 4 hours)
 * - Download progress tracking
 * - User notifications
 * - Install on quit option
 */

class AutoUpdaterService extends EventEmitter {
  constructor(options = {}) {
    super();

    this.config = {
      checkInterval: options.checkInterval || 4 * 60 * 60 * 1000, // 4 hours
      autoDownload: options.autoDownload !== false, // default true
      autoInstall: options.autoInstall !== false, // default true
      ...options
    };

    this.state = {
      updateAvailable: false,
      updateDownloaded: false,
      updateVersion: null,
      downloadProgress: 0,
      isChecking: false,
      isDownloading: false,
      lastCheckTime: null,
      lastError: null
    };

    this.intervalId = null;

    // Configure electron-updater
    autoUpdater.logger = log;
    autoUpdater.autoDownload = this.config.autoDownload;
    autoUpdater.autoInstallOnAppQuit = this.config.autoInstall;
  }

  /**
   * Get current updater state
   * @returns {object}
   */
  getState() {
    return { ...this.state };
  }

  /**
   * Initialize auto-updater
   * Sets up event handlers and IPC communication
   */
  initialize() {
    this._setupEventHandlers();
    this._setupIPC();
    log.info('AutoUpdaterService initialized', this.config);
  }

  /**
   * Start the auto-updater service
   * Checks for updates immediately and schedules periodic checks
   */
  start() {
    if (this.intervalId) {
      log.warn('AutoUpdaterService already started');
      return;
    }

    log.info('AutoUpdaterService starting');

    // Check for updates immediately
    this.checkForUpdates().catch((err) => {
      log.error('Initial update check failed', { error: err.message });
    });

    // Schedule periodic checks
    this.intervalId = setInterval(() => {
      this.checkForUpdates().catch((err) => {
        log.error('Periodic update check failed', { error: err.message });
      });
    }, this.config.checkInterval);

    log.info('AutoUpdaterService periodic checks scheduled', {
      interval: this.config.checkInterval
    });

    this.emit('started');
  }

  /**
   * Stop the auto-updater service
   */
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }

    log.info('AutoUpdaterService stopped');
    this.emit('stopped');
  }

  /**
   * Check for updates
   * @returns {Promise<object>} - { updateAvailable: boolean, version?: string }
   */
  async checkForUpdates() {
    if (this.state.isChecking) {
      log.warn('Update check already in progress');
      return {
        updateAvailable: this.state.updateAvailable,
        isChecking: true
      };
    }

    this.state.isChecking = true;
    this.broadcastState();

    try {
      log.info('Checking for updates');

      const updateInfo = await autoUpdater.checkForUpdates();

      this.state.isChecking = false;
      this.state.lastCheckTime = new Date().toISOString();
      this.state.lastError = null;

      if (updateInfo && updateInfo.updateInfo && updateInfo.updateInfo.version) {
        const newVersion = updateInfo.updateInfo.version;

        if (this._isNewerVersion(newVersion)) {
          this.state.updateAvailable = true;
          this.state.updateVersion = newVersion;

          log.info('Update available', { version: newVersion });
          this.emit('update-available', { version: newVersion });
          this._notifyUser(`Update available: v${newVersion}`);
        } else {
          this.state.updateAvailable = false;
          log.info('Application is up to date');
        }
      } else {
        this.state.updateAvailable = false;
      }

      this.broadcastState();

      return {
        updateAvailable: this.state.updateAvailable,
        version: this.state.updateVersion
      };
    } catch (error) {
      log.error('Update check failed', {
        error: error.message,
        stack: error.stack
      });

      this.state.isChecking = false;
      this.state.lastError = error.message;
      this.broadcastState();

      this.emit('update-check-error', error);

      throw error;
    }
  }

  /**
   * Download an available update
   * @returns {Promise<object>} - { success: boolean, message: string }
   */
  async downloadUpdate() {
    if (!this.state.updateAvailable) {
      const message = 'No update available';
      log.warn(message);
      return { success: false, message };
    }

    if (this.state.isDownloading) {
      const message = 'Download already in progress';
      log.warn(message);
      return { success: false, message };
    }

    this.state.isDownloading = true;
    this.state.downloadProgress = 0;
    this.broadcastState();

    try {
      log.info('Starting update download', { version: this.state.updateVersion });

      await autoUpdater.downloadUpdate();

      this.state.isDownloading = false;
      this.state.downloadProgress = 100;
      this.broadcastState();

      log.info('Update downloaded successfully');
      this.emit('update-downloaded');

      return {
        success: true,
        message: `Update v${this.state.updateVersion} downloaded successfully`
      };
    } catch (error) {
      log.error('Update download failed', {
        error: error.message,
        stack: error.stack
      });

      this.state.isDownloading = false;
      this.state.downloadProgress = 0;
      this.state.lastError = error.message;
      this.broadcastState();

      this.emit('update-download-error', error);

      return {
        success: false,
        message: `Download failed: ${error.message}`
      };
    }
  }

  /**
   * Install the downloaded update
   * On Windows/Linux, this quits the app and installs on startup
   * On macOS, it restarts the app immediately
   *
   * @returns {object} - { success: boolean, message: string }
   */
  installUpdate() {
    if (!this.state.updateDownloaded) {
      const message = 'No update available to install';
      log.warn(message);
      return { success: false, message };
    }

    try {
      log.info('Installing update', { version: this.state.updateVersion });
      this._notifyUser(`Installing update v${this.state.updateVersion}...`);

      // This will quit the app and install on next startup
      autoUpdater.quitAndInstall();

      return {
        success: true,
        message: `Update v${this.state.updateVersion} will install on app restart`
      };
    } catch (error) {
      log.error('Update installation failed', {
        error: error.message,
        stack: error.stack
      });

      this.state.lastError = error.message;
      this.broadcastState();

      return {
        success: false,
        message: `Installation failed: ${error.message}`
      };
    }
  }

  /**
   * Set up electron-updater event handlers
   * @private
   */
  _setupEventHandlers() {
    autoUpdater.on('checking-for-update', () => {
      log.info('Checking for updates...');
    });

    autoUpdater.on('update-available', (info) => {
      log.info('Update available', { version: info.version });
      this.state.updateAvailable = true;
      this.state.updateVersion = info.version;
      this.broadcastState();
    });

    autoUpdater.on('update-not-available', () => {
      log.info('No update available');
      this.state.updateAvailable = false;
      this.broadcastState();
    });

    autoUpdater.on('error', (error) => {
      log.error('Auto-updater error', {
        error: error.message,
        stack: error.stack
      });
      this.state.lastError = error.message;
      this.broadcastState();
    });

    autoUpdater.on('download-progress', (progressObj) => {
      const { percent, bytesPerSecond, transferred, total } = progressObj;

      this.state.downloadProgress = Math.round(percent);
      this.broadcastState();

      log.debug('Download progress', {
        percent: percent.toFixed(2),
        bytesPerSecond,
        transferred,
        total
      });

      this.emit('download-progress', {
        progress: this.state.downloadProgress,
        bytesPerSecond,
        transferred,
        total
      });
    });

    autoUpdater.on('update-downloaded', (info) => {
      log.info('Update downloaded', { version: info.version });
      this.state.updateDownloaded = true;
      this.state.downloadProgress = 100;
      this.broadcastState();

      this._notifyUser(
        `Update v${info.version} ready to install. Restart the app to install.`,
        'update'
      );

      this.emit('update-ready', { version: info.version });
    });
  }

  /**
   * Set up IPC handlers
   * @private
   */
  _setupIPC() {
    ipcMain.handle('updater:get-state', () => {
      return this.getState();
    });

    ipcMain.handle('updater:check-for-updates', async () => {
      return await this.checkForUpdates();
    });

    ipcMain.handle('updater:download-update', async () => {
      return await this.downloadUpdate();
    });

    ipcMain.handle('updater:install-update', () => {
      return this.installUpdate();
    });

    log.info('AutoUpdaterService IPC handlers registered');
  }

  /**
   * Check if a version is newer than current
   * @private
   *
   * @param {string} newVersion - Version string (e.g., "1.2.3")
   * @returns {boolean}
   */
  _isNewerVersion(newVersion) {
    // TODO: Get current version from package.json or process.env.VERSION
    const { app } = require('electron');
    const currentVersion = app.getVersion();

    return this._compareVersions(newVersion, currentVersion) > 0;
  }

  /**
   * Compare two version strings
   * Returns: 1 if v1 > v2, -1 if v1 < v2, 0 if equal
   * @private
   *
   * @param {string} v1
   * @param {string} v2
   * @returns {number}
   */
  _compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);

    for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
      const p1 = parts1[i] || 0;
      const p2 = parts2[i] || 0;

      if (p1 > p2) return 1;
      if (p1 < p2) return -1;
    }

    return 0;
  }

  /**
   * Notify the user about an update
   * @private
   *
   * @param {string} message
   * @param {string} type - 'info' or 'update'
   */
  _notifyUser(message, type = 'info') {
    const { Notification } = require('electron');

    if (Notification.isSupported()) {
      const notification = new Notification({
        title: 'CollectRx',
        body: message,
        icon: undefined // TODO: Add app icon path
      });

      notification.show();
    }

    // Also send via IPC to renderer
    const windows = BrowserWindow.getAllWindows();
    windows.forEach((window) => {
      if (window && !window.isDestroyed()) {
        window.webContents.send('updater:notification', { message, type });
      }
    });
  }

  /**
   * Broadcast state to all renderer processes
   * @private
   */
  broadcastState() {
    const windows = BrowserWindow.getAllWindows();
    windows.forEach((window) => {
      if (window && !window.isDestroyed()) {
        window.webContents.send('updater:state-update', this.getState());
      }
    });

    this.emit('state-updated', this.getState());
  }

  /**
   * Graceful shutdown
   */
  shutdown() {
    log.info('AutoUpdaterService shutting down');
    this.stop();
    this.emit('shutdown');
  }
}

/**
 * Create and initialize a global AutoUpdaterService instance
 *
 * @param {object} options - Configuration options
 * @returns {AutoUpdaterService}
 */
function createAutoUpdater(options = {}) {
  const service = new AutoUpdaterService(options);
  service.initialize();
  return service;
}

module.exports = {
  AutoUpdaterService,
  createAutoUpdater
};
