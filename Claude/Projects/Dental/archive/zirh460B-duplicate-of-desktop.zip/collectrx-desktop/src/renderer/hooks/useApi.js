import { useState, useEffect, useCallback, useRef } from 'react'

/**
 * Mock data for development without Electron
 */
const MOCK_DATA = {
  'queue-stats': {
    queued: 45,
    in_progress: 12,
    resolved: 280,
    escalated: 8,
    paused: 3,
    excluded: 0,
    total: 348,
  },
  'aging-report': {
    carriers: [
      { carrier: 'Sun Life', code: 'sunlife_private', '0-29': 12400, '30-59': 8200, '60-89': 4100, '90-119': 2300, '120+': 1800, total: 28800 },
      { carrier: 'Canada Life', code: 'great_west', '0-29': 9800, '30-59': 5600, '60-89': 3200, '90-119': 1400, '120+': 900, total: 20900 },
      { carrier: 'Manulife', code: 'manulife', '0-29': 7600, '30-59': 4100, '60-89': 2800, '90-119': 1100, '120+': 600, total: 16200 },
      { carrier: 'Green Shield', code: 'green_shield', '0-29': 5200, '30-59': 3400, '60-89': 1900, '90-119': 800, '120+': 400, total: 11700 },
      { carrier: 'RBC Insurance', code: 'rbc_insurance', '0-29': 3100, '30-59': 2000, '60-89': 1200, '90-119': 500, '120+': 300, total: 7100 },
      { carrier: 'TELUS AdjudiCare', code: 'telus_adjudicare', '0-29': 1900, '30-59': 1200, '60-89': 800, '90-119': 300, '120+': 200, total: 4400 },
    ],
    totals: { '0-29': 40000, '30-59': 24500, '60-89': 14000, '90-119': 6400, '120+': 4200, total: 89100 },
  },
  'carrier-stats': {
    carriers: [
      { code: 'sunlife_private', name: 'Sun Life', confidence: 0.87, known_steps: 12, success_rate: 0.72, total_calls: 145 },
      { code: 'great_west', name: 'Canada Life', confidence: 0.82, known_steps: 10, success_rate: 0.68, total_calls: 112 },
      { code: 'manulife', name: 'Manulife', confidence: 0.79, known_steps: 9, success_rate: 0.65, total_calls: 98 },
      { code: 'green_shield', name: 'Green Shield', confidence: 0.74, known_steps: 8, success_rate: 0.61, total_calls: 76 },
      { code: 'rbc_insurance', name: 'RBC Insurance', confidence: 0.71, known_steps: 7, success_rate: 0.58, total_calls: 54 },
      { code: 'telus_adjudicare', name: 'TELUS AdjudiCare', confidence: 0.65, known_steps: 6, success_rate: 0.52, total_calls: 32 },
    ],
  },
  'claims-list': {
    claims: [
      { id: 1001, patient_name: 'J. Smith', carrier: 'Sun Life', carrier_code: 'sunlife_private', amount: 2450.00, age_days: 42, queue_status: 'queued', last_action: '2026-04-02', procedure: 'D2740' },
      { id: 1002, patient_name: 'M. Chen', carrier: 'Manulife', carrier_code: 'manulife', amount: 1875.50, age_days: 67, queue_status: 'in_progress', last_action: '2026-04-04', procedure: 'D4341' },
      { id: 1003, patient_name: 'A. Patel', carrier: 'Canada Life', carrier_code: 'great_west', amount: 3200.00, age_days: 35, queue_status: 'queued', last_action: '2026-04-01', procedure: 'D2750' },
      { id: 1004, patient_name: 'S. Williams', carrier: 'Green Shield', carrier_code: 'green_shield', amount: 980.00, age_days: 95, queue_status: 'escalated', last_action: '2026-03-28', procedure: 'D1110' },
      { id: 1005, patient_name: 'R. Johnson', carrier: 'Sun Life', carrier_code: 'sunlife_private', amount: 4100.00, age_days: 18, queue_status: 'resolved', last_action: '2026-04-05', procedure: 'D6010' },
      { id: 1006, patient_name: 'L. Kim', carrier: 'RBC Insurance', carrier_code: 'rbc_insurance', amount: 1560.00, age_days: 53, queue_status: 'queued', last_action: '2026-03-30', procedure: 'D2391' },
      { id: 1007, patient_name: 'D. Brown', carrier: 'TELUS AdjudiCare', carrier_code: 'telus_adjudicare', amount: 2890.00, age_days: 112, queue_status: 'escalated', last_action: '2026-03-25', procedure: 'D7210' },
      { id: 1008, patient_name: 'K. Nguyen', carrier: 'Manulife', carrier_code: 'manulife', amount: 720.00, age_days: 31, queue_status: 'queued', last_action: '2026-04-03', procedure: 'D0220' },
      { id: 1009, patient_name: 'T. Wilson', carrier: 'Canada Life', carrier_code: 'great_west', amount: 5400.00, age_days: 78, queue_status: 'paused', last_action: '2026-03-20', procedure: 'D6058' },
      { id: 1010, patient_name: 'E. Garcia', carrier: 'Sun Life', carrier_code: 'sunlife_private', amount: 1340.00, age_days: 45, queue_status: 'in_progress', last_action: '2026-04-04', procedure: 'D2330' },
    ],
    total: 45,
  },
  'escalations-list': {
    escalations: [
      { id: 1, claim_id: 1004, carrier: 'Green Shield', reason: 'Carrier requesting additional documentation', age_days: 95, created_at: '2026-03-28' },
      { id: 2, claim_id: 1007, carrier: 'TELUS AdjudiCare', reason: 'Unable to identify TPA — manual carrier identification needed', age_days: 112, created_at: '2026-03-25' },
      { id: 3, claim_id: 1015, carrier: 'Manulife', reason: 'Claim denied — appeal required', age_days: 88, created_at: '2026-03-15' },
    ],
  },
  'practice': {
    id: 1,
    name: 'Tenth Line Family Dentistry',
    address: 'Ottawa, ON',
    max_call_attempts: 3,
    min_claim_value: 50,
    call_window_start: '08:00',
    call_window_end: '17:00',
    escalation_email: 'admin@tenthlinedental.ca',
    sync_interval_minutes: 15,
    last_sync: '2026-04-05T14:30:00Z',
  },
  'build-queue': {
    claims: [
      { claim_id: 1001, carrier: 'sunlife_private', amount: 2450, priority_score: 92 },
      { claim_id: 1003, carrier: 'great_west', amount: 3200, priority_score: 88 },
      { claim_id: 1006, carrier: 'rbc_insurance', amount: 1560, priority_score: 75 },
      { claim_id: 1008, carrier: 'manulife', amount: 720, priority_score: 62 },
    ],
  },
}

/**
 * Maps endpoint keys to window.collectrx methods and mock data
 */
const ENDPOINT_MAP = {
  'queue-stats': { method: 'getQueueStats', mock: 'queue-stats' },
  'aging-report': { method: 'getAgingReport', mock: 'aging-report' },
  'carrier-stats': { method: 'getCarrierStats', mock: 'carrier-stats' },
  'claims-list': { method: 'listClaims', mock: 'claims-list' },
  'escalations-list': { method: 'listEscalations', mock: 'escalations-list' },
  'practice': { method: 'getPractice', mock: 'practice' },
  'build-queue': { method: 'buildQueue', mock: 'build-queue' },
}

/**
 * Custom hook for calling CollectRx backend via Electron IPC.
 * Falls back to mock data in development (no Electron).
 *
 * @param {string} endpoint - Endpoint key (e.g. 'queue-stats', 'claims-list')
 * @param {Object} options
 * @param {Object} options.params - Parameters to pass to the IPC method
 * @param {number} options.pollInterval - Polling interval in ms (default 30000)
 * @param {boolean} options.poll - Whether to poll (default true)
 * @param {boolean} options.enabled - Whether to fetch (default true)
 * @returns {{ data: any, loading: boolean, error: Error|null, refetch: () => Promise<void> }}
 */
export function useApi(endpoint, options = {}) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const mountedRef = useRef(true)

  const pollInterval = options.pollInterval ?? 30000
  const shouldPoll = options.poll !== false
  const enabled = options.enabled !== false

  const fetchData = useCallback(async () => {
    if (!enabled) return

    try {
      setLoading((prev) => prev || data === null)
      setError(null)

      const config = ENDPOINT_MAP[endpoint]
      if (!config) {
        throw new Error(`Unknown endpoint: ${endpoint}`)
      }

      let result

      // Check if Electron IPC is available
      if (window.collectrx && typeof window.collectrx[config.method] === 'function') {
        result = await window.collectrx[config.method](options.params)
        if (result?.error) {
          throw new Error(result.error)
        }
        result = result?.data ?? result
      } else {
        // Development fallback: return mock data
        await new Promise((r) => setTimeout(r, 400 + Math.random() * 300))
        result = MOCK_DATA[config.mock] ?? null
      }

      if (mountedRef.current) {
        setData(result)
      }
    } catch (err) {
      if (mountedRef.current) {
        setError(err)
        console.error(`[useApi] Error fetching ${endpoint}:`, err)
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false)
      }
    }
  }, [endpoint, enabled, options.params])

  const refetch = useCallback(() => {
    return fetchData()
  }, [fetchData])

  // Initial fetch
  useEffect(() => {
    fetchData()
  }, [fetchData])

  // Polling
  useEffect(() => {
    if (!shouldPoll || !pollInterval || !enabled) return

    const timer = setInterval(fetchData, pollInterval)
    return () => clearInterval(timer)
  }, [shouldPoll, pollInterval, enabled, fetchData])

  // Cleanup
  useEffect(() => {
    mountedRef.current = true
    return () => {
      mountedRef.current = false
    }
  }, [])

  return { data, loading, error, refetch }
}
