import { useState } from 'react'
import {
  LayoutDashboard,
  BarChart3,
  TrendingUp,
  Users,
  FileText,
  Send,
  Settings,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
} from 'lucide-react'

const ICON_MAP = {
  LayoutDashboard,
  BarChart3,
  TrendingUp,
  Users,
  FileText,
  Send,
  Settings,
}

export default function Navigation({ tabs, activeTab, onTabChange, onOpenPriority }) {
  const [isCollapsed, setIsCollapsed] = useState(false)

  return (
    <nav
      className={`${
        isCollapsed ? 'w-16' : 'w-60'
      } bg-white border-r border-gray-200 flex flex-col overflow-hidden transition-all duration-200 shrink-0`}
    >
      {/* Logo */}
      <div className="px-4 py-5 border-b border-gray-100">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center text-white font-bold text-xs shrink-0">
            Rx
          </div>
          {!isCollapsed && (
            <div className="min-w-0">
              <h1 className="text-sm font-bold text-gray-900 leading-tight">CollectRx</h1>
              <p className="text-[11px] text-gray-400 leading-tight">Dental AR</p>
            </div>
          )}
        </div>
      </div>

      {/* Nav Items */}
      <div className="flex-1 overflow-y-auto py-2">
        <div className="space-y-0.5 px-2">
          {tabs.map((tab) => {
            const Icon = ICON_MAP[tab.icon]
            const isActive = activeTab === tab.id

            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg transition-all text-sm font-medium ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
                title={isCollapsed ? tab.label : undefined}
              >
                {Icon && (
                  <Icon
                    className={`w-[18px] h-[18px] shrink-0 ${
                      isActive ? 'text-emerald-600' : 'text-gray-400'
                    }`}
                  />
                )}
                {!isCollapsed && <span>{tab.label}</span>}
              </button>
            )
          })}
        </div>

        {/* Carrier Priority shortcut */}
        {!isCollapsed && (
          <div className="px-2 mt-4 pt-4 border-t border-gray-100">
            <button
              onClick={onOpenPriority}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50 transition-all"
            >
              <ArrowUpDown className="w-[18px] h-[18px] shrink-0 text-gray-400" />
              <span>Carrier Priority</span>
            </button>
          </div>
        )}
      </div>

      {/* Collapse Toggle */}
      <div className="border-t border-gray-100 p-2">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-50 text-gray-400 hover:text-gray-600 transition-colors text-xs"
          title={isCollapsed ? 'Expand' : 'Collapse'}
        >
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" />
              <span>Collapse</span>
            </>
          )}
        </button>
      </div>
    </nav>
  )
}
