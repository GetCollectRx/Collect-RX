import { getStatusColor, getStatusLabel } from '../../utils/formatters'

export default function StatusBadge({ status, size = 'md' }) {
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs font-medium rounded',
    md: 'px-3 py-1.5 text-sm font-medium rounded-md',
  }

  const colorClasses = getStatusColor(status)

  return (
    <span className={`inline-flex items-center gap-1 ${sizeClasses[size]} ${colorClasses}`}>
      {/* Status Dot */}
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {getStatusLabel(status)}
    </span>
  )
}
