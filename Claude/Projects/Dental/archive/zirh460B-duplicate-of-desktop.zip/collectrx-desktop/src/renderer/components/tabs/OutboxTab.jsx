import { useState } from 'react'
import DataTable from '../shared/DataTable'
import MetricCard from '../shared/MetricCard'
import StatusBadge from '../shared/StatusBadge'
import { formatDate } from '../../utils/formatters'
import { Mail, MessageSquare, AlertCircle } from 'lucide-react'

export default function OutboxTab() {
  const [activeFilter, setActiveFilter] = useState('all')

  const mockOutbox = [
    {
      id: 1,
      type: 'SMS',
      recipient: 'John Smith',
      messagePreview: 'Payment reminder for outstanding balance',
      status: 'resolved',
      scheduledTime: '2025-04-05 10:00',
      sentTime: '2025-04-05 10:02',
    },
    {
      id: 2,
      type: 'Email',
      recipient: 'SunLife Insurance',
      messagePreview: 'Request for claim status update',
      status: 'resolved',
      scheduledTime: '2025-04-05 09:00',
      sentTime: '2025-04-05 09:05',
    },
    {
      id: 3,
      type: 'SMS',
      recipient: 'Sarah Johnson',
      messagePreview: 'Your treatment plan has been updated',
      status: 'pending',
      scheduledTime: '2025-04-05 14:00',
      sentTime: null,
    },
    {
      id: 4,
      type: 'Email',
      recipient: 'Manulife Insurance',
      messagePreview: 'Follow-up on claim CLM-2025-001',
      status: 'pending',
      scheduledTime: '2025-04-05 15:30',
      sentTime: null,
    },
    {
      id: 5,
      type: 'SMS',
      recipient: 'Michael Brown',
      messagePreview: 'Please confirm receipt of your statement',
      status: 'escalated',
      scheduledTime: '2025-04-04 11:00',
      sentTime: '2025-04-04 11:02',
    },
    {
      id: 6,
      type: 'Email',
      recipient: 'Great West',
      messagePreview: 'Claim documentation request',
      status: 'resolved',
      scheduledTime: '2025-04-04 08:00',
      sentTime: '2025-04-04 08:10',
    },
  ]

  const filteredOutbox = mockOutbox.filter((item) => {
    if (activeFilter === 'all') return true
    if (activeFilter === 'pending') return item.status === 'pending'
    if (activeFilter === 'sent') return item.status === 'resolved'
    if (activeFilter === 'failed') return item.status === 'escalated'
    return true
  })

  const sentToday = mockOutbox.filter((item) => item.sentTime?.includes('2025-04-05')).length
  const pending = mockOutbox.filter((item) => item.status === 'pending').length
  const failed = mockOutbox.filter((item) => item.status === 'escalated').length

  const columns = [
    {
      key: 'type',
      label: 'Type',
      sortKey: 'type',
      render: (value) => {
        const Icon = value === 'SMS' ? MessageSquare : Mail
        return (
          <div className="flex items-center gap-2">
            <Icon className="w-4 h-4 text-emerald-600" />
            <span className="font-medium">{value}</span>
          </div>
        )
      },
    },
    {
      key: 'recipient',
      label: 'Recipient',
      sortKey: 'recipient',
    },
    {
      key: 'messagePreview',
      label: 'Subject/Message',
      sortKey: 'messagePreview',
      render: (value) => (
        <span className="text-gray-700 truncate max-w-xs" title={value}>
          {value}
        </span>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      sortKey: 'status',
      render: (value) => <StatusBadge status={value} />,
    },
    {
      key: 'scheduledTime',
      label: 'Scheduled',
      sortKey: 'scheduledTime',
    },
    {
      key: 'sentTime',
      label: 'Sent',
      sortKey: 'sentTime',
      render: (value) => value || '—',
    },
  ]

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Phase 3 Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-amber-900">Coming Soon - Patient Communication</h3>
          <p className="text-sm text-amber-800 mt-1">
            Full patient communication features including SMS and email campaigns will be available in Phase 2+. This is a preview of the outbox functionality.
          </p>
        </div>
      </div>

      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Communication Outbox</h2>
        <p className="text-sm text-gray-600">View and track all outgoing communications</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Sent Today"
          value={sentToday}
          format="large"
          color="success"
          icon={Mail}
        />
        <MetricCard
          title="Pending"
          value={pending}
          format="large"
          color="warning"
          icon={MessageSquare}
        />
        <MetricCard
          title="Failed"
          value={failed}
          format="large"
          color="danger"
        />
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
        <div className="flex gap-4 border-b border-gray-200 mb-6">
          {[
            { id: 'all', label: 'All' },
            { id: 'pending', label: 'Pending' },
            { id: 'sent', label: 'Sent' },
            { id: 'failed', label: 'Failed' },
          ].map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`pb-3 px-1 font-medium transition-colors border-b-2 ${
                activeFilter === filter.id
                  ? 'border-emerald-600 text-emerald-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              {filter.label}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-hidden -mx-4 -mb-4">
          <DataTable
            columns={columns}
            data={filteredOutbox}
            pageSize={15}
            sortKey="scheduledTime"
            sortDirection="desc"
            emptyMessage={`No ${activeFilter} communications`}
          />
        </div>
      </div>
    </div>
  )
}
