import { useState } from 'react'
import MetricCard from '../shared/MetricCard'
import { formatDate } from '../../utils/formatters'
import { Settings, Database, Bell, Clock, AlertCircle, Check } from 'lucide-react'

export default function AdminTab() {
  const [settings, setSettings] = useState({
    maxCallAttempts: 4,
    minClaimValue: 100,
    callWindowStart: '09:00',
    callWindowEnd: '17:00',
    syncInterval: 30,
    lastSyncTime: '2025-04-05 14:23',
    escalationEmail: 'admin@practice.com',
    pauseAllCalls: false,
    notifyOnEscalation: true,
    notifyOnResolution: false,
  })

  const handleSettingChange = (key, value) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const handleManualSync = () => {
    setSettings((prev) => ({
      ...prev,
      lastSyncTime: new Date().toLocaleString('en-CA', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      }),
    }))
  }

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Admin Settings</h2>
        <p className="text-sm text-gray-600">Configure platform behavior and integrations</p>
      </div>

      {/* System Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="API Uptime"
          value={99.95}
          format="raw"
          color="success"
          subtitle="%"
          trend={0.1}
          trendDirection="up"
          icon={Check}
        />
        <MetricCard
          title="Active Practices"
          value={12}
          color="primary"
          format="large"
          icon={Settings}
        />
        <MetricCard
          title="Total Claims Processed"
          value={4280}
          color="info"
          format="large"
          icon={Database}
        />
      </div>

      {/* Practice Info Card */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-4">Practice Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-600 mb-1">Practice Name</p>
            <p className="text-lg font-semibold text-gray-900">Smile Dental Clinic</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Address</p>
            <p className="text-lg font-semibold text-gray-900">123 Main St, Toronto ON M1A 2B3</p>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Sync Status</p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
              <p className="text-lg font-semibold text-gray-900">Connected</p>
            </div>
          </div>
          <div>
            <p className="text-sm text-gray-600 mb-1">Last Sync</p>
            <p className="text-lg font-semibold text-gray-900">{settings.lastSyncTime}</p>
          </div>
        </div>
      </div>

      {/* Queue Settings */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-6 flex items-center gap-2">
          <Settings className="w-5 h-5 text-emerald-600" />
          Queue Settings
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Max Call Attempts</label>
            <input
              type="number"
              min="1"
              max="10"
              value={settings.maxCallAttempts}
              onChange={(e) => handleSettingChange('maxCallAttempts', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
            <p className="text-xs text-gray-500 mt-1">Number of times to attempt contacting carrier</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Min Claim Value</label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-gray-500">$</span>
              <input
                type="number"
                min="0"
                value={settings.minClaimValue}
                onChange={(e) => handleSettingChange('minClaimValue', parseInt(e.target.value))}
                className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>
            <p className="text-xs text-gray-500 mt-1">Minimum value to queue for calling</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Call Window Start</label>
            <input
              type="time"
              value={settings.callWindowStart}
              onChange={(e) => handleSettingChange('callWindowStart', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Call Window End</label>
            <input
              type="time"
              value={settings.callWindowEnd}
              onChange={(e) => handleSettingChange('callWindowEnd', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Sync Settings */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-6 flex items-center gap-2">
          <Clock className="w-5 h-5 text-emerald-600" />
          Sync Settings
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Sync Interval (seconds)</label>
            <input
              type="number"
              min="10"
              value={settings.syncInterval}
              onChange={(e) => handleSettingChange('syncInterval', parseInt(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Last Sync Time</label>
            <input
              type="text"
              disabled
              value={settings.lastSyncTime}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-500 bg-gray-50 cursor-not-allowed"
            />
          </div>
        </div>
        <button
          onClick={handleManualSync}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors"
        >
          Manual Sync Now
        </button>
      </div>

      {/* Notification Settings */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-6 flex items-center gap-2">
          <Bell className="w-5 h-5 text-emerald-600" />
          Notifications
        </h3>
        <div className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Escalation Email</label>
            <input
              type="email"
              value={settings.escalationEmail}
              onChange={(e) => handleSettingChange('escalationEmail', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
            <p className="text-xs text-gray-500 mt-1">Email for escalation alerts</p>
          </div>

          {[
            { key: 'notifyOnEscalation', label: 'Notify on Escalation', description: 'Send alert when claims are escalated' },
            { key: 'notifyOnResolution', label: 'Notify on Resolution', description: 'Send alert when claims are resolved' },
          ].map((option) => (
            <div key={option.key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div>
                <label className="text-sm font-medium text-gray-700">{option.label}</label>
                <p className="text-xs text-gray-600 mt-1">{option.description}</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings[option.key]}
                  onChange={(e) => handleSettingChange(option.key, e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-emerald-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600" />
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <h3 className="text-md font-semibold text-red-900 mb-4 flex items-center gap-2">
          <AlertCircle className="w-5 h-5" />
          Danger Zone
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-red-200">
            <div>
              <label className="text-sm font-medium text-gray-900">Pause All Calls</label>
              <p className="text-xs text-gray-600 mt-1">Stop all automated calling operations immediately</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.pauseAllCalls}
                onChange={(e) => handleSettingChange('pauseAllCalls', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-red-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600" />
            </label>
          </div>
        </div>
      </div>

      {/* Save Button */}
      <button className="w-full md:w-auto px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors">
        Save Settings
      </button>
    </div>
  )
}
