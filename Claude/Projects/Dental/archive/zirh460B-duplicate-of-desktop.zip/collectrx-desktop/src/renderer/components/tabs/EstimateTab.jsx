import { useState } from 'react'
import MetricCard from '../shared/MetricCard'
import DataTable from '../shared/DataTable'
import { formatCurrency, formatPercentage } from '../../utils/formatters'
import { Calendar, AlertCircle, CheckCircle, TrendingUp } from 'lucide-react'

export default function EstimateTab() {
  const [cdtCode, setCdtCode] = useState('')
  const [selectedCarrier, setSelectedCarrier] = useState('')
  const [annualMaxRemaining, setAnnualMaxRemaining] = useState('')
  const [showEstimateResults, setShowEstimateResults] = useState(false)

  const commonCodes = [
    { code: 'D1110', label: 'Prophy - Adult' },
    { code: 'D1120', label: 'Prophy - Child' },
    { code: 'D2140', label: 'Amalgam - One Surface' },
    { code: 'D2150', label: 'Amalgam - Two Surfaces' },
    { code: 'D2160', label: 'Amalgam - Three Surfaces' },
    { code: 'D2394', label: 'Resin - One Surface' },
    { code: 'D2394', label: 'Resin - Two Surfaces' },
    { code: 'D3110', label: 'Endodontic Therapy' },
    { code: 'D4210', label: 'Periodontal Scaling' },
  ]

  const estimateResults = {
    insurancePortion: 450,
    patientPortion: 150,
    coveragePercentage: 75,
    confidenceLevel: 92,
  }

  const recentEstimates = [
    { id: 'EST-001', patient: 'John Smith', code: 'D2150', carrier: 'SunLife', insurancePortion: 450, patientPortion: 150, createdDate: '2025-04-04' },
    { id: 'EST-002', patient: 'Sarah Johnson', code: 'D3110', carrier: 'Manulife', insurancePortion: 950, patientPortion: 50, createdDate: '2025-04-03' },
    { id: 'EST-003', patient: 'Michael Brown', code: 'D1110', carrier: 'Great West', insurancePortion: 100, patientPortion: 200, createdDate: '2025-04-02' },
    { id: 'EST-004', patient: 'Emily Davis', code: 'D2394', carrier: 'Desjardins', insurancePortion: 350, patientPortion: 100, createdDate: '2025-04-01' },
    { id: 'EST-005', patient: 'Robert Williams', code: 'D4210', carrier: 'SunLife', insurancePortion: 200, patientPortion: 80, createdDate: '2025-03-31' },
  ]

  const estimateColumns = [
    { key: 'id', label: 'Estimate ID', sortKey: 'id' },
    { key: 'patient', label: 'Patient', sortKey: 'patient' },
    { key: 'code', label: 'CDT Code', sortKey: 'code' },
    { key: 'carrier', label: 'Carrier', sortKey: 'carrier' },
    { key: 'insurancePortion', label: 'Insurance', sortKey: 'insurancePortion', render: (v) => formatCurrency(v) },
    { key: 'patientPortion', label: 'Patient', sortKey: 'patientPortion', render: (v) => formatCurrency(v) },
    { key: 'createdDate', label: 'Created', sortKey: 'createdDate' },
  ]

  const handleGenerateEstimate = () => {
    if (cdtCode && selectedCarrier) {
      setShowEstimateResults(true)
    }
  }

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Phase 3 Banner */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-amber-900">Coming Soon - Phase 3</h3>
          <p className="text-sm text-amber-800 mt-1">
            Full estimate generation with real-time coverage lookups will be available in Phase 3. Current functionality shows estimated results.
          </p>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Pending Estimates"
          value={32}
          color="info"
          format="large"
          icon={Calendar}
          trend={2}
          trendDirection="up"
        />
        <MetricCard
          title="Total Estimated Value"
          value={85000}
          format="currency"
          color="primary"
        />
        <MetricCard
          title="Acceptance Rate"
          value={68.5}
          format="raw"
          color="success"
          subtitle="% acceptance"
        />
      </div>

      {/* Form Section */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-6">Create New Estimate</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          {/* CDT Code Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">CDT Code</label>
            <select
              value={cdtCode}
              onChange={(e) => setCdtCode(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="">Select a CDT code...</option>
              {commonCodes.map((item) => (
                <option key={item.code} value={item.code}>
                  {item.code} - {item.label}
                </option>
              ))}
            </select>
          </div>

          {/* Carrier Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Insurance Carrier</label>
            <select
              value={selectedCarrier}
              onChange={(e) => setSelectedCarrier(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="">Select a carrier...</option>
              <option value="sunlife">SunLife</option>
              <option value="manulife">Manulife</option>
              <option value="great_west">Great West</option>
              <option value="desjardins">Desjardins</option>
            </select>
          </div>

          {/* Annual Max Remaining */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Annual Max Remaining</label>
            <input
              type="number"
              value={annualMaxRemaining}
              onChange={(e) => setAnnualMaxRemaining(e.target.value)}
              placeholder="$1,000"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>

          {/* Patient Coverage Info */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Patient Coverage %</label>
            <input
              type="number"
              placeholder="80"
              min="0"
              max="100"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={handleGenerateEstimate}
          disabled={!cdtCode || !selectedCarrier}
          className="w-full md:w-auto px-6 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-300 text-white rounded-lg font-medium transition-colors"
        >
          Generate Estimate
        </button>
      </div>

      {/* Estimate Results */}
      {showEstimateResults && (
        <div className="bg-gradient-to-br from-emerald-50 to-white rounded-lg border border-emerald-200 shadow-sm p-6">
          <h3 className="text-md font-semibold text-gray-900 mb-6 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-emerald-600" />
            Estimate Results
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Insurance Portion */}
            <div className="bg-white rounded-lg p-4 border border-emerald-100">
              <p className="text-sm text-gray-600 mb-2">Estimated Insurance Portion</p>
              <p className="text-3xl font-bold text-emerald-600">{formatCurrency(estimateResults.insurancePortion)}</p>
            </div>

            {/* Patient Portion */}
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <p className="text-sm text-gray-600 mb-2">Estimated Patient Portion</p>
              <p className="text-3xl font-bold text-gray-900">{formatCurrency(estimateResults.patientPortion)}</p>
            </div>

            {/* Coverage Percentage */}
            <div className="bg-white rounded-lg p-4 border border-emerald-100">
              <p className="text-sm text-gray-600 mb-2">Coverage Percentage</p>
              <p className="text-3xl font-bold text-emerald-600">{estimateResults.coveragePercentage}%</p>
            </div>

            {/* Confidence Level */}
            <div className="bg-white rounded-lg p-4 border border-gray-200">
              <p className="text-sm text-gray-600 mb-2">Confidence Level</p>
              <p className="text-3xl font-bold text-gray-900">{estimateResults.confidenceLevel}%</p>
            </div>
          </div>
        </div>
      )}

      {/* Recent Estimates */}
      <div>
        <h3 className="text-md font-semibold text-gray-900 mb-4">Recent Estimates</h3>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <DataTable
            columns={estimateColumns}
            data={recentEstimates}
            pageSize={10}
            sortKey="createdDate"
            sortDirection="desc"
            emptyMessage="No estimates generated yet"
          />
        </div>
      </div>
    </div>
  )
}
