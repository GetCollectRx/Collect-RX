import { useState } from 'react'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import MetricCard from '../shared/MetricCard'
import DataTable from '../shared/DataTable'
import { useApi } from '../../hooks/useApi'
import { formatCurrency, getAgingBucketColor, getAgingBucketLabel } from '../../utils/formatters'
import { Download, TrendingDown } from 'lucide-react'

export default function BalancesTab() {
  const { data: agingReport } = useApi('aging:report')
  const [dateRange, setDateRange] = useState('30d')
  const [selectedCarrier, setSelectedCarrier] = useState('all')

  const mockAgingReport = agingReport || {
    '0-29': 28000,
    '30-59': 15000,
    '60-89': 9000,
    '90-119': 5000,
    '120+': 12000,
  }

  const totalAging = Object.values(mockAgingReport).reduce((sum, val) => sum + val, 0)

  // Mock aging trend over time
  const trendData = [
    { date: 'Week 1', current: 28000, '30-59': 14000, '60-89': 8000, '90-119': 4000, '120+': 10000 },
    { date: 'Week 2', current: 27500, '30-59': 14500, '60-89': 8500, '90-119': 4500, '120+': 11000 },
    { date: 'Week 3', current: 26800, '30-59': 15200, '60-89': 9000, '90-119': 5000, '120+': 12000 },
    { date: 'Week 4', current: 28000, '30-59': 15000, '60-89': 9000, '90-119': 5000, '120+': 12000 },
  ]

  // Mock carrier aging breakdown
  const carrierData = [
    { carrier: 'SunLife', '0-29': 8500, '30-59': 4200, '60-89': 2100, '90-119': 1200, '120+': 3500 },
    { carrier: 'Manulife', '0-29': 7200, '30-59': 3800, '60-89': 1900, '90-119': 1100, '120+': 2800 },
    { carrier: 'Great West', '0-29': 6500, '30-59': 3400, '60-89': 1800, '90-119': 950, '120+': 2400 },
    { carrier: 'Desjardins', '0-29': 3800, '30-59': 2200, '60-89': 1500, '90-119': 800, '120+': 1800 },
    { carrier: 'Other', '0-29': 2000, '30-59': 1400, '60-89': 700, '90-119': 450, '120+': 1500 },
  ]

  const carrierColumns = [
    { key: 'carrier', label: 'Carrier', sortKey: 'carrier' },
    { key: '0-29', label: 'Current (0-29)', sortKey: '0-29', render: (v) => formatCurrency(v) },
    { key: '30-59', label: '30-59 Days', sortKey: '30-59', render: (v) => formatCurrency(v) },
    { key: '60-89', label: '60-89 Days', sortKey: '60-89', render: (v) => formatCurrency(v) },
    { key: '90-119', label: '90-119 Days', sortKey: '90-119', render: (v) => formatCurrency(v) },
    { key: '120+', label: '120+ Days', sortKey: '120+', render: (v) => formatCurrency(v) },
    {
      key: 'total',
      label: 'Total',
      render: (_, row) => formatCurrency(row['0-29'] + row['30-59'] + row['60-89'] + row['90-119'] + row['120+']),
    },
  ]

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Insurance Aging Report</h2>
        <p className="text-sm text-gray-600">Outstanding claims by aging bucket</p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Total Outstanding"
          value={totalAging}
          format="currency"
          color="primary"
          trend={2}
          trendDirection="up"
          sparkline={[55000, 56500, 58000, 60000, 61000, 62000, 69000]}
        />
        <MetricCard
          title="Highest Risk (120+)"
          value={mockAgingReport['120+']}
          format="currency"
          color="danger"
          subtitle="Over 120 days old"
        />
        <MetricCard
          title="Current Claims"
          value={mockAgingReport['0-29']}
          format="currency"
          color="success"
          subtitle="0-29 days"
        />
      </div>

      {/* Aging Summary Bars */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-6">Aging Distribution</h3>
        <div className="space-y-4">
          {['0-29', '30-59', '60-89', '90-119', '120+'].map((bucket) => {
            const amount = mockAgingReport[bucket]
            const percentage = (amount / totalAging) * 100 || 0
            const colorClass = getAgingBucketColor(bucket)

            return (
              <div key={bucket}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">
                    {getAgingBucketLabel(bucket)}
                  </span>
                  <span className="text-sm font-bold text-gray-900">
                    {formatCurrency(amount)} ({percentage.toFixed(1)}%)
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full transition-all ${colorClass}`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Trend Chart */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-4">Aging Trend</h3>
        <ResponsiveContainer width="100%" height={250}>
          <AreaChart data={trendData}>
            <defs>
              <linearGradient id="colorCurrent" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="date" stroke="#6b7280" />
            <YAxis stroke="#6b7280" />
            <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }} />
            <Area type="monotone" dataKey="current" stroke="#10B981" fill="url(#colorCurrent)" name="Current (0-29)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="60d">Last 60 Days</option>
              <option value="90d">Last 90 Days</option>
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">Carrier</label>
            <select
              value={selectedCarrier}
              onChange={(e) => setSelectedCarrier(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
            >
              <option value="all">All Carriers</option>
              <option value="sunlife">SunLife</option>
              <option value="manulife">Manulife</option>
              <option value="great_west">Great West</option>
              <option value="desjardins">Desjardins</option>
            </select>
          </div>
          <div className="flex items-end">
            <button
              disabled
              className="w-full md:w-auto px-4 py-2 bg-gray-100 text-gray-500 rounded-lg font-medium cursor-not-allowed flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              Export (Coming Soon)
            </button>
          </div>
        </div>
      </div>

      {/* Carrier Breakdown Table */}
      <div>
        <h3 className="text-md font-semibold text-gray-900 mb-4">Carrier Aging Breakdown</h3>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <DataTable
            columns={carrierColumns}
            data={carrierData}
            pageSize={10}
            sortKey="carrier"
            emptyMessage="No carrier data available"
          />
        </div>
      </div>
    </div>
  )
}
