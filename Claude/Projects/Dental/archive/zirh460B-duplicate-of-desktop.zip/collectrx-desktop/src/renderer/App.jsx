import { useState, useEffect } from 'react'
import Navigation from './components/navigation/Navigation'
import DashboardTab from './components/tabs/DashboardTab'
import AnalyticsTab from './components/tabs/AnalyticsTab'
import BalancesTab from './components/tabs/BalancesTab'
import PatientARTab from './components/tabs/PatientARTab'
import EstimateTab from './components/tabs/EstimateTab'
import OutboxTab from './components/tabs/OutboxTab'
import AdminTab from './components/tabs/AdminTab'
import CarrierPriorityPanel from './components/carrier-priority/CarrierPriorityPanel'

const TABS = [
  { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard' },
  { id: 'analytics', label: 'Analytics', icon: 'BarChart3' },
  { id: 'balances', label: 'Balances', icon: 'TrendingUp' },
  { id: 'patient-ar', label: 'Patient AR', icon: 'Users' },
  { id: 'estimate', label: 'Estimate', icon: 'FileText' },
  { id: 'outbox', label: 'Outbox', icon: 'Send' },
  { id: 'admin', label: 'Admin', icon: 'Settings' },
]

const TAB_COMPONENTS = {
  dashboard: DashboardTab,
  analytics: AnalyticsTab,
  balances: BalancesTab,
  'patient-ar': PatientARTab,
  estimate: EstimateTab,
  outbox: OutboxTab,
  admin: AdminTab,
}

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard')
  const [syncStatus, setSyncStatus] = useState('idle')
  const [showPriorityPanel, setShowPriorityPanel] = useState(false)

  useEffect(() => {
    // Listen for sync status changes from Electron main process
    if (window.collectrx?.onSyncStatus) {
      window.collectrx.onSyncStatus((status) => setSyncStatus(status))
    }
  }, [])

  const ActiveComponent = TAB_COMPONENTS[activeTab]

  const syncIndicator = {
    idle: { color: 'bg-emerald-500', label: 'Synced' },
    syncing: { color: 'bg-amber-500 animate-pulse', label: 'Syncing...' },
    error: { color: 'bg-red-500', label: 'Sync Error' },
  }

  const currentSync = syncIndicator[syncStatus] || syncIndicator.idle

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar Navigation */}
      <Navigation
        tabs={TABS}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenPriority={() => setShowPriorityPanel(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="border-b border-gray-200 bg-white px-8 py-4 flex items-center justify-between shrink-0">
          <div>
            <h1 className="text-xl font-bold text-gray-900 tracking-tight">CollectRx</h1>
            <p className="text-sm text-gray-500">Dental Insurance AR Automation</p>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setShowPriorityPanel(true)}
              className="text-sm text-gray-600 hover:text-emerald-600 font-medium transition-colors"
            >
              Carrier Priority
            </button>
            <div className="h-4 w-px bg-gray-200" />
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${currentSync.color}`} />
              <span className="text-sm text-gray-500">{currentSync.label}</span>
            </div>
          </div>
        </header>

        {/* Tab Content */}
        <main className="flex-1 overflow-auto">
          <ActiveComponent />
        </main>
      </div>

      {/* Carrier Priority Slide-over Panel */}
      {showPriorityPanel && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div
            className="absolute inset-0 bg-black/20 backdrop-blur-sm"
            onClick={() => setShowPriorityPanel(false)}
          />
          <div className="relative w-full max-w-lg bg-white shadow-2xl border-l border-gray-200 overflow-y-auto animate-slide-in">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between z-10">
              <h2 className="text-lg font-semibold text-gray-900">Carrier Priority</h2>
              <button
                onClick={() => setShowPriorityPanel(false)}
                className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <CarrierPriorityPanel />
          </div>
        </div>
      )}
    </div>
  )
}
