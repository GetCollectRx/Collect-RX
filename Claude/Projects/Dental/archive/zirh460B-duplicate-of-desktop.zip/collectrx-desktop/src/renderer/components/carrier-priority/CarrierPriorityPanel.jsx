import React, { useState, useEffect } from 'react'
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core'
import {
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from '@dnd-kit/sortable'
import { CSS } from '@dnd-kit/utilities'
import {
  GripVertical,
  Check,
  Save,
  ArrowUpDown,
} from 'lucide-react'
import { useApi } from '../../hooks/useApi'
import { formatCurrency } from '../../utils/formatters'

const CARRIERS = [
  { id: 'sunlife_private', name: 'Sun Life', color: '#DC2626' },
  { id: 'great_west', name: 'Great-West Life', color: '#2563EB' },
  { id: 'manulife', name: 'Manulife', color: '#7C3AED' },
  { id: 'green_shield', name: 'Green Shield Canada', color: '#059669' },
  { id: 'rbc_insurance', name: 'RBC Insurance', color: '#0891B2' },
  { id: 'telus_adjudicare', name: 'TELUS AdjudiCare', color: '#D97706' },
]

/**
 * SortableCarrierCard - Individual carrier card with drag handle
 */
function SortableCarrierCard({
  carrier,
  carrierStats,
  isEnabled,
  onToggleEnable,
  isDragging,
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging,
  } = useSortable({ id: carrier.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isSortableDragging ? 0.5 : 1,
  }

  const stats = carrierStats?.[carrier.id] || {}
  const outstanding = stats.outstanding_amount || 0
  const claimsCount = stats.outstanding_claims || 0
  const confidence = stats.confidence_score || 0

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`
        bg-white border border-gray-200 rounded-lg p-4 mb-3
        transition-all duration-200
        ${isSortableDragging ? 'shadow-lg ring-2 ring-emerald-300 scale-105' : 'shadow-sm hover:shadow-md'}
        ${!isEnabled ? 'opacity-60 bg-gray-50' : ''}
      `}
    >
      <div className="flex items-center gap-3">
        {/* Drag Handle */}
        <div
          {...attributes}
          {...listeners}
          className="flex-shrink-0 cursor-grab active:cursor-grabbing p-1 hover:bg-gray-100 rounded transition-colors"
          title="Drag to reorder"
        >
          <GripVertical className="w-5 h-5 text-gray-400" />
        </div>

        {/* Carrier Info */}
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <div
              className="w-3 h-3 rounded-full flex-shrink-0"
              style={{ backgroundColor: carrier.color }}
            />
            <h3 className="font-semibold text-sm text-gray-900">
              {carrier.name}
            </h3>
          </div>
          <p className="text-xs text-gray-500 font-mono">
            {carrier.id}
          </p>
        </div>

        {/* Enable Toggle */}
        <button
          onClick={() => onToggleEnable(carrier.id)}
          className={`
            flex-shrink-0 w-6 h-6 rounded border-2 flex items-center justify-center
            transition-all duration-200
            ${
              isEnabled
                ? 'bg-emerald-500 border-emerald-500 hover:bg-emerald-600'
                : 'border-gray-300 bg-white hover:border-gray-400'
            }
          `}
        >
          {isEnabled && <Check className="w-4 h-4 text-white" />}
        </button>
      </div>

      {/* Stats Row */}
      <div className="mt-3 grid grid-cols-3 gap-3 text-xs">
        <div className="bg-gray-50 rounded p-2">
          <p className="text-gray-500 font-medium">Claims</p>
          <p className="text-lg font-bold text-gray-900 mt-0.5">
            {claimsCount}
          </p>
        </div>

        <div className="bg-gray-50 rounded p-2">
          <p className="text-gray-500 font-medium">Outstanding</p>
          <p className="text-sm font-bold text-gray-900 mt-0.5 truncate">
            {formatCurrency(outstanding)}
          </p>
        </div>

        <div className="bg-gray-50 rounded p-2">
          <p className="text-gray-500 font-medium">Confidence</p>
          <p className="text-lg font-bold text-gray-900 mt-0.5">
            {Math.round(confidence * 100)}%
          </p>
        </div>
      </div>

      {/* Confidence Progress Bar */}
      <div className="mt-2">
        <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500 transition-all duration-300"
            style={{ width: `${confidence * 100}%` }}
          />
        </div>
      </div>
    </div>
  )
}

/**
 * CarrierPriorityPanel - Main component for drag-and-drop carrier prioritization
 */
export default function CarrierPriorityPanel() {
  const { data: carrierStats, loading, error } = useApi('carrier:stats', {
    poll: true,
    pollInterval: 30000,
  })

  const [carriers, setCarriers] = useState(CARRIERS)
  const [enabledCarriers, setEnabledCarriers] = useState(
    new Set(CARRIERS.map((c) => c.id))
  )
  const [hasChanges, setHasChanges] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [saveSuccess, setSaveSuccess] = useState(false)
  const [saveError, setSaveError] = useState(null)

  const sensors = useSensors(
    useSensor(PointerSensor, {
      distance: 8,
    })
  )

  const handleDragEnd = (event) => {
    const { active, over } = event

    if (over && active.id !== over.id) {
      setCarriers((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over.id)
        return arrayMove(items, oldIndex, newIndex)
      })
      setHasChanges(true)
      setSaveSuccess(false)
    }
  }

  const handleToggleEnable = (carrierId) => {
    const newEnabled = new Set(enabledCarriers)
    if (newEnabled.has(carrierId)) {
      newEnabled.delete(carrierId)
    } else {
      newEnabled.add(carrierId)
    }
    setEnabledCarriers(newEnabled)
    setHasChanges(true)
    setSaveSuccess(false)
  }

  const handleSave = async () => {
    setIsSaving(true)
    setSaveError(null)
    setSaveSuccess(false)

    try {
      const payload = {
        priority: carriers.map((c) => c.id),
        enabled: Array.from(enabledCarriers),
      }

      if (window.collectrx && window.collectrx.updateCarrierPriority) {
        await window.collectrx.updateCarrierPriority(payload)
        setSaveSuccess(true)
        setHasChanges(false)

        // Auto-dismiss success message after 3 seconds
        setTimeout(() => setSaveSuccess(false), 3000)
      } else {
        console.warn('updateCarrierPriority not available, using mock save')
        // Mock save for development
        await new Promise((resolve) => setTimeout(resolve, 800))
        setSaveSuccess(true)
        setHasChanges(false)
        setTimeout(() => setSaveSuccess(false), 3000)
      }
    } catch (err) {
      setSaveError(err.message || 'Failed to save carrier priority')
      console.error('Error saving carrier priority:', err)
    } finally {
      setIsSaving(false)
    }
  }

  // Skeleton loading state
  if (loading && !carrierStats) {
    return (
      <div className="space-y-4">
        <div className="h-8 w-48 bg-gray-200 rounded animate-pulse" />
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="h-32 bg-gray-200 rounded-lg animate-pulse"
          />
        ))}
      </div>
    )
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <ArrowUpDown className="w-5 h-5 text-emerald-600" />
          <h2 className="text-lg font-bold text-gray-900">
            Carrier Call Priority
          </h2>
        </div>
        <p className="text-sm text-gray-600">
          Drag carriers to reorder call priority. Disabled carriers will not be
          called.
        </p>
      </div>

      {/* Error State */}
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
          Error loading carrier data. Please try again.
        </div>
      )}

      {/* Success Notification */}
      {saveSuccess && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center gap-2 text-sm text-emerald-700 animate-pulse">
          <Check className="w-4 h-4 flex-shrink-0" />
          <span>Carrier priority saved successfully</span>
        </div>
      )}

      {/* Save Error Notification */}
      {saveError && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
          {saveError}
        </div>
      )}

      {/* Draggable List */}
      <div className="mb-6">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={carriers.map((c) => c.id)}
            strategy={verticalListSortingStrategy}
          >
            {carriers.map((carrier) => (
              <SortableCarrierCard
                key={carrier.id}
                carrier={carrier}
                carrierStats={carrierStats}
                isEnabled={enabledCarriers.has(carrier.id)}
                onToggleEnable={handleToggleEnable}
              />
            ))}
          </SortableContext>
        </DndContext>
      </div>

      {/* Footer with Save Button */}
      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
        <div className="text-sm text-gray-600">
          {enabledCarriers.size === CARRIERS.length
            ? 'All carriers enabled'
            : `${enabledCarriers.size} of ${CARRIERS.length} carriers enabled`}
        </div>

        <button
          onClick={handleSave}
          disabled={!hasChanges || isSaving}
          className={`
            inline-flex items-center gap-2 px-4 py-2 rounded-lg font-medium
            text-sm transition-all duration-200
            ${
              hasChanges && !isSaving
                ? 'bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }
          `}
        >
          <Save className="w-4 h-4" />
          {isSaving ? 'Saving...' : 'Save Priority'}
        </button>
      </div>

      {/* Info Section */}
      <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700">
        <p className="font-medium mb-1">How Priority Works</p>
        <ul className="space-y-1 list-disc list-inside">
          <li>Higher carriers in the list are called first</li>
          <li>Only enabled carriers are included in the queue</li>
          <li>Confidence score shows AI success rate with each carrier</li>
        </ul>
      </div>
    </div>
  )
}
