import { useState, useMemo } from 'react'

export default function DataTable({
  columns,
  data = [],
  loading = false,
  onRowClick,
  pageSize = 20,
  sortKey: initialSortKey,
  sortDirection: initialSortDirection = 'asc',
  emptyMessage = 'No data available',
}) {
  const [sortKey, setSortKey] = useState(initialSortKey || null)
  const [sortDirection, setSortDirection] = useState(initialSortDirection)
  const [currentPage, setCurrentPage] = useState(1)

  // Sort data
  const sortedData = useMemo(() => {
    if (!sortKey) return data
    return [...data].sort((a, b) => {
      const aVal = a[sortKey]
      const bVal = b[sortKey]

      if (aVal === null || aVal === undefined) return 1
      if (bVal === null || bVal === undefined) return -1

      if (typeof aVal === 'string') {
        return sortDirection === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal)
      }

      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal
    })
  }, [data, sortKey, sortDirection])

  // Paginate data
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return sortedData.slice(start, start + pageSize)
  }, [sortedData, currentPage, pageSize])

  const totalPages = Math.ceil(sortedData.length / pageSize)

  const handleSort = (key) => {
    if (sortKey === key) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key)
      setSortDirection('asc')
    }
    setCurrentPage(1)
  }

  const SortIcon = ({ columnKey }) => {
    if (sortKey !== columnKey) {
      return (
        <svg className="w-4 h-4 opacity-30" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4" />
        </svg>
      )
    }
    return sortDirection === 'asc' ? (
      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 5v14m0 0l-7-7m7 7l7-7" />
      </svg>
    ) : (
      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 19V5m0 0l7 7m-7-7l-7 7" />
      </svg>
    )
  }

  // Loading skeleton
  if (loading) {
    return (
      <div className="p-6">
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div
              key={i}
              className="h-12 bg-surface-secondary rounded animate-pulse"
            />
          ))}
        </div>
      </div>
    )
  }

  // Empty state
  if (!data.length) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-center">
          <svg
            className="w-12 h-12 text-tertiary mx-auto mb-3"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
            />
          </svg>
          <p className="text-secondary font-medium">{emptyMessage}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Table Container */}
      <div className="flex-1 overflow-x-auto">
        <table className="w-full">
          <thead className="sticky top-0 bg-surface-secondary border-b border-subtle">
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key || col.label}
                  onClick={() => col.sortKey && handleSort(col.sortKey)}
                  className={`px-6 py-4 text-left text-xs font-semibold text-secondary uppercase tracking-wider ${
                    col.sortKey ? 'cursor-pointer hover:bg-surface-tertiary' : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {col.label}
                    {col.sortKey && <SortIcon columnKey={col.sortKey} />}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-subtle">
            {paginatedData.map((row, rowIdx) => (
              <tr
                key={row.id || rowIdx}
                onClick={() => onRowClick?.(row)}
                className={`transition-colors ${
                  onRowClick
                    ? 'hover:bg-surface-secondary cursor-pointer'
                    : ''
                }`}
              >
                {columns.map((col) => (
                  <td
                    key={col.key || col.label}
                    className="px-6 py-4 text-sm text-primary"
                  >
                    {col.render ? col.render(row[col.key], row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="border-t border-subtle bg-surface-secondary px-6 py-4 flex items-center justify-between">
          <div className="text-sm text-secondary">
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, sortedData.length)} of{' '}
            {sortedData.length}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              className="px-3 py-2 text-sm font-medium rounded border border-subtle text-secondary hover:bg-surface disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <div className="flex items-center gap-1">
              {[...Array(totalPages)].map((_, i) => {
                const pageNum = i + 1
                const isNear = Math.abs(pageNum - currentPage) <= 1
                const isFirst = pageNum === 1
                const isLast = pageNum === totalPages

                if (!isNear && !isFirst && !isLast) {
                  if (pageNum === 2 || pageNum === totalPages - 1) {
                    return <span key={pageNum} className="text-secondary">...</span>
                  }
                  return null
                }

                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`w-8 h-8 text-sm font-medium rounded border transition-colors ${
                      pageNum === currentPage
                        ? 'bg-primary text-white border-primary'
                        : 'border-subtle text-secondary hover:bg-surface-secondary'
                    }`}
                  >
                    {pageNum}
                  </button>
                )
              })}
            </div>
            <button
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-2 text-sm font-medium rounded border border-subtle text-secondary hover:bg-surface disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
