import { formatCurrency, formatPercentage, formatLargeNumber } from '../../utils/formatters'

export default function MetricCard({
  title,
  value,
  trend,
  trendDirection,
  icon: Icon,
  color = 'primary',
  subtitle,
  sparkline,
  format = 'number',
}) {
  const getColorClasses = () => {
    const colors = {
      primary: 'text-primary border-primary/10 bg-emerald-50/30',
      danger: 'text-danger border-red-200 bg-red-50/30',
      warning: 'text-warning border-amber-200 bg-amber-50/30',
      info: 'text-info border-blue-200 bg-blue-50/30',
      success: 'text-success border-emerald-200 bg-emerald-50/30',
    }
    return colors[color] || colors.primary
  }

  const getValueFormatted = () => {
    switch (format) {
      case 'currency':
        return formatCurrency(value)
      case 'percentage':
        return formatPercentage(value)
      case 'large':
        return formatLargeNumber(value)
      case 'raw':
        return value
      default:
        return value?.toLocaleString?.() || value
    }
  }

  const getTrendIcon = () => {
    if (!trend) return null
    if (trendDirection === 'up') {
      return (
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M13 7h8m0 0v8m0-8L5.257 18.743M5 5h8v8"
          />
        </svg>
      )
    } else {
      return (
        <svg
          className="w-4 h-4"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M13 17h8m0 0v-8m0 8L5.257 5.257M5 19h8v-8"
          />
        </svg>
      )
    }
  }

  return (
    <div
      className={`rounded-lg border p-6 transition-all hover:shadow-md ${getColorClasses()}`}
    >
      {/* Header with Icon and Title */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <p className="text-sm font-medium text-secondary">{title}</p>
          {subtitle && <p className="text-xs text-tertiary mt-1">{subtitle}</p>}
        </div>
        {Icon && (
          <Icon className={`w-5 h-5 text-primary flex-shrink-0 ml-2`} />
        )}
      </div>

      {/* Main Value */}
      <div className="mb-4">
        <div className="text-3xl font-bold text-primary tracking-tight">
          {getValueFormatted()}
        </div>
      </div>

      {/* Trend Section */}
      {trend && (
        <div className="flex items-center gap-2 pt-4 border-t border-current border-opacity-10">
          <div className={`flex items-center gap-1 ${trendDirection === 'up' ? 'text-success' : 'text-danger'}`}>
            {getTrendIcon()}
            <span className="text-sm font-medium">{Math.abs(trend)}%</span>
          </div>
          <span className="text-xs text-secondary">vs last period</span>
        </div>
      )}

      {/* Sparkline */}
      {sparkline && (
        <div className="mt-4 h-12 flex items-end gap-1 opacity-75">
          {sparkline.map((value, idx) => (
            <div
              key={idx}
              className="flex-1 bg-current rounded-sm opacity-40 hover:opacity-60 transition-opacity"
              style={{
                height: `${(value / Math.max(...sparkline)) * 100}%`,
                minHeight: '2px',
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}
