/**
 * Format amount as Canadian dollars
 */
export function formatCurrency(amount) {
  if (amount === null || amount === undefined) return '$0.00'
  return new Intl.NumberFormat('en-CA', {
    style: 'currency',
    currency: 'CAD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

/**
 * Format date in readable format (e.g., "Jan 15, 2025")
 */
export function formatDate(date) {
  if (!date) return ''
  const d = new Date(date)
  return new Intl.DateTimeFormat('en-CA', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  }).format(d)
}

/**
 * Format as percentage (e.g., "42.5%")
 */
export function formatPercentage(value) {
  if (value === null || value === undefined) return '0%'
  const num = typeof value === 'string' ? parseFloat(value) : value
  return `${Math.round(num * 10) / 10}%`
}

/**
 * Format claim age (e.g., "32 days")
 */
export function formatClaimAge(days) {
  if (days === null || days === undefined) return '0 days'
  if (days === 1) return '1 day'
  return `${days} days`
}

/**
 * Get Tailwind color class for aging bucket
 */
export function getAgingBucketColor(bucket) {
  const colorMap = {
    '0-29': 'text-emerald-600 bg-emerald-50',
    '30-59': 'text-amber-600 bg-amber-50',
    '60-89': 'text-orange-600 bg-orange-50',
    '90-119': 'text-red-600 bg-red-50',
    '120+': 'text-red-900 bg-red-50',
  }
  return colorMap[bucket] || 'text-gray-600 bg-gray-50'
}

/**
 * Get human-readable label for aging bucket
 */
export function getAgingBucketLabel(bucket) {
  const labelMap = {
    '0-29': 'Current',
    '30-59': '30-59 days',
    '60-89': '60-89 days',
    '90-119': '90-119 days',
    '120+': '120+ days',
  }
  return labelMap[bucket] || bucket
}

/**
 * Get color classes for claim status
 */
export function getStatusColor(status) {
  const colorMap = {
    queued: 'text-blue-600 bg-blue-50',
    in_progress: 'text-amber-600 bg-amber-50',
    resolved: 'text-emerald-600 bg-emerald-50',
    escalated: 'text-red-600 bg-red-50',
    paused: 'text-gray-600 bg-gray-50',
    excluded: 'text-gray-400 bg-gray-50',
  }
  return colorMap[status] || 'text-gray-600 bg-gray-50'
}

/**
 * Get human-readable status label
 */
export function getStatusLabel(status) {
  const labelMap = {
    queued: 'Queued',
    in_progress: 'In Progress',
    resolved: 'Resolved',
    escalated: 'Escalated',
    paused: 'Paused',
    excluded: 'Excluded',
  }
  return labelMap[status] || status
}

/**
 * Truncate text to max length with ellipsis
 */
export function truncateText(text, maxLength = 50) {
  if (!text) return ''
  if (text.length <= maxLength) return text
  return `${text.slice(0, maxLength - 3)}...`
}

/**
 * Format large numbers with abbreviations (e.g., "1.2M", "340K")
 */
export function formatLargeNumber(num) {
  if (num === null || num === undefined) return '0'
  if (num >= 1000000) {
    return `${(num / 1000000).toFixed(1)}M`
  }
  if (num >= 1000) {
    return `${(num / 1000).toFixed(1)}K`
  }
  return num.toString()
}

/**
 * Parse currency string back to number
 */
export function parseCurrency(str) {
  if (!str) return 0
  return parseFloat(str.replace(/[^0-9.-]+/g, ''))
}
