import { useState, useMemo } from 'react'
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import { useApi } from '../../hooks/useApi'
import MetricCard from '../shared/MetricCard'
import DataTable from '../shared/DataTable'
import StatusBadge from '../shared/StatusBadge'
import {
  formatCurrency,
  formatDate,
  formatPercentage,
  getAgingBucketColor,
  getStatusLabel,
} from '../../utils/formatters'

// Carrier color palette
const CARRIER_COLORS = {
  sunlife_private: '#10B981',
  manulife: '#06B6D4',
  great_west: '#8B5CF6',
  canada_life: '#EC4899',
  green_shield: '#14B8A6',
  rbc: '#F59E0B',
  telus: '#EF4444',
  other: '#6B7280',
}

// Aging bucket colors
const AGING_COLORS = {
  '0-29': '#10B981',
  '30-59': '#F59E0B',
  '60-89': '#F97316',
  '90-119': '#EF4444',
  '120+': '#991B1B',
}

export default function DashboardTab() {
  const { data: queueStats, loading: statsLoading } = useApi('queue:stats')
  const { data: agingReport, loading: agingLoading } = useApi('aging:report')
  const { data: claimsList, loading: claimsLoading } = useApi('claims:list')
  const { data: escalations, loading: escalationsLoading } = useApi('escalations:list')
  const { data: carrierStats, loading: carrierStatsLoading } = useApi('carrier:stats')

  // Generate mock data for chart visualizations
  const dailyResolutionData = useMemo(() => {
    const now = new Date()
    return Array.from({ length: 14 }, (_, i) => {
      const date = new Date(now)
      date.setDate(date.getDate() - (13 - i))
      return {
        date: date.toLocaleDateString('en-CA', { month: 'short', day: 'numeric' }),
        resolved: Math.floor(Math.random() * 25) + 10,
      }
    })
  }, [])

  const agingDistributionData = useMemo(() => {
    if (!agingReport) return []
    return [
      { name: '0-29 days', value: agingReport['0-29'] || 0, fill: AGING_COLORS['0-29'] },
      { name: '30-59 days', value: agingReport['30-59'] || 0, fill: AGING_COLORS['30-59'] },
      { name: '60-89 days', value: agingReport['60-89'] || 0, fill: AGING_COLORS['60-89'] },
      { name: '90-119 days', value: agingReport['90-119'] || 0, fill: AGING_COLORS['90-119'] },
      { name: '120+ days', value: agingReport['120+'] || 0, fill: AGING_COLORS['120+'] },
    ]
  }, [agingReport])

  const carrierOutstandingData = useMemo(() => {
    if (!carrierStats) return []
    const carriers = Object.entries(carrierStats).map(([name, value]) => ({
      name: name.replace(/_/g, ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
      value: value,
      fill: CARRIER_COLORS[name] || CARRIER_COLORS.other,
    }))
    return carriers.sort((a, b) => b.value - a.value)
  }, [carrierStats])

  // Calculate metrics
  const totalOutstanding = useMemo(() => {
    if (!agingReport) return 0
    return Object.values(agingReport).reduce((sum, val) => sum + val, 0)
  }, [agingReport])

  const activeClaimsCount = useMemo(() => {
    if (!claimsList) return 0
    return claimsList.filter(c => c.status !== 'resolved' && c.status !== 'excluded').length
  }, [claimsList])

  const resolutionRate = useMemo(() => {
    if (!queueStats) return 0
    const total = (queueStats.queued || 0) + (queueStats.resolved || 0) + (queueStats.escalated || 0)
    if (total === 0) return 0
    return ((queueStats.resolved || 0) / total) * 100
  }, [queueStats])

  const avgDaysToResolve = useMemo(() => {
    if (!claimsList || claimsList.length === 0) return 0
    const resolved = claimsList.filter(c => c.status === 'resolved')
    if (resolved.length === 0) return 0
    const total = resolved.reduce((sum, c) => sum + (c.age || 0), 0)
    return Math.round(total / resolved.length)
  }, [claimsList])

  // DataTable columns
  const columns = [
    {
      key: 'id',
      label: 'Claim ID',
      sortKey: 'id',
      render: (value) => (
        <span className="font-mono font-semibold text-gray-900">#{value}</span>
      ),
    },
    {
      key: 'patient_name',
      label: 'Patient',
      sortKey: 'patient_name',
      render: (value) => {
        if (!value) return '—'
        const parts = value.split(' ')
        if (parts.length >= 2) {
          return `${parts[0].charAt(0)}. ${parts[parts.length - 1]}`
        }
        return value.charAt(0) + '.'
      },
    },
    {
      key: 'carrier',
      label: 'Carrier',
      sortKey: 'carrier',
      render: (value) => (
        <div className="flex items-center gap-2">
          <div
            className="w-2 h-2 rounded-full"
            style={{ backgroundColor: CARRIER_COLORS[value] || CARRIER_COLORS.other }}
          />
          <span className="text-gray-700">
            {value?.replace(/_/g, ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
          </span>
        </div>
      ),
    },
    {
      key: 'amount',
      label: 'Amount',
      sortKey: 'amount',
      render: (value) => (
        <span className="font-semibold text-gray-900">{formatCurrency(value)}</span>
      ),
    },
    {
      key: 'age',
      label: 'Age (days)',
      sortKey: 'age',
      render: (value) => (
        <span className={`font-medium ${value > 60 ? 'text-red-600' : value > 30 ? 'text-amber-600' : 'text-emerald-600'}`}>
          {value}
        </span>
      ),
    },
    {
      key: 'status',
      label: 'Status',
      sortKey: 'status',
      render: (value) => <StatusBadge status={value} />,
    },
    {
      key: 'last_action_date',
      label: 'Last Action',
      sortKey: 'last_action_date',
      render: (value) => <span className="text-gray-600 text-sm">{value ? formatDate(value) : '—'}</span>,
    },
  ]

  // Skeleton loader component
  const SkeletonCard = () => (
    <div className="bg-white rounded-lg border border-gray-200 p-6 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-24 mb-4" />
      <div className="h-10 bg-gray-200 rounded w-32 mb-2" />
      <div className="h-3 bg-gray-100 rounded w-20" />
    </div>
  )

  const SkeletonChart = () => (
    <div className="bg-white rounded-lg border border-gray-200 p-6 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-32 mb-6" />
      <div className="h-48 bg-gray-100 rounded" />
    </div>
  )

  return (
    <div className="p-8 space-y-8 bg-gray-50 min-h-screen">
      {/* Section 1: Top Row — Key Metrics */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {statsLoading || agingLoading ? (
            <>
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
            </>
          ) : (
            <>
              <MetricCard
                title="Total Outstanding AR"
                value={totalOutstanding}
                format="currency"
                trend={8}
                trendDirection="down"
                subtitle={`${activeClaimsCount} active claims`}
              />
              <MetricCard
                title="Claims in Queue"
                value={queueStats?.queued || 0}
                format="large"
                subtitle={`${queueStats?.in_progress || 0} in progress`}
                trend={5}
                trendDirection="up"
              />
              <MetricCard
                title="Resolution Rate"
                value={resolutionRate}
                format="percentage"
                subtitle={`${queueStats?.resolved || 0} resolved`}
                trend={12}
                trendDirection="up"
              />
              <MetricCard
                title="Avg Days to Resolve"
                value={avgDaysToResolve}
                format="raw"
                subtitle="across resolved claims"
                trend={-3}
                trendDirection="down"
              />
            </>
          )}
        </div>
      </div>

      {/* Section 2: Two-column layout — AR Aging & Call Queue Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: AR Aging Distribution */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">AR Aging Distribution</h3>
            {agingLoading ? (
              <div className="h-64 bg-gray-100 rounded animate-pulse" />
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart
                  data={agingDistributionData}
                  margin={{ top: 20, right: 30, left: 0, bottom: 20 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                  <XAxis dataKey="name" stroke="#6b7280" style={{ fontSize: '12px' }} />
                  <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                  <Tooltip
                    formatter={(value) => formatCurrency(value)}
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: '1px solid #e5e7eb',
                      borderRadius: '6px',
                    }}
                  />
                  <Bar dataKey="value" fill="#10B981" radius={[8, 8, 0, 0]}>
                    {agingDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Right: Call Queue Status */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Call Queue Status</h3>
          <div className="space-y-4">
            {/* Queued */}
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="flex items-center gap-3">
                <div className="relative w-2 h-2">
                  <div className="absolute inset-0 bg-blue-500 rounded-full animate-pulse" />
                  <div className="absolute inset-0 bg-blue-500 rounded-full" />
                </div>
                <span className="text-sm font-medium text-gray-700">Queued</span>
              </div>
              <span className="text-lg font-bold text-blue-600">
                {statsLoading ? '—' : queueStats?.queued || 0}
              </span>
            </div>

            {/* In Progress */}
            <div className="flex items-center justify-between p-3 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-amber-500 animate-spin" />
                <span className="text-sm font-medium text-gray-700">In Progress</span>
              </div>
              <span className="text-lg font-bold text-amber-600">
                {statsLoading ? '—' : queueStats?.in_progress || 0}
              </span>
            </div>

            {/* Completed Today */}
            <div className="flex items-center justify-between p-3 bg-emerald-50 rounded-lg border border-emerald-200">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-sm font-medium text-gray-700">Completed</span>
              </div>
              <span className="text-lg font-bold text-emerald-600">
                {statsLoading ? '—' : queueStats?.resolved || 0}
              </span>
            </div>

            {/* Run Queue Button */}
            <button className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M17.657 17.657a8 8 0 00-11.314 0m23.657-23.657a12 12 0 00-16.971 0l-2.686 2.686m19.343 19.343l-2.686 2.686m-2.686-2.686a4 4 0 005.656 0m11.314 0a8 8 0 010-11.314" />
              </svg>
              Run Queue
            </button>

            {/* Next Scheduled Run */}
            <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Next Run</p>
              <p className="text-sm font-semibold text-gray-900">Today at 2:00 PM</p>
              <p className="text-xs text-gray-500 mt-1">in 3 hours 25 minutes</p>
            </div>
          </div>
        </div>
      </div>

      {/* Section 3: Two-column layout — Daily Trend & Top Carriers */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Daily Resolution Trend */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Daily Resolution Trend</h3>
          {claimsLoading ? (
            <div className="h-64 bg-gray-100 rounded animate-pulse" />
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={dailyResolutionData} margin={{ top: 10, right: 30, left: 0, bottom: 20 }}>
                <defs>
                  <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" vertical={false} />
                <XAxis dataKey="date" stroke="#6b7280" style={{ fontSize: '12px' }} />
                <YAxis stroke="#6b7280" style={{ fontSize: '12px' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '6px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="resolved"
                  stroke="#10B981"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorResolved)"
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Right: Top Carriers by Outstanding */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Top Carriers by Outstanding</h3>
          {carrierStatsLoading ? (
            <div className="h-64 bg-gray-100 rounded animate-pulse" />
          ) : (
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={carrierOutstandingData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {carrierOutstandingData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(value)} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Section 4: Full-width Active Claims Table */}
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Active Claims</h3>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <DataTable
            columns={columns}
            data={claimsList || []}
            loading={claimsLoading}
            pageSize={10}
            emptyMessage="No active claims"
            sortKey="age"
            sortDirection="desc"
          />
        </div>
      </div>

      {/* Section 5: Right sidebar / Escalations */}
      {escalationsLoading ? (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Escalations</h3>
          <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-100 rounded animate-pulse" />
              ))}
            </div>
          </div>
        </div>
      ) : escalations && escalations.length > 0 ? (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Escalations</h3>
            <span className="inline-flex items-center justify-center w-6 h-6 bg-red-600 text-white text-xs font-bold rounded-full">
              {escalations.length}
            </span>
          </div>
          <div className="space-y-3">
            {escalations.map((escalation) => (
              <div
                key={escalation.id}
                className="bg-red-50 border border-red-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-2 rounded-full bg-red-600 flex-shrink-0 mt-2" />
                    <div>
                      <p className="font-semibold text-gray-900">Claim #{escalation.claim_id}</p>
                      <p className="text-sm text-gray-600 mt-1">
                        {escalation.carrier?.replace(/_/g, ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                      </p>
                    </div>
                  </div>
                  <span className="text-xs font-medium text-red-600 whitespace-nowrap ml-2">
                    {escalation.age} days
                  </span>
                </div>
                <p className="text-sm text-gray-700 mt-3 pl-5">
                  <span className="font-medium text-gray-900">Reason:</span> {escalation.reason || 'Requires manual review'}
                </p>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-12">
          <svg
            className="w-12 h-12 text-gray-400 mx-auto mb-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={1.5}
              d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <h4 className="text-lg font-medium text-gray-900 mb-1">No Escalations</h4>
          <p className="text-gray-500">All claims are on track. Great job!</p>
        </div>
      )}
    </div>
  )
}
