import { useState } from 'react'
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import MetricCard from '../shared/MetricCard'
import DataTable from '../shared/DataTable'
import StatusBadge from '../shared/StatusBadge'
import { useApi } from '../../hooks/useApi'
import { TrendingUp, Clock, CheckCircle } from 'lucide-react'

export default function AnalyticsTab() {
  const { data: stats } = useApi('queue:stats', { poll: false })
  const [timeRange] = useState('30d')

  // Mock analytics data
  const trendData = [
    { date: 'Day 1', resolved: 12, pending: 8, escalated: 2 },
    { date: 'Day 5', resolved: 18, pending: 12, escalated: 3 },
    { date: 'Day 10', resolved: 24, pending: 15, escalated: 2 },
    { date: 'Day 15', resolved: 32, pending: 18, escalated: 4 },
    { date: 'Day 20', resolved: 38, pending: 14, escalated: 3 },
    { date: 'Day 25', resolved: 45, pending: 10, escalated: 2 },
    { date: 'Day 30', resolved: 52, pending: 8, escalated: 1 },
  ]

  const carrierData = [
    { name: 'SunLife', resolved: 48, color: '#10B981' },
    { name: 'Manulife', resolved: 36, color: '#059669' },
    { name: 'Great West', resolved: 28, color: '#047857' },
    { name: 'Desjardins', resolved: 22, color: '#065f46' },
    { name: 'Other', resolved: 18, color: '#d1d5db' },
  ]

  const outcomeData = [
    { name: 'Resolved', value: 180, color: '#10B981' },
    { name: 'Pending', value: 45, color: '#F59E0B' },
    { name: 'Escalated', value: 12, color: '#EF4444' },
    { name: 'Failed', value: 8, color: '#9CA3AF' },
  ]

  const recentOutcomes = [
    { id: 'CLM-2025-001', carrier: 'SunLife', outcome: 'resolved', duration: '12m 34s', timestamp: '2025-04-05 14:23' },
    { id: 'CLM-2025-002', carrier: 'Manulife', outcome: 'resolved', duration: '8m 15s', timestamp: '2025-04-05 13:45' },
    { id: 'CLM-2025-003', carrier: 'Great West', outcome: 'escalated', duration: '18m 02s', timestamp: '2025-04-05 13:12' },
    { id: 'CLM-2025-004', carrier: 'SunLife', outcome: 'resolved', duration: '11m 48s', timestamp: '2025-04-05 12:30' },
    { id: 'CLM-2025-005', carrier: 'Desjardins', outcome: 'pending', duration: '15m 19s', timestamp: '2025-04-05 11:55' },
  ]

  const successRate = 94.2

  const outcomeColumns = [
    { key: 'id', label: 'Claim ID', sortKey: 'id' },
    { key: 'carrier', label: 'Carrier', sortKey: 'carrier' },
    {
      key: 'outcome',
      label: 'Outcome',
      sortKey: 'outcome',
      render: (value) => <StatusBadge status={value} />,
    },
    { key: 'duration', label: 'Duration', sortKey: 'duration' },
    { key: 'timestamp', label: 'Timestamp', sortKey: 'timestamp' },
  ]

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Metrics Row */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-6">Key Metrics</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <MetricCard
            title="Total Calls Made"
            value={245}
            icon={TrendingUp}
            color="primary"
            format="large"
            trend={18}
            trendDirection="up"
          />
          <MetricCard
            title="Avg Resolution Time"
            value="12m 24s"
            icon={Clock}
            color="primary"
            format="raw"
          />
          <MetricCard
            title="Success Rate"
            value={successRate}
            icon={CheckCircle}
            color="success"
            format="raw"
            subtitle="% of resolutions"
          />
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Resolution Trend */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-md font-semibold text-gray-900 mb-4">Resolution Trend (30 Days)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10B981" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#10B981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="date" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
                cursor={{ fill: 'rgba(16, 185, 129, 0.1)' }}
              />
              <Area
                type="monotone"
                dataKey="resolved"
                stroke="#10B981"
                fillOpacity={1}
                fill="url(#colorResolved)"
                name="Resolved"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Carrier Performance */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
          <h3 className="text-md font-semibold text-gray-900 mb-4">Carrier Performance</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={carrierData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip
                contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
              />
              <Bar dataKey="resolved" fill="#10B981" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Call Outcome Distribution */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-6">
        <h3 className="text-md font-semibold text-gray-900 mb-4">Call Outcome Distribution</h3>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={outcomeData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, value }) => `${name}: ${value}`}
              outerRadius={100}
              fill="#10B981"
              dataKey="value"
            >
              {outcomeData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Recent Outcomes Table */}
      <div>
        <h3 className="text-md font-semibold text-gray-900 mb-4">Recent Call Outcomes</h3>
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
          <DataTable
            columns={outcomeColumns}
            data={recentOutcomes}
            pageSize={10}
            sortKey="timestamp"
            sortDirection="desc"
            emptyMessage="No call outcomes available"
          />
        </div>
      </div>
    </div>
  )
}
