import { useState } from 'react'
import MetricCard from '../shared/MetricCard'
import DataTable from '../shared/DataTable'
import StatusBadge from '../shared/StatusBadge'
import { formatCurrency, formatClaimAge } from '../../utils/formatters'
import { Mail, FileText, Search, Users } from 'lucide-react'

export default function PatientARTab() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedPatient, setSelectedPatient] = useState(null)

  const mockPatients = [
    { id: 1, name: 'John Smith', balance: 450, insurancePending: 300, daysOutstanding: 15, status: 'queued', lastContact: '2025-04-02' },
    { id: 2, name: 'Sarah Johnson', balance: 1200, insurancePending: 800, daysOutstanding: 32, status: 'in_progress', lastContact: '2025-04-01' },
    { id: 3, name: 'Michael Brown', balance: 350, insurancePending: 0, daysOutstanding: 8, status: 'resolved', lastContact: '2025-03-28' },
    { id: 4, name: 'Emily Davis', balance: 800, insurancePending: 500, daysOutstanding: 45, status: 'escalated', lastContact: '2025-03-25' },
    { id: 5, name: 'Robert Williams', balance: 625, insurancePending: 400, daysOutstanding: 22, status: 'queued', lastContact: '2025-04-03' },
    { id: 6, name: 'Jennifer Martinez', balance: 925, insurancePending: 750, daysOutstanding: 38, status: 'in_progress', lastContact: '2025-03-30' },
    { id: 7, name: 'David Thompson', balance: 275, insurancePending: 150, daysOutstanding: 5, status: 'queued', lastContact: '2025-04-04' },
    { id: 8, name: 'Lisa Anderson', balance: 1450, insurancePending: 1200, daysOutstanding: 55, status: 'escalated', lastContact: '2025-03-20' },
  ]

  const filteredPatients = mockPatients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const totalPatientAR = filteredPatients.reduce((sum, p) => sum + p.balance, 0)
  const avgBalance = filteredPatients.length > 0 ? totalPatientAR / filteredPatients.length : 0
  const collectionRate = 72.5

  const columns = [
    {
      key: 'name',
      label: 'Patient Name',
      sortKey: 'name',
    },
    {
      key: 'balance',
      label: 'Balance',
      sortKey: 'balance',
      render: (value) => formatCurrency(value),
    },
    {
      key: 'insurancePending',
      label: 'Insurance Pending',
      sortKey: 'insurancePending',
      render: (value) => formatCurrency(value),
    },
    {
      key: 'daysOutstanding',
      label: 'Days Outstanding',
      sortKey: 'daysOutstanding',
      render: (value) => formatClaimAge(value),
    },
    {
      key: 'status',
      label: 'Payment Status',
      sortKey: 'status',
      render: (value) => <StatusBadge status={value} />,
    },
    {
      key: 'lastContact',
      label: 'Last Contact',
      sortKey: 'lastContact',
    },
  ]

  return (
    <div className="p-8 space-y-8 bg-gray-50">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Patient Accounts Receivable</h2>
        <p className="text-sm text-gray-600">Manage and track patient payment collections</p>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <MetricCard
          title="Total Patient AR"
          value={totalPatientAR}
          format="currency"
          color="primary"
          icon={Users}
          trend={5}
          trendDirection="up"
        />
        <MetricCard
          title="Avg Patient Balance"
          value={avgBalance}
          format="currency"
          color="info"
        />
        <MetricCard
          title="Collection Rate"
          value={collectionRate}
          format="raw"
          color="success"
          subtitle="% of target"
        />
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search patients by name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-gray-900"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        {filteredPatients.length === 0 ? (
          <div className="flex items-center justify-center p-12">
            <div className="text-center">
              <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-600 font-medium">No patients found</p>
              <p className="text-sm text-gray-500 mt-1">Try adjusting your search criteria</p>
            </div>
          </div>
        ) : (
          <DataTable
            columns={columns}
            data={filteredPatients}
            pageSize={10}
            sortKey="daysOutstanding"
            sortDirection="desc"
            onRowClick={(patient) => setSelectedPatient(patient)}
            emptyMessage="No patient balances available"
          />
        )}
      </div>

      {/* Action Buttons */}
      {filteredPatients.length > 0 && (
        <div className="flex gap-4">
          <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors">
            <Mail className="w-4 h-4" />
            Send Reminder
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-lg font-medium transition-colors">
            <FileText className="w-4 h-4" />
            Generate Statement
          </button>
        </div>
      )}
    </div>
  )
}
