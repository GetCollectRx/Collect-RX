import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwind from '@tailwindcss/vite'

export default defineConfig({
  plugins: [
    react(),
    tailwind(),
  ],
  base: './',
  build: {
    outDir: 'dist-renderer',
    target: 'esnext',
    minify: 'terser',
    sourcemap: false,
  },
  server: {
    port: 5173,
    strictPort: true,
    hmr: {
      protocol: 'http',
      host: 'localhost',
      port: 5173,
    },
  },
})
